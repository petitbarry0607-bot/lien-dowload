import * as THREE from 'three';
// Presentation only: no extra avatars, lights or permanent animation work.
export function createMatchIntro({blue,red,camera,onFinish}){
 const panel=document.createElement('div');panel.className='match-presentation';panel.hidden=true;panel.innerHTML='<div><small>TOUCHLINE · JOUR DE MATCH</small><h2></h2><p></p></div><button type="button">Passer la cinématique ↵</button>';document.body.append(panel);
 const title=panel.querySelector('h2'),sub=panel.querySelector('p');let active=false,t=0,entries=[],decorations=[];
 const world=e=>e.root.getWorldPosition(new THREE.Vector3());
 const place=(e,p,yaw)=>{e.root.position.copy(e.root.parent.worldToLocal(p.clone()));const q=e.root.parent.getWorldQuaternion(new THREE.Quaternion()).invert();e.root.quaternion.copy(q.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),yaw+(e.keeper?Math.PI:0))));};
 function finish(){if(!active)return;active=false;document.body.classList.remove('cinematic');for(const [o,visible] of decorations)o.visible=visible;for(const e of entries){e.root.position.copy(e.local);e.root.quaternion.copy(e.rotation);e.avatar.reset();}panel.hidden=true;onFinish();}
 panel.querySelector('button').onclick=finish;
 return {get active(){return active},get elapsed(){return t},skip:finish,
 start(){active=true;t=0;document.body.classList.add('cinematic');decorations=[];for(const e of [...blue,...red])for(const o of e.root.children){if(o.isSprite||o.geometry?.type==='RingGeometry'){decorations.push([o,o.visible]);o.visible=false;}}panel.hidden=false;entries=[];for(const [team,list] of [blue,red].entries())list.forEach((e,i)=>entries.push({...e,i,team,end:world(e),local:e.root.position.clone(),rotation:e.root.quaternion.clone(),start:new THREE.Vector3(35+i*1.25,0,team? -1.7:1.7),line:new THREE.Vector3((i-(list.length-1)/2)*2,0,team?-.57:.57)}));this.update(0);},
 update(dt){if(!active)return;t+=dt;const entry=t<12,greeting=t>=12&&t<18;
 title.textContent=entry?'Les équipes entrent sur le terrain':greeting?'Respect avant le coup d’envoi':'Les joueurs prennent leur place';sub.textContent='BLEUS  /  ROUGES · DUEL · 2 GARDIENS';
 for(const e of entries){let p,yaw;if(entry){const u=Math.min(1,t/12);p=e.start.clone().lerp(e.line,u);yaw=Math.PI/2;}else if(greeting){p=e.line.clone();yaw=e.team?Math.PI:0;}else{const u=THREE.MathUtils.smoothstep((t-18)/8,0,1);p=e.line.clone().lerp(e.end,u);const d=e.end.clone().sub(e.line);yaw=Math.atan2(-d.x,-d.z);}
 place(e,p,yaw);e.avatar.update(dt,{moving:!greeting,walk:entry});
 if(greeting){const age=t-12-e.i*.35;const strength=Math.min(1,Math.max(0,age/.35),Math.max(0,(1.8-age)/.4));if(strength>0)e.avatar.greet(new THREE.Vector3(e.line.x,1.12+Math.sin(age*10)*.018,0),strength);}}
 if(entry){camera.position.set(18,10,24);camera.lookAt(8,1,0);}else if(greeting){camera.position.set(13,4.5,12);camera.lookAt(0,1,0);}else{camera.position.set(29,30,35);camera.lookAt(0,0,0);}camera.fov=48;camera.updateProjectionMatrix();if(t>=26)finish();}
 };
}
