import {sampleKeeperMotion,keeperStepDuration} from './keeper-motion.js';
import * as THREE from 'three';
import { createFootballer } from './character.js?v=duels2';

// Blended keeper controller: breathing ready pose, planted lateral steps,
// anticipation, push-off, flight, landing, recovery and a walk back into position.
export function createGoalkeeper(scene,goalZ,options={}){
 const root=new THREE.Group();root.name='Goalkeeper';root.position.set(0,0,goalZ+1.12);scene.add(root);
 const pivot=new THREE.Group();pivot.position.y=1;root.add(pivot);
 const feet=new THREE.Group();feet.position.y=-1;feet.rotation.y=Math.PI;pivot.add(feet);
 const avatar=createFootballer(feet,{keeper:true,home:!!options.home});
 const hands=[],armChains=[],legChains=[],bones=[];const rig={};
 let catchAge=0,stanceBlend=0;const catchWorld=new THREE.Vector3();let cleanPose=null,ready=false,shot=false,reaction=0,committed=false,targetX=0,targetY=1,saved=false,shotCount=0;
 let phase='ready',phaseTime=0,age=0,vx=0,diveSign=0,catchTarget=null,lastTarget=new THREE.Vector3(0,1,goalZ+1.4);
 let throwRelease=null,throwEmitted=false,throwYaw=0;let lastIdleStep=0;
 let gaitSide=1,landRoll=0,recoverRoll=0,recoverHeight=1,phaseSerial=0,bodyCrouch=.07;
 const groundY=.073,baseZ=goalZ+1.12;
 const clamp=THREE.MathUtils.clamp,damp=THREE.MathUtils.damp;
 const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
 const wp=b=>b.getWorldPosition(new THREE.Vector3());
 const wq=b=>b.getWorldQuaternion(new THREE.Quaternion());
 const local=v=>pivot.localToWorld(v.clone());
 const airborne=()=>['push','flight','land','recover'].includes(phase);
 function enter(next){if(phase===next)return;phase=next;phaseTime=0;phaseSerial++;
  if(next==='land')landRoll=pivot.rotation.z;
  if(next==='recover'){recoverRoll=pivot.rotation.z;recoverHeight=pivot.position.y;for(const l of legChains)l.recoveryFrom=wp(l.foot);}
 }
 const promise=avatar.promise.then(m=>{
  m.updateWorldMatrix(true,true);
  m.traverse(o=>{if(o.isBone){bones.push(o);rig[o.name]=o;}});
  for(const side of ['L','R']){
   const palm=rig['Palm'+side],upper=rig['UpperArm'+side],lower=rig['LowerArm'+side];
   if(palm){const scale=palm.getWorldScale(new THREE.Vector3());const glove=new THREE.Mesh(new THREE.SphereGeometry(1,14,10),new THREE.MeshStandardMaterial({color:'#e8f3e7',roughness:.63}));glove.scale.set(.102/scale.x,.133/scale.y,.064/scale.z);glove.position.y=.085/scale.y;glove.castShadow=true;palm.add(glove);hands.push(glove);}
   if(upper&&lower&&palm)armChains.push({upper,lower,palm,side:side==='L'?1:-1,target:wp(palm)});
   const thigh=rig['UpperLeg'+side],calf=rig['LowerLeg'+side],foot=rig['Foot'+side],end=rig['LowerLeg'+side+'_end'];
   if(thigh&&calf&&foot&&end){
    const footWorld=wp(foot),offset=wp(end).sub(footWorld),base=root.worldToLocal(footWorld.clone());
    legChains.push({upper:thigh,lower:calf,end,foot,side:side==='L'?1:-1,offset,restQ:wq(foot),base,anchor:footWorld.clone(),start:footWorld.clone(),destination:footWorld.clone(),progress:1,duration:.24,stepping:false,recoveryFrom:footWorld.clone()});
   }
  }
  ready=true;reset(true);return m;
 });
 function restorePose(){if(cleanPose){cleanPose.forEach(([b,q,p])=>{b.quaternion.copy(q);b.position.copy(p);});cleanPose=null;}}
 function capturePose(){cleanPose=bones.map(b=>[b,b.quaternion.clone(),b.position.clone()]);}
 function reset(immediate=true){
  catchAge=0;stanceBlend=0;throwRelease=null;throwEmitted=false;throwYaw=0;pivot.rotation.y=0;shot=false;committed=false;reaction=0;targetX=0;targetY=1;saved=false;catchTarget=null;
  if(!immediate){if(!airborne())enter('return');return;}
  restorePose();avatar.reset();root.position.set(0,0,baseZ);pivot.position.set(0,1,0);pivot.rotation.set(0,0,0);vx=0;diveSign=0;phase='ready';phaseTime=0;bodyCrouch=.07;lastIdleStep=age;
  root.updateWorldMatrix(true,true);
  for(const l of legChains){l.anchor.set(root.position.x+l.side*.245,groundY+l.base.y,baseZ+l.base.z);l.start.copy(l.anchor);l.destination.copy(l.anchor);l.stepping=false;l.progress=1;}
  for(const a of armChains)a.target.copy(local(new THREE.Vector3(a.side*.31,.12,.40)));
 }
 function holdPoint(){root.updateWorldMatrix(true,true);if(hands.length===2){const together=wp(hands[0]).add(wp(hands[1])).multiplyScalar(.5);if(phase==='throw'){const palm=wp(hands[0]).add(new THREE.Vector3(0,0,.10).applyQuaternion(wq(pivot)));return together.lerp(palm,smooth(phaseTime/.23));}return together;}return local(new THREE.Vector3(0,.15,.35));}
 function startThrow(target){if(!saved||phase!=='hold'||phaseTime<.65)return false;throwYaw=clamp(Math.atan2(target.x-root.position.x,target.z-root.position.z),-.85,.85);throwEmitted=false;throwRelease=null;enter('throw');return true;}
 function takeThrowRelease(){const result=throwRelease;throwRelease=null;return result;}

 function aimBone(bone,child,where){
  const origin=wp(bone),current=wp(child).sub(origin).normalize(),wanted=where.clone().sub(origin).normalize();
  const delta=new THREE.Quaternion().setFromUnitVectors(current,wanted);
  const desired=wq(bone).premultiply(delta);
  bone.quaternion.copy(wq(bone.parent).invert().multiply(desired));bone.updateWorldMatrix(false,true);
 }
 // A length-preserving two-bone solver shared by the arms and knees.
 function solve(upper,lower,end,target,pole){
  const a=wp(upper),b=wp(lower),c=wp(end),l1=a.distanceTo(b),l2=b.distanceTo(c);
  const axis=target.clone().sub(a),distance=clamp(axis.length(),Math.abs(l1-l2)+.012,l1+l2-.010);axis.normalize();
  const perpendicular=pole.clone().sub(a);perpendicular.addScaledVector(axis,-perpendicular.dot(axis));
  if(perpendicular.lengthSq()<.00001)perpendicular.set(0,0,1).addScaledVector(axis,-axis.z);
  perpendicular.normalize();const along=(l1*l1-l2*l2+distance*distance)/(2*distance),h=Math.sqrt(Math.max(0,l1*l1-along*along));
  const elbow=a.clone().addScaledVector(axis,along).addScaledVector(perpendicular,h),tip=a.clone().addScaledVector(axis,distance);
  aimBone(upper,lower,elbow);aimBone(lower,end,tip);return tip;
 }
 function shiftWorld(b,offset){const desired=wp(b).add(offset);b.position.copy(b.parent.worldToLocal(desired));b.updateWorldMatrix(false,true);}
 function nominalFoot(l){return new THREE.Vector3(root.position.x+l.side*.245,groundY+l.base.y,baseZ+l.base.z);}
 function gait(dt){
  const moving=Math.abs(vx)>.12;
  let stepping=legChains.some(l=>l.stepping);
  if(!stepping){
   const needs=legChains.filter(l=>Math.abs(nominalFoot(l).x-l.anchor.x)>.095||Math.abs(nominalFoot(l).z-l.anchor.z)>.08);
   if(!needs.length&&!moving&&age-lastIdleStep>2.65&&!saved){const l=legChains.find(l=>l.side===gaitSide)||legChains[0];if(l){l.stepping=true;l.idleTap=true;l.progress=0;l.duration=.34;l.start.copy(l.anchor);l.destination.copy(nominalFoot(l));gaitSide=-l.side;lastIdleStep=age;}}
   if(needs.length){let chosen=needs.find(l=>l.side===gaitSide)||needs[0];chosen.stepping=true;chosen.idleTap=false;chosen.progress=0;chosen.duration=clamp(.28-Math.abs(vx)*.024,.17,.28);chosen.start.copy(chosen.anchor);chosen.destination.copy(nominalFoot(chosen));chosen.destination.x+=clamp(vx*.08,-.18,.18);gaitSide=-chosen.side;}
  }
  for(const l of legChains){if(l.stepping){l.progress=Math.min(1,l.progress+dt/l.duration);l.anchor.copy(l.start).lerp(l.destination,smooth(l.progress));const step=sampleKeeperMotion('sidestep',Math.min(.999,l.progress)*keeperStepDuration);const lift=Math.max(step[7],step[8])*.6;l.anchor.y+=l.idleTap?Math.sin(Math.PI*l.progress)*.027:Math.min(.085,lift)*(moving?1:.65);if(l.progress>=1){l.anchor.copy(l.destination);l.stepping=false;}}}
 }
 function update(dt,ball,velocity,inPlay,playerX,preparing=false){
  if(!ready||dt<=0)return;age+=dt;phaseTime+=dt;catchAge=saved?catchAge+dt:0;stanceBlend=damp(stanceBlend,preparing||committed?1:0,8,dt);restorePose();avatar.update(dt);capturePose();
  const flight=velocity.z<-.01?(root.position.z-ball.z)/velocity.z:99;
  let desiredX=clamp(playerX*.22,-1.65,1.65);
  if(shot&&!saved&&inPlay){
   reaction-=dt;
   if(!committed&&reaction<=0&&ball.z-root.position.z<12&&flight>0){committed=true;targetX=clamp(ball.x+velocity.x*flight+Math.sin(shotCount*2.41)*.16,-3.3,3.3);targetY=clamp(ball.y+velocity.y*flight-4.9*flight*flight,.22,2.6);lastTarget.set(targetX,targetY-.06,baseZ+.34);}
   if(committed&&!airborne()){
    if(phase!=='set')enter('set');desiredX=targetX;
    if(flight<.34&&flight>-.06&&(Math.abs(targetX-root.position.x)>.46||targetY>1.83)){
     diveSign=Math.abs(targetX-root.position.x)<.45?0:Math.sign(targetX-root.position.x);enter('push');
    }
   }
  }
  if(phase==='push'&&phaseTime>=.105)enter('flight');
  if(phase==='flight'&&phaseTime>=.46)enter('land');
  if(phase==='land'&&phaseTime>=.23)enter('recover');
  if(phase==='recover'&&phaseTime>=.95){pivot.rotation.z=0;pivot.position.y=1;for(const l of legChains){l.anchor.copy(nominalFoot(l));l.stepping=false;}diveSign=0;enter(saved?'hold':'return');}
  if(saved&&!airborne()&&phase!=='throw')enter('hold');
  if(phase==='throw'&&phaseTime>1.2){pivot.rotation.y=0;enter('return');}
  if(!inPlay&&!saved&&phase==='set')enter('return');
  if(phase==='hold'&&!saved)enter('return');
  if(phase==='return'){desiredX=clamp(playerX*.22,-1.65,1.65);if(Math.abs(root.position.x-desiredX)<.035&&Math.abs(vx)<.08)enter('ready');}
  if(phase==='set'||phase==='push')desiredX=targetX;
  let speed=phase==='set'?3.1:phase==='return'?1.9:2.1;
  let desiredVX=clamp((desiredX-root.position.x)*5,-speed,speed);
  if(phase==='push')desiredVX=clamp((targetX-root.position.x)*7,-3.2,3.2);
  if(phase==='flight')desiredVX=diveSign?clamp((targetX-root.position.x)*7,-4.7,4.7):0;
  if(['land','recover','hold','throw'].includes(phase))desiredVX=0;
  vx=damp(vx,desiredVX,phase==='flight'?15:9,dt);
  root.position.x=clamp(root.position.x+vx*dt,-3.2,3.2);
  if(phase==='ready'&&Math.abs(vx)>.14)enter('shuffle');
  if(phase==='shuffle'&&Math.abs(vx)<.08)enter('ready');
  const idleMotion=sampleKeeperMotion('idle',age);const lateralMotion=sampleKeeperMotion('sidestep',age);const shuffleWeight=clamp(Math.abs(vx)/1.8,0,1);
  let height=1,roll=0,crouch=.085+stanceBlend*.05-idleMotion[6]*.6-lateralMotion[6]*shuffleWeight*.3,flightT=0;
  if(phase==='push'){const p=smooth(phaseTime/.105);crouch=.085+.12*p;height=1;}
  if(phase==='flight'){
   flightT=clamp(phaseTime/.46,0,1);crouch=.03;
   if(diveSign){roll=-diveSign*1.38*smooth(flightT/.77);height=THREE.MathUtils.lerp(.97,.37,smooth(flightT)) + Math.sin(Math.PI*flightT)*(.24+Math.max(0,targetY-1.1)*.26);}
   else{height=1+Math.sin(Math.PI*flightT)*.50;roll=0;}
  }
  if(phase==='land'){const p=clamp(phaseTime/.23,0,1);roll=landRoll;height=diveSign?.37-.035*Math.sin(p*Math.PI):1;crouch=diveSign?.02:.16*Math.sin(p*Math.PI)+.07;}
  if(phase==='recover'){
   const p=clamp(phaseTime/.95,0,1);roll=THREE.MathUtils.lerp(recoverRoll,0,smooth((p-.12)/.80));height=p<.45?THREE.MathUtils.lerp(recoverHeight,.68,smooth(p/.45)):THREE.MathUtils.lerp(.68,1,smooth((p-.45)/.55));crouch=.08+Math.sin(Math.PI*p)*.16;
  }
  if(!airborne()){height=1+idleMotion[6]*.18;}
  pivot.position.y=height;pivot.rotation.z=roll;pivot.rotation.y=phase==='throw'?throwYaw*smooth(phaseTime/.3)*(1-smooth((phaseTime-1)/.2)):0;root.updateWorldMatrix(true,true);
  bodyCrouch=damp(bodyCrouch,crouch,16,dt);
  const sway=!airborne()?Math.sin(age*.95)*.014-clamp(vx*.008,-.02,.02):0;
  if(rig.Body)shiftWorld(rig.Body,new THREE.Vector3(sway,-bodyCrouch,0).applyQuaternion(wq(pivot)));
  if(rig.Torso){rig.Torso.rotateX(.065+Math.sin(age*2.1)*.012);rig.Torso.rotateZ(-clamp(vx*.018,-.045,.045));}
  if(phase==='throw'&&rig.Torso){const wind=smooth(phaseTime/.43),swing=smooth((phaseTime-.43)/.3),settle=1-smooth((phaseTime-.82)/.38);rig.Torso.rotateY((-.24*wind+.37*swing)*settle);rig.Torso.rotateX((-.10*wind+.28*swing)*settle);}
  if(rig.Head){const yaw=clamp(Math.atan2(ball.x-root.position.x,Math.max(2,ball.z-baseZ)),-.38,.38);rig.Head.rotateY(yaw*.55);rig.Head.rotateX(-clamp((ball.y-1.4)/20,-.04,.12));}
  root.updateWorldMatrix(true,true);
  if(!airborne())gait(dt);
  for(const l of legChains){
   let desired=l.anchor.clone(),q=l.restQ.clone();
   if(phase==='throw'&&l.side===-1){const step=smooth((phaseTime-.18)/.3)*(1-smooth((phaseTime-.83)/.37));desired.z+=.26*step;desired.y+=.055*Math.sin(Math.PI*step);}
   if(phase==='push'){desired=l.anchor.clone();}
   if(phase==='flight'||phase==='land'){
    const curl=(l.side===diveSign?.13:-.10)*Math.sin(Math.PI*flightT);
    desired=local(new THREE.Vector3(l.side*.245,-.94+Math.abs(curl),l.base.z+curl));desired.y=Math.max(groundY+l.base.y,desired.y);
    q.premultiply(wq(pivot));
   }
   if(phase==='recover'){desired=l.recoveryFrom.clone().lerp(nominalFoot(l),smooth(phaseTime/.65));desired.y=Math.max(groundY+l.base.y,desired.y);q.premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),roll));}
   const offset=l.offset.clone();if(phase==='flight'||phase==='land')offset.applyQuaternion(wq(pivot));
   const pole=local(new THREE.Vector3(l.side*.40,-.47,.60));
   const actual=solve(l.upper,l.lower,l.end,desired.clone().add(offset),pole);
   l.foot.position.copy(l.foot.parent.worldToLocal(actual.sub(offset)));
   l.foot.quaternion.copy(wq(l.foot.parent).invert().multiply(q));l.foot.updateWorldMatrix(false,true);
  }
  root.updateWorldMatrix(true,true);
  // Small, asynchronous glove adjustments during the ready idle; actual reach
  // follows the predicted ball, and a recovery hand pushes off the ground.
  const adjust=smooth((Math.sin(age*.88)-.78)/.22)*.07;
  let reach=committed&&inPlay?smooth((.70-flight)/.45):0;
  if(phase==='push'||phase==='flight')reach=1;if(phase==='land'||phase==='recover')reach=0;
  for(const a of armChains){
   const hand=a.side===1?0:3;
   const ix=clamp(Math.abs(idleMotion[hand]),.24,.37),sx=clamp(Math.abs(lateralMotion[hand])*.6,.34,.47);
   const hx=THREE.MathUtils.lerp(ix,sx,shuffleWeight)-adjust;
   const hy=.10+THREE.MathUtils.lerp(idleMotion[hand+1],lateralMotion[hand+1]*.65,shuffleWeight)+stanceBlend*.035;
   const hz=.30+THREE.MathUtils.lerp(idleMotion[hand+2],lateralMotion[hand+2],shuffleWeight)*.4+stanceBlend*.045;
   let readyPoint=local(new THREE.Vector3(a.side*hx,hy,hz));
   let desired=readyPoint.clone().lerp(lastTarget.clone().add(new THREE.Vector3(a.side*.10,0,0)),reach);
   if(saved){const hold=local(new THREE.Vector3(a.side*.115,.13,.35));const contact=catchWorld.clone().add(new THREE.Vector3(a.side*.10,0,0));desired.copy(contact).lerp(hold,smooth(catchAge/.38));}
   if(!saved&&phase==='recover'&&a.side===-Math.sign(recoverRoll)&&phaseTime<.52){const support=new THREE.Vector3(root.position.x+a.side*.34,.16,baseZ+.32);desired.lerp(support,Math.sin(Math.PI*clamp(phaseTime/.52,0,1))*.8);}
   if(!saved&&phase==='land')desired.lerp(local(new THREE.Vector3(a.side*.27,.20,.28)),.7);
   if(phase==='throw'){
    if(a.side===1){const points=[[0,.115,.13,.35],[.23,.36,.42,-.07],[.43,.38,.73,-.22],[.66,.25,.53,.64],[.87,.18,-.04,.60],[1.2,.31,.10,.39]];let i=0;while(i<points.length-2&&phaseTime>points[i+1][0])i++;const a0=points[i],b0=points[i+1],t=smooth((phaseTime-a0[0])/(b0[0]-a0[0]));desired=local(new THREE.Vector3(THREE.MathUtils.lerp(a0[1],b0[1],t),THREE.MathUtils.lerp(a0[2],b0[2],t),THREE.MathUtils.lerp(a0[3],b0[3],t)));}
    else{desired=local(new THREE.Vector3(-.35,.08,.25));}
   }
   a.target.lerp(desired,1-Math.exp(-dt*(phase==='throw'?32:airborne()?24:10)));
   const pole=local(new THREE.Vector3(a.side*.63,phase==='throw'?.25:.05,phase==='throw'&&phaseTime<.45?-.24:.24));solve(a.upper,a.lower,a.palm,a.target,pole);
   const palmWorld=wq(pivot).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),a.side*(.10+Math.sin(age*.8)*.015)));
   a.palm.quaternion.copy(wq(a.palm.parent).invert().multiply(palmWorld));a.palm.updateWorldMatrix(false,true);
  }
  root.updateWorldMatrix(true,true);
  if(phase==='throw'&&phaseTime>=.66&&!throwEmitted){throwRelease=holdPoint();throwEmitted=true;saved=false;shot=false;committed=false;}
 }
 function checkSave(previous,current,ballRadius){
  if(!ready||!shot||saved)return false;
  const segment=new THREE.Line3(previous,current),closest=new THREE.Vector3();
  const colliders=[];
  for(const [name,r] of [['Head',.18],['Torso',.25],['Abdomen',.26],['Hips',.24],['UpperLegL',.18],['UpperLegR',.18],['LowerLegL',.15],['LowerLegR',.15]])if(rig[name])colliders.push({p:wp(rig[name]),r});
  hands.forEach(g=>colliders.push({p:wp(g),r:.17}));
  for(const c of colliders){segment.closestPointToPoint(c.p,true,closest);if(closest.distanceTo(c.p)<c.r+ballRadius){saved=true;catchAge=0;catchWorld.copy(closest);catchTarget=pivot.worldToLocal(closest.clone());if(!airborne())enter('hold');return true;}}
  return false;
 }
 return {root,avatar,promise,reset,update,checkSave,holdPoint,startThrow,takeThrowRelease,hands,armChains,legChains,
  get motionSource(){return 'TechLabID idle + sidestep / adapted IK'},get ready(){return ready},get saved(){return saved},get diving(){return ['push','flight','land'].includes(phase)},get committed(){return committed},get animationState(){return phase},get phaseTime(){return phaseTime},
  onShot(){shot=true;reaction=.16;committed=false;saved=false;shotCount++;catchTarget=null;if(!airborne())enter('set');}
 };
}
