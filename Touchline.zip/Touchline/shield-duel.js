// Proximity controls the visible/physical shield, independently of the five-
// second contact budget. A quick step out and back cannot refill that budget.
export function createShieldDuel(){
 let age=0,duration=0,away=0,episode=false,near=false,enabled=true;
 const engaged=()=>episode&&near&&enabled;
 return {
  reset(){age=0;duration=0;away=0;episode=false;near=false;enabled=true;},
  update(dt,{owned,contact,distance,enabled:allowed=true}){
   if(!owned){this.reset();return;}
   enabled=allowed;
   near=distance<=(near?2.3:1.95);
   if(episode){age+=dt;away=distance>2.3?away+dt:0;if(away>1.5){this.reset();enabled=allowed;near=distance<=1.95;}}
   if(!episode&&near&&enabled&&contact){episode=true;age=0;duration=5;}
  },
  get near(){return near},get active(){return engaged()},
  get remaining(){return engaged()?Math.max(0,duration-age):0},
  get duration(){return duration},get exhausted(){return engaged()&&age>=duration},
  get protected(){return engaged()&&age<duration}
 };
}
