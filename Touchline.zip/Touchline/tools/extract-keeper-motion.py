"""Bake small IK motion curves from TechLabID GLBs (no mesh/texture copies).
Usage: python tools/extract-keeper-motion.py /path/to/keepers
Requires numpy/scipy for offline conversion, not for playing the game.
"""
from pathlib import Path
import sys,json,struct,numpy as np
from scipy.spatial.transform import Rotation
source=Path(sys.argv[1]);out={}
for key in ['idle','sidestep']:
 raw=(source/(key+'.glb')).read_bytes();ln=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+ln]);bn=struct.unpack_from('<I',raw,20+ln)[0];buf=raw[28+ln:28+ln+bn]
 def access(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];start=v.get('byteOffset',0)+a.get('byteOffset',0)
  return np.ndarray((a['count'],n),dtype='<f4',buffer=buf,offset=start,strides=(v.get('byteStride',n*4),4)).astype(float)
 nodes=d['nodes'];names={n.get('name','').split(':')[-1]:i for i,n in enumerate(nodes)};anim=d['animations'][0];channels=[]
 for c in anim['channels']:
  sampler=anim['samplers'][c['sampler']];channels.append((c['target']['node'],c['target']['path'],access(sampler['input'])[:,0],access(sampler['output'])))
 duration=max(t[-1] for _,_,t,_ in channels);frames=[]
 for time in np.linspace(0,duration,round(duration*30)+1):
  props=[{k:np.array(n.get(k,default),float) for k,default in [('translation',[0,0,0]),('rotation',[0,0,0,1]),('scale',[1,1,1])]} for n in nodes]
  for node,prop,t,vals in channels:
   j=max(0,min(len(t)-2,np.searchsorted(t,time)-1));f=np.clip((time-t[j])/max(1e-8,t[j+1]-t[j]),0,1);a,b=vals[j],vals[j+1]
   if prop=='rotation' and a@b<0:b=-b
   value=a*(1-f)+b*f
   if prop=='rotation':value/=np.linalg.norm(value)
   props[node][prop]=value
  world={}
  def visit(i,parent):
   p=props[i];m=np.eye(4);m[:3,:3]=Rotation.from_quat(p['rotation']).as_matrix()@np.diag(p['scale']);m[:3,3]=p['translation'];world[i]=parent@m
   for ch in nodes[i].get('children',[]):visit(ch,world[i])
  for root in d['scenes'][0]['nodes']:visit(root,np.eye(4))
  pos=lambda name:world[names[name]][:3,3]
  hip=pos('Hips');feet=[pos('LeftFoot'),pos('RightFoot')];toe=pos('LeftToeBase');forward=1 if toe[2]>feet[0][2] else -1
  # Positive X = actor left, positive Z = front, metres scaled to a 1.95m avatar.
  height=pos('HeadTop_End')[1]-min(f[1] for f in feet)
  frames.append({'lh':(pos('LeftHand')-hip).tolist(),'rh':(pos('RightHand')-hip).tolist(),'hip':hip.tolist(),'feet':[f.tolist() for f in feet],'height':height,'forward':forward})
 scale=1.95/max(f['height'] for f in frames);baseHip=max(f['hip'][1] for f in frames);floor=min(v[1] for f in frames for v in f['feet']);forward=frames[0]['forward'];leftsign=1 if frames[0]['lh'][0]>0 else -1
 baked=[]
 for f in frames:
  hands=[]
  for name in ['lh','rh']:
   x,y,z=f[name];hands.extend([x*scale*leftsign,y*scale,z*scale*forward])
  baked.append([round(v,5) for v in hands+[(f['hip'][1]-baseHip)*scale]+[(v[1]-floor)*scale for v in f['feet']]])
 out[key]={'duration':float(duration),'frames':baked}
 print(key,'seconds',duration,'frames',len(baked),'scale',scale,'first',baked[0],'range',np.min(baked,axis=0),np.max(baked,axis=0))
root=Path(__file__).resolve().parent.parent
(root/'assets/animations/keeper-motion.js').write_text('// Motion curves adapted from TechLabID goalkeeper packs; see LICENSE-TechLabID.txt.\nexport const keeperMotion='+json.dumps(out,separators=(',',':'))+';\n')
