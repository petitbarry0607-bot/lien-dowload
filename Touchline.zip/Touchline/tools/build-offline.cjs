const fs=require('fs'),path=require('path'),esbuild=require('esbuild');
const root=path.resolve(__dirname,'..');
(async()=>{
 const result=await esbuild.build({entryPoints:[path.join(__dirname,'offline-entry.js')],bundle:true,write:false,format:'iife',platform:'browser',target:'es2020',minify:true,legalComments:'inline',plugins:[{name:'local-modules',setup(build){build.onResolve({filter:/.*/},args=>{if(args.path==='three')return{path:path.join(root,'vendor/three.module.js')};if(args.path.startsWith('.')&&args.path.includes('?'))return{path:path.resolve(args.resolveDir,args.path.split('?')[0])};});}}]});
 const assets={};for(const file of ['assets/player.fbx',...fs.readdirSync(path.join(root,'assets/stadiums')).filter(f=>/\.(fbx|jpg)$/i.test(f)).map(f=>'assets/stadiums/'+f)])assets[file]=fs.readFileSync(path.join(root,file)).toString('base64');
 let html=fs.readFileSync(path.join(root,'app.html'),'utf8');
 html=html.replace(/<link rel="stylesheet" href="style.css[^\"]*">/,()=>'<style>'+fs.readFileSync(path.join(root,'style.css'),'utf8')+'</style>');
 html=html.replace(/<script type="importmap">[\s\S]*?<\/script>/,'');
 html=html.replace(/<script type="module" src="game.js[^\"]*"><\/script>/,()=>'<script id="embeddedAssets" type="application/json">'+JSON.stringify(assets)+'</script><script>'+result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script')+'</script>');
 fs.writeFileSync(path.join(root,'index.html'),html);console.log('Autonomous index.html:',(Buffer.byteLength(html)/1024/1024).toFixed(1),'MB;',Object.keys(assets).length,'embedded assets.');
})().catch(e=>{console.error(e);process.exit(1)});
