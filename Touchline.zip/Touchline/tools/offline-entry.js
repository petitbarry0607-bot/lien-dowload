import * as THREE from '../vendor/three.module.js';
const assets=JSON.parse(document.getElementById('embeddedAssets').textContent),urls=new Map();
function resolveAsset(url){
 const text=String(url).replaceAll('\\','/').split('?')[0];
 const key=Object.keys(assets).find(k=>text===k||text.endsWith('/'+k))||(/(?:^|\/)Pitch\.jpg$/i.test(text)?'assets/stadiums/Pitch.jpg':null);
 if(!key)return url;
 if(!urls.has(key)){const bytes=Uint8Array.from(atob(assets[key]),c=>c.charCodeAt(0));urls.set(key,URL.createObjectURL(new Blob([bytes],{type:key.endsWith('.jpg')?'image/jpeg':'application/octet-stream'})));}
 return urls.get(key);
}
for(const Loader of [THREE.FileLoader,THREE.ImageLoader]){
 const original=Loader.prototype.load;
 Loader.prototype.load=function(url,...args){
  const full=this.manager.resolveURL((this.path||'')+url),embedded=resolveAsset(full);
  if(embedded===full)return original.call(this,url,...args);
  const path=this.path;this.path='';try{return original.call(this,embedded,...args);}finally{this.path=path;}
 };
}
requestAnimationFrame(()=>setTimeout(()=>{import('../game.js').catch(error=>{
 console.error(error);const box=document.createElement('div');box.style='position:fixed;inset:20%;z-index:99999;background:#fff;padding:32px;color:#173e36;font:16px Arial';box.textContent='Le jeu n’a pas pu démarrer. Vérifie que l’accélération graphique est activée dans ton navigateur. Détail : '+error.message;document.body.appendChild(box);
});},0));
