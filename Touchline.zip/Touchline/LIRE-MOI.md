# TOUCHLINE — Gardiens animés

## Jouer
1. Extraire le ZIP dans un nouveau dossier.
2. Ouvrir **index.html** dans Chrome ou Edge. Aucune installation ni connexion requise.
3. Attendre la préparation des **4 personnages** et du stade, puis entrer sur le terrain.

L’onglet affiche « Touchline — Gardiens animés » pour identifier cette version.

## Mode simplifié demandé
- Bleus : le joueur contrôlé et son gardien.
- Rouges : un seul défenseur et son gardien.
- **Quatre personnages au total**, aucun autre joueur de champ chargé ou simulé.
- Le défenseur suit le ballon dans les quatre directions à 3,2 m/s : gauche, droite, avance et recul. Il vise une position à 80 cm du ballon, côté but adverse, ou le ballon lui-même lorsqu’il est libre.
- À distance, son corps s’oriente dans le sens réel du déplacement. Quand le porteur le fixe de face à moins de 4 mètres, il se met de trois quarts (45°), regarde le ballon et effectue de petits pas de recul dédiés. Aucune animation de course inversée. Il recule sur environ 2,5 mètres depuis le début du duel, prend appui 0,16 seconde, puis accélère à 4,4 m/s vers le ballon et tente un tacle debout. Le contact est évalué après le début du geste, pas instantanément. La protection ou une esquive peuvent faire échouer le tacle. Près de la limite du terrain, le recul est écourté. Le recul est interrompu si le porteur se détourne ou s’éloigne ; un ballon libéré déclenche la poursuite.
- Il peut récupérer un ballon proche, s’arrêter puis dégager.
- Les passes aux partenaires, appels et le panneau du coéquipier sont désactivés.
- L’engagement est simplifié : ballon au centre pour le joueur humain après le décompte, y compris après les buts. Le score est conservé.

La courte présentation d’avant-match réutilise les quatre personnages. Entrée ou « Passer la cinématique » permet de la passer. Le défenseur commence à 18 mètres du centre vers son but, puis peut se déplacer en profondeur.

## Commandes
ZQSD / flèches : déplacement. Maj : sprint. Espace : maintenir puis relâcher pour tirer. Souris : viser. X : tacle glissé. Ctrl : protection à proximité de l’adversaire. C : caméra. R : replacer au centre. Échap : pause.

Manette : stick gauche, RT/R2 pour sprinter, B/Rond pour tirer, X/Carré pour tacler sans ballon. L’accès à la manette dépend des permissions du navigateur.

## Éléments conservés
Terrain 105 × 68 m, seize stades complets, bancs décoratifs, public optimisé (léger / dense / masqué), caméra pro à orientation fixe, écran de chargement, personnalisation 3D du nom, de la peau et des chaussettes. Les gardiens peuvent arrêter et relancer à la main. Les réglages sont sauvegardés localement selon les capacités du navigateur.

## Sources et tests
**index.html** est autonome. Les autres fichiers constituent les sources ; **app.html** nécessite un serveur HTTP pour le développement.
Reconstruire : `npm ci`, puis `npm run build`.
Test du mode actuel : `npx playwright install chromium`, puis `node tools/test-mobile-duel.cjs`.
Les anciens tests des effectifs 11 contre 11 concernent les versions précédentes et ne représentent plus les critères de ce mode.

## Crédits
Voir assets/CREDITS.md, assets/stadiums/CREDITS.md et vendor/THREE-LICENSE.txt. Modèle Quaternius CC0. Licence des stades fournis non renseignée : à vérifier avant publication. Tenue et tête stylisées, non officielles.

Correction de rotation : les rotations de déplacement réinitialisent aussi les axes X et Z, afin de ne pas conserver une représentation de rotation issue de la cinématique qui inversait ensuite le sens visible. Tests des quatre directions après la présentation et le coup d’envoi.

Test spécifique : `node tools/test-three-quarter.cjs` vérifie le recul, l’angle du corps, la direction de la tête, la hauteur des pieds et la sortie de la posture.

## Animations défensives affinées

Entrée progressive dans la posture de trois quarts et sortie avec fondu de pose. Rotation du corps amortie à l’entrée du duel. Appuis maintenus en coordonnées du terrain durant le contact, petits pas à cadence variable, levée des pieds modérée et arrêt progressif du mouvement. Genoux légèrement fléchis, bras bas et détendus avec un léger contre-balancement. Le regard vers le ballon, le duel à quatre personnages et les déplacements normaux sont conservés.

Test visuel et de transitions : `node tools/test-defense-animation.cjs` (serveur HTTP sur le port 3000 requis).

## Recul puis attaque du ballon

Test actuel : `node tools/test-retreat-press.cjs` (recul de 2,5 m, prise d’appui, pressing, contact retardé du tacle, protection et esquive). L’ancien test de stabilisation `test-three-quarter.cjs` correspond à la version précédente où le défenseur maintenait son écart.

Le pack externe TechLabID Run Backward Arc Right a été téléchargé et inspecté, mais n’est pas intégré à cette version : squelette TechLabID de type Mixamo, différent du squelette Quaternius utilisé ici. Son adaptation doit être faite et vérifiée avant utilisation. Voir ANIMATIONS-EXTERNES.md.

## Animations des gardiens

Les deux gardiens utilisent maintenant des courbes de mouvement adaptées de TechLabID pour l’attente et les pas latéraux : respiration, petits mouvements des gants, flexion et levée des pieds. Modèles Quaternius, tenue et gants conservés. Le ramené du ballon après un arrêt et le relevé après un plongeon ont aussi été ajustés. Les arrêts, collisions, relances à la main et leur synchronisation restent gérés par le jeu ; la relance ne réinitialise pas le match. Aucun téléchargement additionnel nécessaire pour jouer.

Test : `node tools/test-keeper-motion.cjs`. Sources et licence : assets/animations/README.md. Le recul de 2,5 mètres puis pressing du défenseur est conservé.
