# Stadium pack supplied by the user

Source: https://github.com/petitbarry0607-bot/foot
Repository commit inspected: 6ec55fb635ba61dbd870ef9c1b759d53f06f865f
Original archive: Stadiums_FBX.zip (16 FBX stadiums plus Pitch.jpg).

No license or author attribution was included in the archive or repository at inspection time. Do not label these stadium models CC0: that license belongs to the separate Quaternius player model. Confirm stadium licensing before external publication or redistribution.

Runtime adaptation in stadium.js: pedestal removal, replacement of the static textured pitch with the existing playable field, normalized dimensions, reduced height. All stands and roofs are retained (the old camera-side cutaway was removed). FBX source files are unchanged. The country labels and numbers follow archive filenames and are not claims of real stadium identities.

The complete bowl is offset outwards to provide a grass runoff area around the full-size 105 × 68 m playing field. Two procedural covered team benches (seven seats each) and technical-area markings are added separately in technical-area.js.
