# Personnage Touchline

## Modèle original
- **Auteur : Quaternius**
- **Pack : Animated Men Pack (2019)**
- **Fichier : Smooth_Male_Casual.fbx**
- **Licence : Creative Commons Zero 1.0 (CC0 / domaine public)**
- Page de l'auteur : https://quaternius.com/packs/animatedmen.html
- Pack et indication de licence : https://poly.pizza/bundle/Animated-Men-Pack-DAC9SDgMQT
- Licence : https://creativecommons.org/publicdomain/zero/1.0/
- Téléchargement public fourni par l'auteur : https://drive.google.com/drive/folders/17LibivOaUidsQhSkcxP3YYvDr0n7wIwu
- Fichier : https://drive.google.com/file/d/1m46QkeqCFktuL5Vl3FR6_PtTKSN3WszF/view

## Adaptations pour ce jeu
Tenue bleue Touchline n°10, texture de maillot, short blanc, chaussettes hautes, couleurs de crampons, regroupement des matériaux, échelle et orientation, transitions d'animations, pose additive de frappe.
Les animations de repos, de course et d'applaudissement proviennent du modèle original. La frappe est une animation procédurale ajoutée au jeu.

## Supporters
Silhouettes procédurales créées pour le jeu dans crowd.js. Aucune photographie de spectateurs ni image externe n’est utilisée.

## Mouvements des gardiens
Courbes adaptées des packs GoalKeeper Breathing Idle et GoalKeeper Sidestep : **3D Asset by TechLabID**. Licence et détails dans `animations/README.md` et `animations/LICENSE-TechLabID.txt`. Ces courbes ne sont pas CC0. Les modèles/rigs Quaternius existants sont conservés.
