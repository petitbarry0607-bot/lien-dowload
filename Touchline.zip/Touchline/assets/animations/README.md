# Courbes de mouvement des gardiens — TechLabID

Source : https://techlabid.github.io/techlabid/free-3d-assets/

Packs effectivement adaptés :
- Breathing Idle : https://github.com/TechLabID/techlabid/releases/download/V11.0-GoalKeeper-asset/GoalKeeper_Breathing_Idle-3D-Asset.zip
- Goalkeeper Sidestep : https://github.com/TechLabID/techlabid/releases/download/V11.7-GoalKeeper-asset/GoalKeeper_Goalkeeper_Sidestep-3D-Asset.zip

Attribution : 3D Asset by TechLabID. Voir LICENSE-TechLabID.txt.

`keeper-motion.js` contient des courbes échantillonnées à 30 Hz depuis les animations GLB : positions des mains relatives au bassin, mouvement vertical du bassin et hauteur des pieds. Elles sont normalisées puis adaptées dans `keeper-motion.js` (module à la racine du projet) et `goalkeeper.js` pour piloter les cibles IK du gardien Quaternius. Les rotations du squelette source, déplacements globaux, modèles et textures source ne sont pas utilisés. Ce n’est donc pas la lecture brute de l’intégralité des clips source.

Les appuis, collisions, anticipation, plongeons et relances restent pilotés par le jeu. Le script `tools/extract-keeper-motion.py` documente la conversion depuis les GLB source. Les courbes sont incluses dans index.html ; aucun téléchargement en cours de partie.

Le pack Goalkeeper Catch a été téléchargé et inspecté, mais il n’est pas intégré à cette version. Le mouvement de ramené du ballon utilisé ici est procédural.
