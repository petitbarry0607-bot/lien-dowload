import * as THREE from 'three';
export function laneClear(a,b,obstacles,width=.85){
 const dx=b.x-a.x,dz=b.z-a.z,len=dx*dx+dz*dz;if(len<.01)return false;
 return obstacles.every(o=>{const p=o.position||o,t=((p.x-a.x)*dx+(p.z-a.z)*dz)/len;if(t<.06||t>.94)return true;return Math.hypot(p.x-a.x-t*dx,p.z-a.z-t*dz)>width;});
}
export function steerAvoid(position,desired,obstacles,strength=1){
 const result=desired.clone(),heading=desired.clone().normalize();
 for(const o of obstacles){const p=o.position||o,away=position.clone().sub(p);away.y=0;const d=away.length();if(d<.001)continue;
  if(d<2)result.addScaledVector(away.clone().normalize(),(2-d)*strength);
  const ahead=-away.dot(heading);if(d<2.6&&ahead>.1){const cross=heading.z*away.x-heading.x*away.z,side=cross>=0?-1:1;result.addScaledVector(new THREE.Vector3(-heading.z,0,heading.x),side*(2.6-d)*strength*.9);}
 }
 return result;
}
// Body contacts are separate from ball possession. Touching another player
// never transfers ownership, and a ball in flight is not a solid player body.
export function separatePlayers(roots,carrier){
 for(let n=0;n<4;n++)for(let i=0;i<roots.length;i++)for(let j=i+1;j<roots.length;j++){
  const a=roots[i],b=roots[j],dx=b.position.x-a.position.x,dz=b.position.z-a.position.z,d=Math.hypot(dx,dz),minimum=1.04;
  if(d>=minimum)continue;const nx=d>.0001?dx/d:(i%2?1:-1),nz=d>.0001?dz/d:0;
  const move=minimum-d,wa=a===carrier?.22:b===carrier?.78:.5;
  a.position.x-=nx*move*wa;a.position.z-=nz*move*wa;b.position.x+=nx*move*(1-wa);b.position.z+=nz*move*(1-wa);
 }
 for(const r of roots){r.position.x=THREE.MathUtils.clamp(r.position.x,-33.2,33.2);r.position.z=THREE.MathUtils.clamp(r.position.z,-50.8,51.2);}
}
