import * as THREE from 'three';
// 10 × 16 invisible, four-metre cells. Each team owns an independent grid.
// Occupancy and short-term predictions are rebuilt from teammates only.
export function createTeamGrid(){
 const size=4,occupied=new Map(),predicted=new Map(),reserved=new Map();let members=[];
 const cell=p=>`${THREE.MathUtils.clamp(Math.floor((p.x+34)/size),0,16)},${THREE.MathUtils.clamp(Math.floor((p.z+52.5)/size),0,26)}`;
 const add=(map,key,root)=>{if(!map.has(key))map.set(key,new Set());map.get(key).add(root);};
 const other=(map,key,root)=>[...(map.get(key)||[])].some(r=>r!==root);
 return {
  cellSize:size,cell,occupied,predicted,reserved,
  reset(){occupied.clear();predicted.clear();reserved.clear();members=[];},
  update(roots){members=[...new Set(roots.filter(Boolean))];occupied.clear();predicted.clear();for(const root of members){add(occupied,cell(root.position),root);const future=root.position.clone().addScaledVector(root.userData?.velocity||new THREE.Vector3(),.5);add(predicted,cell(future),root);}},
  clearReservations(){reserved.clear();},
  canReserve(root,point){const key=cell(point);return !other(occupied,key,root)&&(!reserved.has(key)||reserved.get(key)===root);},
  reserve(root,point){if(!this.canReserve(root,point))return false;for(const [key,owner]of reserved)if(owner===root)reserved.delete(key);reserved.set(cell(point),root);return true;},
  penalty(root,point){const key=cell(point);return (other(occupied,key,root)?12:0)+(other(predicted,key,root)?7:0)+(reserved.has(key)&&reserved.get(key)!==root?18:0);},
  routeCost(root,point){let sum=0;const seen=new Set();for(const t of [.3,.55,.8,1]){const p=root.position.clone().lerp(point,t),key=cell(p);if(!seen.has(key)){seen.add(key);sum+=this.penalty(root,p);}}return sum;},
  steer(root,desired){
   const speed=desired.length();if(speed<.1)return desired;
   // A cell is not a physical wall: only detour when a teammate is actually
   // near the projected path. This permits short passes and natural crossings.
   const forward=desired.clone().normalize();const near=members.filter(r=>r!==root&&r.position.distanceTo(root.position)<3);
   const collision=d=>near.some(r=>{const delta=r.position.clone().addScaledVector(r.userData?.velocity||new THREE.Vector3(),.25).sub(root.position);delta.y=0;const along=delta.dot(d);return along>0&&along<Math.min(2.4,speed*.55)&&delta.lengthSq()-along*along<1.2*1.2;});
   if(!collision(forward))return desired;
   let best=null,score=Infinity;
   for(const angle of [-.65,.65,-1.15,1.15]){const d=forward.clone().applyAxisAngle(new THREE.Vector3(0,1,0),angle);if(collision(d))continue;const end=root.position.clone().addScaledVector(d,2.3);if(Math.abs(end.x)>33||Math.abs(end.z)>51)continue;const value=Math.abs(angle)*4+this.penalty(root,end);if(value<score){score=value;best=d;}}
   return best?best.multiplyScalar(speed*.88):desired.clone().multiplyScalar(.18);
  }
 };
}
