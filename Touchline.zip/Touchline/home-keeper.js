import * as THREE from 'three';
import {createGoalkeeper} from './goalkeeper.js?v=duels2';
// Run the existing keeper in its canonical end, then mirror its completed pose.
// IK, glove sweeps and recovery all operate in the same coordinates as before.
export function createHomeKeeper(scene){
 const group=new THREE.Group();scene.add(group);const keeper=createGoalkeeper(group,-52.5,{home:true});
 const mirror=v=>new THREE.Vector3(-v.x,v.y,-v.z);
 function canonical(fn){group.rotation.y=0;group.updateMatrixWorld(true);try{return fn();}finally{group.rotation.y=Math.PI;group.updateMatrixWorld(true);}}
 const promise=keeper.promise.then(m=>{group.rotation.y=Math.PI;group.updateMatrixWorld(true);return m;});
 return {root:keeper.root,promise,group,avatar:keeper.avatar,get saved(){return keeper.saved},get ready(){return keeper.ready},get animationState(){return keeper.animationState},
 startThrow(target){return canonical(()=>keeper.startThrow(mirror(target)));},takeThrowRelease(){return canonical(()=>{const point=keeper.takeThrowRelease();return point?mirror(point):null;});},
 reset(immediate=true){canonical(()=>keeper.reset(immediate));},onShot(){keeper.onShot();},
 update(dt,ball,velocity,inPlay,x,charging=false){canonical(()=>keeper.update(dt,mirror(ball),mirror(velocity),inPlay,-x,charging));},
 checkSave(a,b,r){return canonical(()=>keeper.checkSave(mirror(a),mirror(b),r));},
 holdPoint(){return canonical(()=>mirror(keeper.holdPoint()));}
 };
}
