import * as THREE from 'three';
import {createTeamGrid} from './team-grid.js';
import {laneClear} from './tactics.js';
export function createTeamMovement(sign){
 const grid=createTeamGrid(),plans=new Map();let review=0,age=0,lastCarrier=null;
 const roles=['left','back','right','striker'];
 const role=r=>r.userData?.tacticalRole||'striker';
 const bounds=r=>(role(r)==='fullLeft'?[-17,-10]:role(r)==='fullRight'?[10,17]:role(r)==='midCenter'?[-3,3]:role(r)==='left'?[-16.5,-10]:role(r)==='right'?[10,16.5]:role(r)==='midLeft'?[-9,-1]:role(r)==='midRight'?[1,9]:role(r)==='back'?(r.userData.tacticalLane<0?[-9,-2]:[2,9]):[-5.5,5.5]).map(v=>v*1.7);
 function positionFor(root,ball,defending=false){
  const r=role(root),progress=ball.z*sign/1.640625;
  const x=r==='fullLeft'?-14:r==='fullRight'?14:r==='midCenter'?0:r==='left'?-13:r==='right'?13:r==='back'?(root.userData.tacticalLane??0):r==='midLeft'?-5:r==='midRight'?5:THREE.MathUtils.clamp(ball.x*.18,-3,3);
  const depth=r.startsWith('full')?THREE.MathUtils.clamp(progress-10,-25,8):r==='midCenter'?THREE.MathUtils.clamp(progress-7,-20,15):r==='back'?THREE.MathUtils.clamp(progress-12,-25,6):r==='striker'?THREE.MathUtils.clamp(progress+(defending?2:10),-10,26):r.startsWith('mid')?THREE.MathUtils.clamp(progress-(r==='midLeft'?5:2),-18,18):THREE.MathUtils.clamp(progress+(defending?-5:3),-20,23);
  return new THREE.Vector3(x*1.7,0,sign*depth*1.640625);
 }
 return {grid,positionFor,get plans(){return plans},
  reset(){plans.clear();grid.reset();review=0;age=0;lastCarrier=null;},
  update(dt,{agents,carrier,holder,enemies,active,members}){
   agents.forEach((a,i)=>{a.root.userData??={};a.root.userData.tacticalRole??=roles[i%4];});
   grid.update(members||[...agents.map(a=>a.root),carrier]);
   if(!active){plans.clear();grid.clearReservations();lastCarrier=null;return plans;}
   age+=dt;review-=dt;const changed=lastCarrier!==carrier;if(changed){lastCarrier=carrier;review=0;}
   if(review>0)return plans;review=.28;grid.clearReservations();
   for(const a of agents){
    if(a.root===carrier){plans.delete(a);continue;}
    const root=a.root,anchor=positionFor(root,holder),[minX,maxX]=bounds(root),old=plans.get(a);
    // Explicit calls keep their depth but cannot drag a winger across the pitch.
    if(a.runTarget){const t=a.runTarget.clone();t.x=THREE.MathUtils.clamp(t.x,minX,maxX);if(t.distanceTo(a.runTarget)>.1)a.requestRun(t);if(grid.reserve(root,t)){plans.set(a,{target:t,kind:'run',speed:5.8,until:age+1,open:laneClear(holder,t,enemies,1.05)});continue;}a.cancelRun?.();}
    if(!changed&&old&&age<old.until&&old.target.distanceTo(anchor)<6&&grid.reserve(root,old.target)){continue;}
    let target=null,best=-Infinity;
    // Absolute field lanes, never offsets from the ball's lateral position.
    for(const dx of [-3,0,3])for(const dz of [-4,0,4]){
     const p=anchor.clone();p.x=THREE.MathUtils.clamp(p.x+dx,minX,maxX);p.z=THREE.MathUtils.clamp(p.z+dz,-48.5,48.5);
     if(p.distanceTo(holder)<4||!grid.canReserve(root,p))continue;
     const gap=Math.min(8,...enemies.map(e=>p.distanceTo(e.position)));
     let score=(laneClear(holder,p,enemies,1.05)?12:0)+gap*1.1-p.distanceTo(anchor)*1.3-root.position.distanceTo(p)*.08-grid.routeCost(root,p)*.15;
     if(gap<2)score-=(2-gap)*12;
     if(old&&p.distanceTo(old.target)<1)score+=2; // don't dance when already available
     if(score>best){best=score;target=p;}
    }
    // Congestion fallback stays in the player's OWN lane, even far from the ball.
    if(!target)for(let z=-46;z<=46;z+=4)for(const x of [minX,(minX+maxX)/2,maxX]){const p=new THREE.Vector3(x,0,z);if(!grid.canReserve(root,p))continue;const score=-p.distanceTo(anchor);if(score>best){best=score;target=p;}}
    if(!target){plans.delete(a);continue;}grid.reserve(root,target);
    const kind=(role(root)==='back'||role(root).startsWith('full'))?'balance':role(root)==='striker'?'run':role(root).startsWith('mid')?'support':'wide';
    plans.set(a,{target,kind,speed:4.8,until:age+1.2,open:laneClear(holder,target,enemies,1.05)});
   }
   return plans;
  }
 };
}
