import * as THREE from 'three';
import {createSockStyle} from './sock-style.js';
import {paintParisKit,createDembeleFace} from './psg-kit.js?v=editor1';
import { FBXLoader } from './vendor/FBXLoader.js';

// Source: Quaternius, Animated Men Pack, Smooth_Male_Casual.fbx (CC0).
// Original locomotion clips; Touchline kit, calf socks and shooting pose added here.
export function createFootballer(parent,options={}){
 const isKeeper=!!options.keeper;const sockStyle=options.dembele?createSockStyle():null;
 let model,mixer,actions={},active=null,ready=false,kickTime=0;
 const kickDuration=.28;const kickContact=.095;const kickRest={};
 let overlayPose=null,overlayModelY=null,overlayModelRotation=null,poseAge=0;
 const rig={};
 const lastWorld=new THREE.Vector3(),world=new THREE.Vector3(),localVelocity=new THREE.Vector3(),worldRotation=new THREE.Quaternion();
 let jockeyBlend=0,jockeyPhase=0;const jockeyMotion=new THREE.Vector3(),jockeyFeet=new Map();
 let tracked=false,smoothSpeed=0,turnLean=0,lastHeading=0,forwardLean=0;
 let idleBreath=0,breathPhase=(options.number??10)*.71,exertion=0,breathLift=0;
 const blendWeights={idle:1,walk:0,run:0,clap:0};
 const kitCanvas=document.createElement('canvas');kitCanvas.width=1024;kitCanvas.height=512;
 const c=kitCanvas.getContext('2d');c.fillStyle=isKeeper?(options.home?'#957acb':'#ef9a32'):options.opponent?'#c84136':'#1979bd';c.fillRect(0,0,1024,512);
 const grad=c.createLinearGradient(0,0,0,512);grad.addColorStop(0,isKeeper?(options.home?'#594181':'#cf6427'):options.opponent?'#8e2928':'#0c589c');grad.addColorStop(1,isKeeper?(options.home?'#ae92d9':'#f6ba4c'):options.opponent?'#e46b4e':'#239cd0');c.fillStyle=grad;c.fillRect(0,0,1024,512);
 for(let x=0;x<1024;x+=12){c.fillStyle='rgba(255,255,255,.024)';c.fillRect(x,0,1,512);}
 for(const offset of [0,512]){c.fillStyle='#eef4e3';c.fillRect(offset,27,512,10);c.fillStyle='#164e88';c.fillRect(offset,482,512,30);}
 c.fillStyle='#f8f5e7';c.textAlign='center';c.font='700 40px Arial';c.fillText('TOUCHLINE',256,109);c.font='900 236px Arial';c.fillText(String(options.number??(isKeeper?1:10)),256,357);c.fillStyle='#d9f573';c.fillRect(224,398,64,7);
 c.fillStyle='#eaf5da';c.beginPath();c.moveTo(865,94);c.lineTo(918,94);c.lineTo(915,146);c.lineTo(891,164);c.lineTo(868,146);c.closePath();c.fill();c.fillStyle='#176fa6';c.font='bold 22px Arial';c.fillText('TL',891,130);c.fillStyle='#edf6e7';c.font='700 38px Arial';c.fillText('TOUCHLINE',768,244);c.font='17px Arial';c.fillText('FOOTBALL CLUB',768,276);
 const paris=!isKeeper&&!options.opponent;if(paris)paintParisKit(kitCanvas,options.number??10,options.dembele?'DEMBÉLÉ':'PARIS');
 const faceTexture=options.dembele?createDembeleFace():null;
 const tex=new THREE.CanvasTexture(kitCanvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;
 const promise=new FBXLoader().loadAsync('./assets/player.fbx').then(object=>{
 model=object;model.name=options.dembele?'Dembele_Stylised_PSG_10':'Quaternius_Touchline_Player';model.userData.kit=paris?'PSG inspired':'Touchline';model.updateMatrixWorld(true);
 model.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false;const g=o.geometry,positions=g.attributes.position;const colors=new Float32Array(positions.count*3),uv=new Float32Array(positions.count*2);colors.fill(1);const sourceMaterials=Array.isArray(o.material)?o.material:[o.material];const groups=[...g.groups],color=new THREE.Color(),pos=new THREE.Vector3();const sockHeights=new Float32Array(positions.count);const skinIndices=new Set();const indices=[];const reshaped=new Set();const inverseMesh=o.matrixWorld.clone().invert();
 // Paint in bind-pose coordinates so kit details follow the skinned animation.
 for(const group of groups){const name=sourceMaterials[group.materialIndex].name;for(let i=group.start;i<group.start+group.count;i++){const index=g.index?g.index.getX(i):i;pos.fromBufferAttribute(positions,index).applyMatrix4(o.matrixWorld);
 sockHeights[index]=pos.y;
 let hex='#ffffff';if(name==='Skin')hex=pos.y<126?(options.opponent?'#a43830':'#176db4'):(options.skinTone||'#b68059');else if(name==='Hair'||name==='Hair2')hex='#332d29';else if(name==='Eyes')hex=pos.y<20?'#d4ec61':'#242c2b';else if(name==='Pants')hex=Math.abs(pos.x)>37?'#164f88':'#eff2e4';else if(name==='Socks')hex=options.opponent?'#a43830':'#176db4';else if(name==='Shoes')hex='#d4ec61';
 if(paris&&(name==='Pants'||name==='Socks'||name==='Skin'&&pos.y<126))hex='#0b2042';
 if(options.dembele&&name==='Skin'&&pos.y>=126)hex='#754a36';
 if(options.dembele&&(name==='Hair'||name==='Hair2'||name==='Skin'&&pos.y>451&&Math.abs(pos.x)<28))hex='#151311';
 if(isKeeper&&name==='Pants')hex='#24343b';if(isKeeper&&((name==='Skin'&&pos.y<126)||name==='Socks'))hex='#df8e2e';
 if(name==='Skin'&&pos.y>116&&pos.y<126)hex='#eef4dc';
 if(name==='Skin'&&pos.y>=126&&!(options.dembele&&pos.y>451&&Math.abs(pos.x)<28))skinIndices.add(index);
 color.set(hex);colors[index*3]=color.r;colors[index*3+1]=color.g;colors[index*3+2]=color.b;
 const front=pos.z>0;uv[index*2]=(front?.5:0)+THREE.MathUtils.clamp((front?pos.x:-pos.x)/115+.5,.006,.994)*.5;uv[index*2+1]=THREE.MathUtils.clamp((pos.y-253)/148,.01,.99);
 if(faceTexture&&name==='Skin'){uv[index*2]=.01;uv[index*2+1]=.99;if(pos.y>400&&Math.abs(pos.x)<28&&pos.z>7){uv[index*2]=.10+.80*THREE.MathUtils.clamp((pos.x+25)/50,0,1);uv[index*2+1]=.10+.80*THREE.MathUtils.clamp((pos.y-400)/65,0,1);}}
 if(options.dembele&&!reshaped.has(index)&&pos.y>410&&Math.abs(pos.x)<29){reshaped.add(index);const p=pos.clone();p.x*=.94;if(name==='Hair'||name==='Hair2'){p.y=436+(p.y-436)*.78;p.z*=.94;}p.applyMatrix4(inverseMesh);positions.setXYZ(index,p.x,p.y,p.z);}

 }}
 // Consolidate the exporter's many interleaved material groups into six draw calls.
 g.clearGroups();for(let mat=0;mat<sourceMaterials.length;mat++){const start=indices.length;for(const group of groups){if(group.materialIndex!==mat)continue;for(let i=group.start;i<group.start+group.count;i++)indices.push(g.index?g.index.getX(i):i);}if(indices.length>start)g.addGroup(start,indices.length-start,mat);}g.userData.skinIndices=[...skinIndices];g.setIndex(indices);if(options.dembele){positions.needsUpdate=true;g.computeVertexNormals();}g.setAttribute('color',new THREE.BufferAttribute(colors,3));g.setAttribute('uv',new THREE.BufferAttribute(uv,2));g.setAttribute('sockBindHeight',new THREE.BufferAttribute(sockHeights,1));
 o.material=sourceMaterials.map(m=>new THREE.MeshStandardMaterial({name:m.name,color:'#ffffff',vertexColors:true,roughness:m.name==='Eyes'?.55:.85,map:m.name.startsWith('Shirt')?tex:m.name==='Skin'?faceTexture:null}));
 if(sockStyle)for(const mat of o.material)if(mat.name==='Skin'||mat.name==='Socks')sockStyle.apply(mat);
 });
 mixer=new THREE.AnimationMixer(model);
 for(const [key,suffix] of Object.entries({idle:'Man_Idle',walk:'Man_Walk',run:'Man_Run',clap:'Man_Clapping'})){const clip=model.animations.find(a=>a.name.endsWith(suffix));if(clip){actions[key]=mixer.clipAction(clip);actions[key].play();actions[key].time=((options.number??10)*.317)%clip.duration;actions[key].setEffectiveWeight(0);}}
 actions.idle.setEffectiveWeight(1);active='idle';mixer.update(.001);model.updateMatrixWorld(true);
 const bounds=new THREE.Box3().setFromObject(model),height=bounds.max.y-bounds.min.y;const scale=1.95/height;model.scale.multiplyScalar(scale);model.position.y=-bounds.min.y*scale;model.rotation.y=Math.PI;parent.add(model);
 model.traverse(b=>{if(b.isBone)rig[b.name]=b;});for(const name of ['UpperLegR','LowerLegR'])kickRest[name]=rig[name].quaternion.clone();
 ready=true;return model;
 });
 // Restore the unmodified mixer pose BEFORE the next mixer update. Three.js
 // may skip unchanged tracks; incremental bone rotations otherwise accumulate.
 function restoreOverlay(){
  if(overlayModelRotation){model.quaternion.copy(overlayModelRotation);overlayModelRotation=null;}
  if(overlayModelY!==null){model.position.y=overlayModelY;overlayModelY=null;}
  if(!overlayPose)return;
  for(const [name,pose] of Object.entries(overlayPose)){
   rig[name].quaternion.copy(pose.quaternion);rig[name].position.copy(pose.position);
  }
  overlayPose=null;
 }
 const keyframes=[
  [0,0,0,0], [.14,.22,.34,.012], [.34,-.90,-.20,.045],
  [.58,-.66,-.12,.025], [1,0,0,0]
 ];
 function sampleKick(p){
  let i=0;while(i<keyframes.length-2&&p>keyframes[i+1][0])i++;
  const a=keyframes[i],b=keyframes[i+1];let t=THREE.MathUtils.clamp((p-a[0])/(b[0]-a[0]),0,1);t=t*t*(3-2*t);
  return a.slice(1).map((v,j)=>THREE.MathUtils.lerp(v,b[j+1],t));
 }
 const wp=b=>b.getWorldPosition(new THREE.Vector3()),wq=b=>b.getWorldQuaternion(new THREE.Quaternion());
 function aimBone(bone,child,target){const a=wp(bone),q=new THREE.Quaternion().setFromUnitVectors(wp(child).sub(a).normalize(),target.clone().sub(a).normalize());bone.quaternion.copy(wq(bone.parent).invert().multiply(wq(bone).premultiply(q)));bone.updateWorldMatrix(false,true);}
 function solve(a,b,c,target,pole){const origin=wp(a),l1=origin.distanceTo(wp(b)),l2=wp(b).distanceTo(wp(c)),axis=target.clone().sub(origin);const d=THREE.MathUtils.clamp(axis.length(),Math.abs(l1-l2)+.01,l1+l2-.01);axis.normalize();const normal=pole.clone().sub(origin);normal.addScaledVector(axis,-normal.dot(axis)).normalize();const x=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-x*x));aimBone(a,b,origin.clone().addScaledVector(axis,x).addScaledVector(normal,h));aimBone(b,c,origin.clone().addScaledVector(axis,d));}
 function shieldPose(amount,side,moving){
  overlayPose={};for(const [name,bone] of Object.entries(rig))overlayPose[name]={quaternion:bone.quaternion.clone(),position:bone.position.clone()};
  model.updateWorldMatrix(true,true);
  const legs=['L','R'].map(s=>{const foot=rig['Foot'+s],end=rig['LowerLeg'+s+'_end'];const point=wp(foot),local=parent.worldToLocal(point.clone()),sign=Math.sign(local.x)||1;const stance=amount*(moving?.42:1);local.x=THREE.MathUtils.lerp(local.x,sign*.29,stance);local.z+=sign*side*.13*stance;return {s,sign,foot,end,target:parent.localToWorld(local),offset:wp(end).sub(point),q:wq(foot)};});
  overlayModelY=model.position.y;overlayModelRotation=model.quaternion.clone();
  model.position.y-=(.205+Math.sin(poseAge*2.5)*.006)*amount;
  model.rotateY(side*.38*amount);
  rig.Torso.rotateX(.16*amount);rig.Torso.rotateY(-side*.20*amount);model.updateWorldMatrix(true,true);
  for(const l of legs){solve(rig['UpperLeg'+l.s],rig['LowerLeg'+l.s],l.end,l.target.clone().add(l.offset),parent.localToWorld(new THREE.Vector3(l.sign*.38,.5,-.85)));l.foot.position.copy(l.foot.parent.worldToLocal(l.target));l.foot.quaternion.copy(wq(l.foot.parent).invert().multiply(l.q));}
  model.updateWorldMatrix(true,true);
  for(const s of ['L','R']){
   const arm=rig['UpperArm'+s],lower=rig['LowerArm'+s],palm=rig['Palm'+s];if(!palm)continue;
   const sign=Math.sign(parent.worldToLocal(wp(arm)).x)||1,blocking=sign===side;
   // Short bent forearm, not a fully extended palm-up "asking" gesture.
   const target=parent.localToWorld(new THREE.Vector3(sign*(blocking?.43:.28),blocking?1.04:1.02,blocking?.07:-.25));
   const relaxedHand=wq(palm);
   target.lerp(wp(palm),1-amount);
   solve(arm,lower,palm,target,parent.localToWorld(new THREE.Vector3(sign*(blocking?.61:.43),1.23,blocking?.07:-.12)));
   const neutral=wq(palm.parent).invert().multiply(relaxedHand);palm.quaternion.slerp(neutral,amount);palm.updateWorldMatrix(false,true);
  }
  model.updateWorldMatrix(true,true);
 }
 // Dedicated angled defensive steps. No reversed walk/run clip.
 function jockeyPose(velocity,side,dt,weight){
  overlayPose={};for(const [name,bone] of Object.entries(rig))overlayPose[name]={quaternion:bone.quaternion.clone(),position:bone.position.clone()};
  model.updateWorldMatrix(true,true);
  jockeyMotion.lerp(velocity,1-Math.exp(-dt*12));
  const speed=jockeyMotion.length(),activity=THREE.MathUtils.clamp(speed/1.3,0,1);
  const period=THREE.MathUtils.lerp(.72,.56,activity),stance=.62;
  if(speed>.025)jockeyPhase=(jockeyPhase+dt/period)%1;
  const local=jockeyMotion.clone().applyQuaternion(parent.getWorldQuaternion(new THREE.Quaternion()).invert());local.y=0;
  const legs=['L','R'].map((s,i)=>{
   const foot=rig['Foot'+s],end=rig['LowerLeg'+s+'_end'];
   const origin=parent.worldToLocal(wp(foot));const sign=Math.sign(origin.x)||(i?1:-1);
   const phase=(jockeyPhase+i*.5)%1,ground=speed<.025||phase<stance;
   const u=ground?phase/stance:(phase-stance)/(1-stance);
   const offset=ground?.5-u:-.5+u*u*(3-2*u);
   const point=new THREE.Vector3(sign*.18,.025,0).addScaledVector(local,period*stance*offset);
   if(!ground)point.y+=Math.sin(Math.PI*u)*.075*activity;
   let target=parent.localToWorld(point),q=wq(foot);
   let planted=jockeyFeet.get(s);
   if(!planted){planted={ground:false,point:target.clone(),q:q.clone()};jockeyFeet.set(s,planted);}
   // World-space supports stay still while the other foot takes a short step.
   // Reset anchors after teleports or an unusually large displacement.
   if(ground){
    if(!planted.ground||planted.point.distanceTo(target)>.55){planted.point.copy(target);planted.point.y=parent.localToWorld(new THREE.Vector3(0,.025,0)).y;planted.q.copy(q);}
    target.copy(planted.point);q.copy(planted.q);
   }
   planted.ground=ground;
   return {s,sign,foot,end,target,offset:wp(end).sub(wp(foot)),q};
  });
  overlayModelY=model.position.y;
  model.position.y-=.085+Math.sin(jockeyPhase*Math.PI*4)*.008*activity;
  rig.Torso.rotateX(.06);rig.Torso.rotateY(-side*.17);rig.Torso.rotateZ(THREE.MathUtils.clamp(-local.x*.025,-.04,.04));rig.Head?.rotateY(-side*.5);
  model.updateWorldMatrix(true,true);
  for(const l of legs){solve(rig['UpperLeg'+l.s],rig['LowerLeg'+l.s],l.end,l.target.clone().add(l.offset),parent.localToWorld(new THREE.Vector3(l.sign*.3,.5,-.8)));l.foot.position.copy(l.foot.parent.worldToLocal(l.target));l.foot.quaternion.copy(wq(l.foot.parent).invert().multiply(l.q));}
  // Keep elbows low and hands relaxed near the hips, with a small counter-swing.
  for(const [s,sign] of [['L',-1],['R',1]]){
   const arm=rig['UpperArm'+s],lower=rig['LowerArm'+s],palm=rig['Palm'+s];if(!palm)continue;
   const handRotation=wq(palm),swing=Math.sin(jockeyPhase*Math.PI*2)*.035*activity*sign;
   const target=parent.localToWorld(new THREE.Vector3(sign*.24,1.10+swing,-.30));
   solve(arm,lower,palm,target,parent.localToWorld(new THREE.Vector3(sign*.28,.75,.12)));
   palm.quaternion.copy(wq(palm.parent).invert().multiply(handRotation));
  }
  // Blend the entire additive pose so entering and leaving do not snap.
  for(const [name,base] of Object.entries(overlayPose)){const bone=rig[name];bone.position.lerpVectors(base.position,bone.position,weight);const posed=bone.quaternion.clone();bone.quaternion.copy(base.quaternion).slerp(posed,weight);}
  model.position.y=THREE.MathUtils.lerp(overlayModelY,model.position.y,weight);
  model.updateWorldMatrix(true,true);
 }
 function slidePose(progress){
  const ease=t=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*(3-2*t);};
  const amount=ease(progress/.16)*(1-ease((progress-.62)/.58));
  overlayPose={};for(const [name,bone] of Object.entries(rig))overlayPose[name]={quaternion:bone.quaternion.clone(),position:bone.position.clone()};
  model.updateWorldMatrix(true,true);
  const legs=['L','R'].map(s=>{const foot=rig['Foot'+s],end=rig['LowerLeg'+s+'_end'],point=wp(foot),localPoint=parent.worldToLocal(point.clone()),sign=Math.sign(localPoint.x)||1;const extended=s==='R';const destination=new THREE.Vector3(sign*(extended?.17:.32),localPoint.y,extended?-1.03:-.32);localPoint.lerp(destination,amount);return {s,sign,foot,end,target:parent.localToWorld(localPoint),offset:wp(end).sub(point),q:wq(foot)};});
  overlayModelY=model.position.y;model.position.y-=.75*amount;rig.Torso.rotateX(-.48*amount);rig.Torso.rotateZ(.13*amount);model.updateWorldMatrix(true,true);
  for(const l of legs){solve(rig['UpperLeg'+l.s],rig['LowerLeg'+l.s],l.end,l.target.clone().add(l.offset),parent.localToWorld(new THREE.Vector3(l.sign*.42,.45,-.5)));const actual=wp(l.end).sub(l.offset);l.foot.position.copy(l.foot.parent.worldToLocal(actual));l.foot.quaternion.copy(wq(l.foot.parent).invert().multiply(l.q));}
  model.updateWorldMatrix(true,true);
  for(const s of ['L','R']){const arm=rig['UpperArm'+s],lower=rig['LowerArm'+s],palm=rig['Palm'+s];if(!palm)continue;const sign=Math.sign(parent.worldToLocal(wp(arm)).x)||1;const target=parent.localToWorld(new THREE.Vector3(sign*.46,s==='L'?.25:.75,s==='L'?.22:-.12));target.lerp(wp(palm),1-amount);solve(arm,lower,palm,target,parent.localToWorld(new THREE.Vector3(sign*.7,.6,.1)));}
  model.updateWorldMatrix(true,true);
 }
 function setAppearance(profile){
  if(!ready)return;
  const color=new THREE.Color(profile.skinTone||'#754a36');sockStyle?.update(profile);
  model.traverse(o=>{if(!o.isMesh||!o.geometry.userData.skinIndices)return;const colors=o.geometry.attributes.color;for(const i of o.geometry.userData.skinIndices)colors.setXYZ(i,color.r,color.g,color.b);colors.needsUpdate=true;});
  if(paris){paintParisKit(kitCanvas,options.number??10,(profile.lastName||'PARIS').toLocaleUpperCase('fr'));tex.needsUpdate=true;}
  model.userData.profile={...profile};
 }
 return {greet(target,amount=1){if(!ready||!rig.PalmR)return;if(!overlayPose){overlayPose={};for(const [name,bone] of Object.entries(rig))overlayPose[name]={quaternion:bone.quaternion.clone(),position:bone.position.clone()};}model.updateWorldMatrix(true,true);const palm=rig.PalmR;const dest=wp(palm).lerp(target,amount);const pole=wp(rig.UpperArmR).add(new THREE.Vector3(.4,-.3,.1));solve(rig.UpperArmR,rig.LowerArmR,palm,dest,pole);},setAppearance,promise,get ready(){return ready},get model(){return model},get kicking(){return kickTime>0},get locomotion(){return active},get motionBlend(){return {jockey:jockeyBlend,...blendWeights,speed:smoothSpeed,turnLean,forwardLean,idleBreath,breathLift,exertion}},get kickProgress(){return kickTime>0?1-kickTime/kickDuration:1},
 kick(atContact=false){restoreOverlay();kickTime=kickDuration-(atContact?kickContact:0);},
 reset(){restoreOverlay();jockeyBlend=0;jockeyPhase=0;jockeyMotion.set(0,0,0);jockeyFeet.clear();idleBreath=0;exertion=0;breathLift=0;kickTime=0;tracked=false;smoothSpeed=0;turnLean=0;forwardLean=0;for(const k of Object.keys(blendWeights))blendWeights[k]=k==='idle'?1:0;if(!ready)return;for(const action of Object.values(actions))action.stop();for(const [k,a] of Object.entries(actions))a.reset().setEffectiveWeight(k==='idle'?1:0).play();active='idle';mixer.update(0);},
 update(dt,{moving=false,sprint=false,walk=false,goal=false,shield=0,shieldSide=1,slide=-1,jockey=false,jockeySide=1,jockeyVelocity=null}={}){
 if(!ready)return;
 restoreOverlay();poseAge+=dt;
 jockeyBlend=THREE.MathUtils.damp(jockeyBlend,jockey&&slide<0&&kickTime<=0?1:0,jockey?12:16,dt);
 if(jockeyBlend<.002){jockeyBlend=0;jockeyFeet.clear();jockeyMotion.set(0,0,0);}

 parent.getWorldPosition(world);parent.getWorldQuaternion(worldRotation);
 const elapsed=Math.max(.001,dt),distance=world.distanceTo(lastWorld);
 let speed=tracked&&distance<2?distance/elapsed:0;
 localVelocity.copy(world).sub(lastWorld).divideScalar(elapsed).applyQuaternion(worldRotation.clone().invert());
 if(!tracked||distance>=2)localVelocity.set(0,0,0);
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(worldRotation),heading=Math.atan2(forward.x,forward.z);
 const turn=tracked?Math.atan2(Math.sin(heading-lastHeading),Math.cos(heading-lastHeading))/elapsed:0;
 lastHeading=heading;lastWorld.copy(world);tracked=true;
 if(moving&&speed<.03)speed=sprint?5.8:walk?1.6:3.8;
 if(!moving)speed=0;
 const previousSpeed=smoothSpeed;smoothSpeed=THREE.MathUtils.lerp(smoothSpeed,Math.min(speed,8),1-Math.exp(-dt*12));
 const slow=moving&&(walk||shield>.15||speed<(active==='walk'?2.6:1.8));
 const wanted=slide>=0||jockey?'idle':goal?'clap':moving?(slow?'walk':'run'):'idle';active=wanted;
 // Keep cycles alive and blend weights instead of restarting a stride every turn.
 for(const [name,action] of Object.entries(actions)){
  blendWeights[name]=THREE.MathUtils.lerp(blendWeights[name],name===wanted?1:0,1-Math.exp(-dt*(slide>=0?25:16)));
  action.setEffectiveWeight(blendWeights[name]);
 }
 if(actions.run)actions.run.timeScale=THREE.MathUtils.clamp((smoothSpeed||3.8)/4.2,.55,1.55);
 if(actions.walk)actions.walk.timeScale=THREE.MathUtils.clamp((smoothSpeed||1.6)/1.8,.6,1.65);
 turnLean=THREE.MathUtils.lerp(turnLean,THREE.MathUtils.clamp(-turn*smoothSpeed*.012,-.09,.09),1-Math.exp(-dt*9));
 const acceleration=(smoothSpeed-previousSpeed)/elapsed;
 forwardLean=THREE.MathUtils.lerp(forwardLean,THREE.MathUtils.clamp(smoothSpeed*.009+acceleration*.0025,-.025,.09),1-Math.exp(-dt*10));
 exertion=THREE.MathUtils.damp(exertion,moving?Math.min(1,speed/6.5):0,moving?1.5:.17,dt);
 idleBreath=THREE.MathUtils.damp(idleBreath,!moving&&!goal&&shield<.005&&kickTime<=0&&slide<0?1:0,moving?20:3.5,dt);
 breathPhase+=dt*(1.8+exertion*.7);breathLift=0;
 mixer.update(dt);
 if(slide>=0){kickTime=0;slidePose(slide);return;}
 if(jockeyBlend>.002&&jockeyVelocity&&kickTime<=0){jockeyPose(jockeyVelocity,jockeySide,dt,jockeyBlend);return;}
 if(kickTime>0&&!goal){
  kickTime=Math.max(0,kickTime-dt);const p=1-kickTime/kickDuration;
  if(kickTime===0)return;
  overlayPose={};for(const [name,bone] of Object.entries(rig))if(bone)overlayPose[name]={quaternion:bone.quaternion.clone(),position:bone.position.clone()};
  model.updateWorldMatrix(true,true);
  const lower=rig.LowerLegR,foot=rig.FootR;
  const footOffset=lower.worldToLocal(foot.getWorldPosition(new THREE.Vector3()));
  const lowerBefore=lower.getWorldQuaternion(new THREE.Quaternion());
  const footBefore=foot.getWorldQuaternion(new THREE.Quaternion());
  const [hipAngle,kneeAngle,lean]=sampleKick(p);
  const plant=Math.sin(Math.PI*p)*.85;rig.UpperLegR.quaternion.slerp(kickRest.UpperLegR,plant);lower.quaternion.slerp(kickRest.LowerLegR,plant);
  rig.UpperLegR.rotateX(hipAngle);lower.rotateX(kneeAngle);
  rig.Torso.rotateX(lean);
  const balance=Math.sin(p*Math.PI);rig.UpperArmL.rotateZ(-balance*.16);rig.UpperArmR.rotateZ(balance*.20);
  model.updateWorldMatrix(true,true);
  // In this FBX the foot is a separate bone, not a child of the calf.
  // Carry it with the knee chain to prevent a pinned foot and a stretched leg.
  const footWorld=lower.localToWorld(footOffset.clone());
  foot.position.copy(foot.parent.worldToLocal(footWorld));
  const delta=lower.getWorldQuaternion(new THREE.Quaternion()).multiply(lowerBefore.clone().invert());
  const parentInverse=foot.parent.getWorldQuaternion(new THREE.Quaternion()).invert();
  foot.quaternion.copy(parentInverse.multiply(delta.multiply(footBefore)));
  model.updateWorldMatrix(true,true);
 }else if(goal){kickTime=0;}else if(shield>.005){shieldPose(shield,shieldSide,moving);}
 else if(!isKeeper&&rig.Torso){
  // Upper-body-only balance: never rotate the entire model or its planted feet.
  overlayPose={};for(const name of ['Torso','Head','UpperArmL','UpperArmR','LowerArmL','LowerArmR'])if(rig[name])overlayPose[name]={quaternion:rig[name].quaternion.clone(),position:rig[name].position.clone()};
  const wave=(1-Math.cos(breathPhase))*.5,amplitude=idleBreath*(1+exertion*.3);
  const breath=(wave-.5)*.085*amplitude;
  model.updateWorldMatrix(true,true);
  // Lift only the chest, not the character root: feet and camera stay fixed.
  breathLift=wave*.035*amplitude;
  const chest=wp(rig.Torso);chest.y+=breathLift;
  rig.Torso.position.copy(rig.Torso.parent.worldToLocal(chest));
  rig.Torso.rotateX(forwardLean+breath);rig.Torso.rotateZ(turnLean);
  for(const [side,sign] of [['L',-1],['R',1]]){
   rig['UpperArm'+side]?.rotateZ(sign*(wave*.075+.018)*amplitude);
   rig['LowerArm'+side]?.rotateX((.06+Math.sin(breathPhase-.35)*.045)*amplitude);
  }
  if(rig.Head){rig.Head.rotateX(-forwardLean*.25-breath*.35);rig.Head.rotateZ(-turnLean*.35);}

 }
 }};
}
