import {createDuelSequence} from './duel-sequence.js';
import {turnToward,defensiveFacing} from './movement-facing.js';
import * as THREE from 'three';
import {createProbeNavigator,openShotTarget} from './probe-navigation.js';
import {laneClear,steerAvoid} from './tactics.js';
import {createFootballer} from './character.js?v=duels2';
export function createDefender(scene,options={}){
 const root=new THREE.Group(),body=new THREE.Group();scene.add(root);root.add(body);root.position.set((options.x??-2)*1.7,0,(options.z??-8)*1.640625);
 const avatar=createFootballer(body,{number:options.number??4,opponent:true});
 const direction=new THREE.Vector3(0,0,1),velocity=new THREE.Vector3();
 const duelSequence=createDuelSequence();const navigator=createProbeNavigator();root.userData.velocity=velocity;const retreat=new THREE.Vector3();let tackleStyle='stand',tackleCount=0,slideFinish=-1;let chosenAction=null,shotTarget=null;let flank=options.number===9?-1:1,flankTime=0;let jockeying=false,jockeySide=1,jockeyTurn=0;let state='mark',phase=0,rest=1.0,won=false,clearTime=0,kicked=false;
 const ring=new THREE.Mesh(new THREE.RingGeometry(.46,.50,40),new THREE.MeshBasicMaterial({color:'#f18b76',transparent:true,opacity:.7,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.076;root.add(ring);
 const canvas=document.createElement('canvas');canvas.width=256;canvas.height=64;const ctx=canvas.getContext('2d');ctx.fillStyle='#743a32';ctx.beginPath();ctx.roundRect(0,0,256,64,16);ctx.fill();ctx.fillStyle='#fff0df';ctx.font='bold 24px Arial';ctx.textAlign='center';ctx.fillText((options.number??4)+' · ADVERSAIRE',128,41);const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;const label=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,depthTest:false}));label.position.y=2.27;label.scale.set(1.65,.41,1);root.add(label);
 function reset(){duelSequence.reset();jockeying=false;jockeyTurn=0;tackleStyle='stand';tackleCount=0;slideFinish=-1;navigator.reset();root.position.set((options.x??-2)*1.7,0,(options.z??-8)*1.640625);root.rotation.set(0,Math.PI,0);direction.set(0,0,1);velocity.set(0,0,0);body.rotation.set(0,0,0);body.position.y=0;state='mark';phase=0;rest=1.0;clearTime=0;kicked=false;won=false;avatar.reset();}
 function receive(){if(state==='tackle'&&tackleStyle==='slide')slideFinish=Math.min(.9,phase/.8);navigator.reset();chosenAction=null;won=true;clearTime=0;kicked=false;velocity.multiplyScalar(.85);state='control';phase=0;}
 function intercept(a,b){if(rest>0||state==='recover'||state==='tackle'||state==='control'||state==='clear')return false;const v=b.clone().sub(a),t=THREE.MathUtils.clamp(root.position.clone().sub(a).dot(v)/Math.max(.001,v.lengthSq()),0,1),point=a.clone().addScaledVector(v,t);return point.y<.75&&Math.hypot(point.x-root.position.x,point.z-root.position.z)<.72;}
 function update(dt,c){
  if(!avatar.ready||dt<=0)return null;const frameStart=root.position.clone();rest=Math.max(0,rest-dt);phase+=dt;let result=null;
  if(options.simpleDuel){
   if(!c.active){velocity.set(0,0,0);avatar.update(dt);return null;}
   const carrier=c.carrierRoot;
   const gap=Math.hypot(c.ball.x-root.position.x,c.ball.z-root.position.z);
   let facingDuel=false;
   if(carrier){const toward=root.position.clone().sub(carrier.position);toward.y=0;const forward=new THREE.Vector3(0,0,-1).applyQuaternion(carrier.quaternion);facingDuel=toward.normalize().dot(forward)>(jockeying?.2:.5);}
   const wasJockey=jockeying;
   const fixing=!!(!c.owns&&!c.free&&carrier&&facingDuel&&c.ball.z>root.position.z-.4&&gap<(duelSequence.mode==='idle'?4:8));
   const seq=duelSequence.update(dt,{position:root.position,ball:c.ball,fixing,free:c.free,owns:c.owns});
   if((seq.mode==='press'||seq.mode==='idle')&&!c.owns&&c.canChallenge!==false&&gap<1.4&&c.ball.y<.7&&rest<=0){if(duelSequence.beginTackle()){avatar.kick();tackleCount++;tackleStyle='stand';}}
   const stage=duelSequence.mode;
   jockeying=stage==='retreat'||stage==='plant';
   if(jockeying&&!wasJockey){jockeySide=carrier&&carrier.position.x-root.position.x>.1?-1:1;jockeyTurn=Math.atan2(-direction.x,-direction.z);}
   const frozen=c.owns||stage==='plant'||stage==='tackle'||stage==='recover';
   const destination=frozen?root.position.clone():new THREE.Vector3(
    THREE.MathUtils.clamp(c.ball.x+(jockeying?jockeySide*.3:0),-32,32),0,
    stage==='retreat'?seq.retreatZ:THREE.MathUtils.clamp(c.ball.z-(c.free?0:.65),-49,49));
   const travel=destination.sub(root.position);travel.y=0;const distance=travel.length();
   const speed=stage==='retreat'?1.8:stage==='press'?4.4:3.2;
   if(distance>.015)travel.multiplyScalar(Math.min(distance,speed*dt)/distance);else travel.set(0,0,0);
   root.position.add(travel);velocity.copy(travel).divideScalar(dt);
   const moving=travel.lengthSq()>.000001;
   state=stage==='tackle'?'tackle':stage==='press'?'press':stage==='plant'?'plant':stage==='recover'?'recover':jockeying?'jockey':moving?'duel':'hold';
   if(moving&&!jockeying){direction.copy(travel).normalize();root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);}
   if(jockeying){const toBall=c.ball.clone().sub(root.position);toBall.y=0;const yaw=Math.atan2(-toBall.x,-toBall.z)+jockeySide*Math.PI/4;const diff=Math.atan2(Math.sin(yaw-jockeyTurn),Math.cos(yaw-jockeyTurn));jockeyTurn+=diff*(1-Math.exp(-dt*12));root.rotation.set(0,jockeyTurn,0);direction.set(-Math.sin(jockeyTurn),0,-Math.cos(jockeyTurn));}
   if(stage==='tackle'){direction.copy(c.ball).sub(root.position);direction.y=0;direction.normalize();root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);}
   avatar.update(dt,{moving,sprint:stage==='press',jockey:jockeying,jockeySide,jockeyVelocity:velocity});
   if(seq.contact){rest=1.05;if(c.canChallenge!==false&&!c.protected&&!c.owns&&c.ball.y<.7&&Math.hypot(c.ball.x-root.position.x,c.ball.z-root.position.z)<1.5)return 'win';}
   if(c.owns){clearTime+=dt;if(clearTime>1){clearTime=0;avatar.kick();return 'shoot';}}else clearTime=0;
   return null;
  }
  if(!c.active){velocity.set(0,0,0);body.rotation.z*=Math.exp(-dt*9);body.position.y*=Math.exp(-dt*9);avatar.update(dt,{});return null;}
  if(c.owns){
   clearTime+=dt;body.rotation.z*=Math.exp(-dt*10);body.position.y*=Math.exp(-dt*10);
   const enemies=c.enemies||[],ally=c.ally,goal=new THREE.Vector3(0,0,52.5);
   const pressure=Math.min(...enemies.map(o=>root.position.distanceTo(o.position)));
   const passDistance=ally?root.position.distanceTo(ally.position):99;
   const canPass=ally&&passDistance>4&&passDistance<55&&laneClear(root.position,ally.position,enemies,1.0);
   const shootingLane=openShotTarget(root.position,52.5,enemies);
   const canShoot=52.5-root.position.z<17&&Math.abs(root.position.x)<8&&!!shootingLane;
   const route=navigator.update(dt,root.position,goal,c.obstacles||enemies);
   let desired=route.direction.clone().multiplyScalar(3.9*route.speed);if(c.teamGrid)desired=c.teamGrid.steer(root,desired);
   if(chosenAction){state=chosenAction;velocity.multiplyScalar(Math.exp(-dt*1.3));root.position.addScaledVector(velocity,dt);if(phase>.095){result=chosenAction;chosenAction=null;state='follow';phase=0;rest=.55;}}
   else if(clearTime<.12){state='control';velocity.multiplyScalar(Math.exp(-dt*4));root.position.addScaledVector(velocity,dt);}
   else if(clearTime>.4&&canPass&&!canShoot&&(route.trapped||route.blocked||pressure<3||ally.position.z>root.position.z+3.5&&clearTime>.65||root.position.x*ally.position.x< -55&&clearTime>1||clearTime>2.5)){chosenAction='pass';phase=0;avatar.kick();direction.copy(ally.position).sub(root.position).normalize();}
   else if(clearTime>.24&&canShoot){chosenAction='shoot';shotTarget=shootingLane;phase=0;direction.copy(shotTarget).sub(root.position).normalize();avatar.kick();}
   else{state='carry';velocity.lerp(desired,1-Math.exp(-dt*7));root.position.addScaledVector(velocity,dt);turnToward(direction,velocity,dt);}
   if(chosenAction&&phase===0)root.position.addScaledVector(velocity,dt);
  }else if(state==='follow'){velocity.multiplyScalar(Math.exp(-dt*3));root.position.addScaledVector(velocity,dt);if(phase>.16){state='mark';phase=0;}
  }else if(state==='tackle'){
   // Committed standing tackle: a short lunge, a foot contact window, then recovery.
   // The direction is locked, so a late pass or sidestep can beat the defender.
   const before=root.position.clone();root.position.addScaledVector(direction,dt*5.8*Math.max(0,1-phase/.55));
   if(c.canChallenge!==false&&!won&&phase>(tackleStyle==='slide'?.22:.10)&&phase<.55&&c.ball.y<.72){const foot=root.position.clone().addScaledVector(direction,.78),start=before.clone().addScaledVector(direction,.35),segment=foot.clone().sub(start);const t=THREE.MathUtils.clamp(c.ball.clone().sub(start).dot(segment)/Math.max(.001,segment.lengthSq()),0,1);const near=start.addScaledVector(segment,t);if(Math.hypot(near.x-c.ball.x,near.z-c.ball.z)<(c.protected?.46:.78)){won=true;result='win';}}
   body.rotation.z=.13*Math.sin(Math.min(1,phase/.62)*Math.PI);body.position.y=-.07*Math.sin(Math.min(1,phase/.62)*Math.PI);
   if(phase>(tackleStyle==='slide'?.8:.62)){state='recover';phase=0;rest=1.5;}
  }else if(state==='recover'){
   root.position.addScaledVector(retreat,dt*1.5*Math.max(0,1-phase));velocity.multiplyScalar(Math.exp(-dt*10));body.rotation.z*=Math.exp(-dt*10);body.position.y*=Math.exp(-dt*10);if(phase>1.05){state='mark';phase=0;}
  }else{
   body.rotation.z*=Math.exp(-dt*10);body.position.y*=Math.exp(-dt*10);
   const target=c.ball.clone();target.y=0;
   if(c.ball.z>8){target.set(c.ball.x*.65,0,4.5);state='mark';}else{target.addScaledVector(c.ballVelocity,c.free?.16:0);state=c.free?'intercept':'press';}
   target.x=THREE.MathUtils.clamp(target.x,-32.4,32.4);target.z=THREE.MathUtils.clamp(target.z,-49.2,48.5);
   if(c.coverTarget){target.copy(c.coverTarget);target.y=0;state='mark';}
   if(c.allyOwns){target.set(options.lane??(c.ball.x>0?-6:6),0,Math.min(26,c.ball.z+(options.depth??5)));state='support';}
   if(c.supportPlan&&!c.owns){target.copy(c.supportPlan.target);state=c.supportPlan.kind;}
   if(c.defensePlan&&!c.owns&&!c.allyOwns){target.copy(c.defensePlan.target);state=c.defensePlan.kind;}
   if(c.shieldCenter){
    // Walk an arc around the body rather than pushing straight through it.
    flankTime+=dt;if(flankTime>2.3){flank*=-1;flankTime=0;}
    const away=root.position.clone().sub(c.shieldCenter);away.y=0;if(away.length()<.01)away.set(1,0,0);away.normalize();
    const angle=flank*.85,cs=Math.cos(angle),sn=Math.sin(angle);target.copy(c.shieldCenter).add(new THREE.Vector3(away.x*cs-away.z*sn,0,away.x*sn+away.z*cs).multiplyScalar(1.24));state='circle';
   }else flankTime=0;
   const delta=target.sub(root.position);const distance=delta.length();const desired=delta.normalize().multiplyScalar(Math.min(c.supportPlan?c.supportPlan.speed:c.defensePlan?c.defensePlan.speed:c.shieldCenter?1.8:rest>0?3.1:4.45,distance*3));velocity.lerp(steerAvoid(root.position,c.teamGrid?c.teamGrid.steer(root,desired):desired,(c.obstacles||[]).filter(o=>!(c.defensePlan?.pressing&&o===c.carrierRoot)),1.7).clampLength(0,c.defensePlan?.speed||4.45),1-Math.exp(-dt*7));root.position.addScaledVector(velocity,dt);
   const face=defensiveFacing(root.position,velocity,c.ball);turnToward(direction,face,dt);
   const gap=Math.hypot(c.ball.x-root.position.x,c.ball.z-root.position.z);
   if(!c.supportPlan&&c.canChallenge!==false&&!c.allyOwns&&!c.coverTarget&&rest<=0&&gap<1.8&&direction.dot(c.ball.clone().sub(root.position).normalize())>.2&&c.ball.y<.7&&(!c.shieldCenter||phase>1.1)){tackleCount++;tackleStyle=tackleCount%2===1&&gap>1.15?'slide':'stand';state='tackle';phase=0;won=false;direction.copy(c.ball).sub(root.position);direction.y=0;direction.normalize();velocity.set(0,0,0);if(tackleStyle==='stand')avatar.kick();}
  }
  if(c.shieldCenter){const away=root.position.clone().sub(c.shieldCenter);away.y=0;const gap=away.length();if(gap<.83&&gap>.001)root.position.copy(c.shieldCenter).addScaledVector(away,.83/gap);root.position.y=0;}
  root.position.x=THREE.MathUtils.clamp(root.position.x,-33,33);root.position.z=THREE.MathUtils.clamp(root.position.z,-49.5,49.5);// Use the real displacement, including recovery and steering, not the
  // tactical velocity (which can point elsewhere during a state change).
  const travel=root.position.clone().sub(frameStart);travel.y=0;
  if(travel.lengthSq()>dt*dt*.01)direction.copy(travel).normalize();
  root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);
  if(slideFinish>=0){slideFinish+=dt*2.2;if(slideFinish>=1)slideFinish=-1;}
  avatar.update(dt,{slide:state==='tackle'&&tackleStyle==='slide'?Math.min(1,phase/.8):slideFinish,moving:travel.lengthSq()>dt*dt*.01,sprint:velocity.length()>4});
  return result;
 }
 return {get duelPhase(){return duelSequence.mode},get duelRetreatDistance(){return duelSequence.retreatDistance},get tackleStyle(){return tackleStyle},get tackleCount(){return tackleCount},get shotTarget(){return shotTarget},navigator,number:options.number??4,root,avatar,direction,velocity,promise:avatar.promise,reset,receive,update,intercept,repel(from){chosenAction=null;state='recover';phase=0;rest=1.35;won=false;retreat.copy(from?root.position.clone().sub(from):direction.clone().negate());retreat.y=0;if(retreat.lengthSq()<.01)retreat.set(flank,0,-1);retreat.normalize();velocity.multiplyScalar(.2);},get state(){return state},get status(){return {plant:'Prend appui avant de presser',jockey:'Recul de trois quarts',duel:'Se déplace vers le ballon',hold:'Tient la ligne',screen:'Coupe la ligne de passe',cover:'Protège le but',wide:'Garde son couloir',unmark:'Sort du marquage',run:'Appel diagonal',balance:'Soutien en retrait',pass:'Cherche son partenaire',circle:'Contourne le porteur',carry:'Monte à l’attaque',support:'Fait un appel',shoot:'Prépare sa frappe',mark:'Ferme les espaces',press:'Presse le porteur',intercept:'Coupe la passe',tackle:'Tente le tacle',recover:'Se replace',control:'Prépare le dégagement',clear:'Dégage !'}[state]||'En défense'}};
}
