// Browser Gamepad API, standard Xbox / PlayStation layout. No external service.
export function createGamepadControls(callbacks){
 const state={connected:false,active:false,id:'',layout:'xbox',moveX:0,moveY:0,sprint:false,protect:false,finesse:false,chip:false,mapping:'',blocked:false};
 let index=null,previous=[],identity='',lastUsed=-999,lastPad=null,enabled=true;
 const button=(p,i)=>!!p.buttons[i]&&(p.buttons[i].pressed||p.buttons[i].value>.5);
 function analog(p,i){return p.buttons[i]?.value??(p.buttons[i]?.pressed?1:0);}
 function stick(x,y){const len=Math.hypot(x,y),dead=.17;if(len<=dead)return [0,0];const amount=Math.min(1,(len-dead)/(1-dead));return [x/len*amount,y/len*amount];}
 function clear(){state.moveX=state.moveY=0;state.sprint=state.protect=state.finesse=state.chip=false;state.active=false;previous=[];}
 function disconnect(){const was=state.connected;state.connected=false;state.id='';index=null;lastPad=null;clear();if(was)callbacks.onDisconnect?.();}
 const controls={state,
 poll(now){
  if(!enabled){clear();return;}
  let pads;try{pads=navigator.getGamepads?Array.from(navigator.getGamepads()):[];}catch(e){if(!state.blocked){state.blocked=true;callbacks.onUnavailable?.(e);}disconnect();return;}
  let p=pads.find(p=>p&&p.index===index&&p.connected!==false);
  if(!p)p=pads.find(p=>p&&p.connected!==false&&p.mapping==='standard')||pads.find(p=>p&&p.connected!==false);
  if(!p){disconnect();return;}
  lastPad=p;
  const nextIdentity=p.index+':'+p.id;
  if(!state.connected||nextIdentity!==identity){identity=nextIdentity;index=p.index;previous=[];state.connected=true;state.id=p.id;state.mapping=p.mapping;state.layout=!/xbox|xinput|045e/i.test(p.id)&&/playstation|dualsense|dualshock|054c|wireless controller/i.test(p.id)?'ps':'xbox';callbacks.onConnect?.(state);}
  const buttons=Array.from({length:17},(_,i)=>button(p,i));
  const down=i=>buttons[i]&&!previous[i],up=i=>!buttons[i]&&previous[i];
  [state.moveX,state.moveY]=stick(p.axes[0]||0,p.axes[1]||0);
  state.sprint=analog(p,7)>.25;state.protect=analog(p,6)>.25;state.chip=buttons[4];state.finesse=buttons[5];
  if(Math.hypot(state.moveX,state.moveY)>.01||buttons.some(Boolean))lastUsed=now;
  state.active=now-lastUsed<8;
  const mode=callbacks.mode();
  if(down(9)){callbacks.onMenu();previous=buttons;return;}
  if(down(8)){callbacks.onHelp();previous=buttons;return;}
  if(mode==='intro'){if(down(0))callbacks.onStart();previous=buttons;return;}
  if(mode==='paused'){if(down(0)||down(1))callbacks.onResume();previous=buttons;return;}
  const mapping=[[1,'shoot'],[0,'pass'],[2,'cross'],[3,'through']];
  for(const [i,kind] of mapping){if(down(i))callbacks.onCharge(kind);if(up(i))callbacks.onRelease(kind,{chip:state.chip||!!previous[4],finesse:state.finesse||!!previous[5]});}
  if(down(10))callbacks.onRun?.();
  if(down(11))callbacks.onCamera();
  previous=buttons;
 },
 pulse(strong=.35,duration=150){try{const actuator=lastPad?.vibrationActuator;if(actuator?.playEffect)actuator.playEffect('dual-rumble',{startDelay:0,duration,strongMagnitude:strong,weakMagnitude:strong*.65}).catch(()=>{});}catch{}},
 setEnabled(value){enabled=value;clear();},
 clear,
 };
 return controls;
}
