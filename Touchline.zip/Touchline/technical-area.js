import * as THREE from 'three';
export function createTechnicalArea(scene){
 const group=new THREE.Group();group.name='TeamDugouts';scene.add(group);
 const steel=new THREE.MeshStandardMaterial({color:'#d1d9d6',metalness:.55,roughness:.4});
 const shell=new THREE.MeshStandardMaterial({color:'#a9c9cf',transparent:true,opacity:.3,roughness:.25,side:THREE.DoubleSide,depthWrite:false});
 const dark=new THREE.MeshStandardMaterial({color:'#31433e',roughness:.85});
 function box(parent,x,y,z,w,h,d,mat){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=mat!==shell;m.receiveShadow=true;parent.add(m);return m;}
 for(const [team,z,color] of [['BLEUS',8.5,'#176eb0'],['ROUGES',-8.5,'#b93832']]){
  const bench=new THREE.Group();bench.name='Banc_'+team;bench.position.set(37.8,0,z);bench.userData={team,seats:7};group.add(bench);
  const seats=new THREE.MeshStandardMaterial({color,roughness:.65});
  box(bench,0,.035,0,2,.07,7.9,dark);
  for(const x of [-.87,.87])for(const zz of [-3.7,3.7])box(bench,x,1.08,zz,.055,2.16,.055,steel);
  box(bench,.9,1.25,0,.035,1.8,7.4,shell);
  for(const zz of [-3.7,3.7]){box(bench,0,1.27,zz,1.8,1.78,.035,shell);box(bench,0,2.16,zz,1.85,.055,.06,steel);}
  for(const x of [-.89,.89])box(bench,x,2.16,0,.055,.06,7.45,steel);
  const roof=box(bench,0,2.21,0,2,.055,7.65,shell);roof.rotation.z=.08;
  box(bench,.13,.37,0,.09,.12,6.5,steel);
  for(let i=0;i<7;i++){
   const zz=(i-3)*.9;
   box(bench,.05,.5,zz,.64,.12,.69,seats);box(bench,.34,.84,zz,.12,.66,.69,seats);
   box(bench,.16,.25,zz,.07,.47,.07,steel);
   for(const side of [-1,1])box(bench,-.04,.75,zz+side*.37,.64,.065,.055,steel);
  }
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=80;const ctx=canvas.getContext('2d');ctx.fillStyle=color;ctx.fillRect(0,0,512,80);ctx.fillStyle='#f4f3e5';ctx.font='bold 32px Arial';ctx.textAlign='center';ctx.fillText(team+' · REMPLAÇANTS',256,53);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  const sign=new THREE.Mesh(new THREE.PlaneGeometry(6.3,.45),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}));sign.rotation.y=-Math.PI/2;sign.position.set(-.92,2.12,0);bench.add(sign);
  // Dashed technical-area markings, outside the 40 × 64 m playing field.
  const paint=new THREE.MeshBasicMaterial({color:'#e2e8d5'});
  for(let zz=-4.3;zz<=4.3;zz+=.7)box(bench,-2.1,.035,zz,.055,.012,.4,paint);
  for(const zz of [-4.5,4.5])for(let x=-2.1;x<1.2;x+=.7)box(bench,x,.035,zz,.4,.012,.055,paint);
 }
 return group;
}
