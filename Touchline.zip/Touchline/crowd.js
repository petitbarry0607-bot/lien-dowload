import * as THREE from 'three';
// Static, textured cut-outs merged into ONE draw call. No bones, physics,
// per-frame updates, transparency sorting, or individual spectator objects.
export function addCrowd(stadium){
 const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=128;const ctx=canvas.getContext('2d');
 let seed=1049;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 const shirts=['#182f56','#244a81','#e7e3da','#b73238','#394753','#d1c3a0','#22262d','#4786a4'];
 const skins=['#e4b88d','#c38b61','#936042','#623e2c'];
 for(let i=0;i<16;i++){
  const x=i*64;ctx.save();ctx.translate(x,0);const skin=skins[i%4],shirt=shirts[i%8];
  ctx.fillStyle='#252c39';ctx.fillRect(17,89,13,34);ctx.fillRect(34,89,13,34);
  const gradient=ctx.createLinearGradient(12,0,51,0);gradient.addColorStop(0,shirt);gradient.addColorStop(.6,shirt);gradient.addColorStop(1,'#202d3c');ctx.fillStyle=gradient;ctx.beginPath();ctx.moveTo(18,43);ctx.lineTo(46,43);ctx.lineTo(51,91);ctx.quadraticCurveTo(32,99,13,91);ctx.closePath();ctx.fill();
  ctx.strokeStyle=shirt;ctx.lineWidth=11;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(19,50);ctx.lineTo(i%4===0?5:10,i%4===0?24:78);ctx.moveTo(45,50);ctx.lineTo(i%5===0?60:54,i%5===0?22:79);ctx.stroke();
  ctx.strokeStyle=skin;ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(i%4===0?5:10,i%4===0?24:78);ctx.lineTo(i%4===0?7:22,i%4===0?14:89);ctx.moveTo(i%5===0?60:54,i%5===0?22:79);ctx.lineTo(i%5===0?58:43,i%5===0?12:89);ctx.stroke();
  ctx.fillStyle=skin;ctx.fillRect(27,33,10,14);ctx.beginPath();ctx.ellipse(32,26,12,16,0,0,Math.PI*2);ctx.fill();ctx.fillStyle=i%3?'#24211e':'#655044';ctx.beginPath();ctx.ellipse(32,17,12,8,0,Math.PI,2*Math.PI);ctx.fill();
  ctx.fillStyle='#302723';ctx.fillRect(26,26,3,2);ctx.fillRect(36,26,3,2);ctx.fillStyle='#7e5140';ctx.fillRect(29,35,7,2);
  if(i%3===0){ctx.fillStyle='#d12e40';ctx.fillRect(23,45,6,30);ctx.fillStyle='#e5e5d9';ctx.fillRect(36,45,5,28);}
  ctx.restore();
 }
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=2;
 const points=[],used=new Set(),a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),normal=new THREE.Vector3(),ab=new THREE.Vector3(),ac=new THREE.Vector3();
 stadium.updateMatrixWorld(true);
 for(const mesh of stadium.children){
  if(!mesh.isMesh)continue;const hsl={};mesh.material.color.getHSL(hsl);if(hsl.s<.22||hsl.l<.08)continue;
  const pos=mesh.geometry.attributes.position;
  for(let i=0;i<pos.count;i+=3){
   a.fromBufferAttribute(pos,i);b.fromBufferAttribute(pos,i+1);c.fromBufferAttribute(pos,i+2);
   normal.crossVectors(ab.copy(b).sub(a),ac.copy(c).sub(a)).normalize();if(normal.y<0)normal.negate();if(normal.y<.24||normal.y>.98)continue;
   const mx=(a.x+b.x+c.x)/3,mz=(a.z+b.z+c.z)/3;
   if(normal.x*mx+normal.z*mz>-.2)continue;
   const determinant=(b.z-c.z)*(a.x-c.x)+(c.x-b.x)*(a.z-c.z);if(Math.abs(determinant)<.1)continue;
   const minX=Math.min(a.x,b.x,c.x),maxX=Math.max(a.x,b.x,c.x),minZ=Math.min(a.z,b.z,c.z),maxZ=Math.max(a.z,b.z,c.z);
   for(let x=Math.ceil(minX/1.12)*1.12;x<=maxX;x+=1.12)for(let z=Math.ceil(minZ/1.18)*1.18;z<=maxZ;z+=1.18){
    const u=((b.z-c.z)*(x-c.x)+(c.x-b.x)*(z-c.z))/determinant,v=((c.z-a.z)*(x-c.x)+(a.x-c.x)*(z-c.z))/determinant,w=1-u-v;
    if(u<.025||v<.025||w<.025)continue;const y=u*a.y+v*b.y+w*c.y;
    if(y<.15||y>38||Math.max(Math.abs(x)/34,Math.abs(z)/52.5)<1.17)continue;
    const key=Math.round(x/1.12)+','+Math.round(z/1.18)+','+Math.round(y/1.2);if(used.has(key))continue;used.add(key);
    if(random()<.13)continue;points.push({x,y,z,tile:Math.floor(random()*16),scale:.9+random()*.22});
   }
  }
 }
 // Randomise once so the lightweight subset stays spread across all stands.
 for(let i=points.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[points[i],points[j]]=[points[j],points[i]];}
 const capacity=Math.min(6000,points.length),geometry=new THREE.PlaneGeometry(.8,1.37);
 const tiles=new Float32Array(capacity);geometry.setAttribute('crowdTile',new THREE.InstancedBufferAttribute(tiles,1));
 const material=new THREE.MeshBasicMaterial({map:texture,alphaTest:.45,side:THREE.DoubleSide,toneMapped:false});
 material.onBeforeCompile=shader=>{shader.vertexShader='attribute float crowdTile;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <uv_vertex>','#include <uv_vertex>\nvMapUv.x = (vMapUv.x * 0.984375 + crowdTile + 0.0078125) / 16.0;');};
 material.customProgramCacheKey=()=> 'crowd-atlas-instanced-v2';
 const crowd=new THREE.InstancedMesh(geometry,material,capacity),dummy=new THREE.Object3D();
 for(let i=0;i<capacity;i++){const p=points[i];dummy.position.set(p.x,p.y+.03+.685*p.scale,p.z);dummy.scale.setScalar(p.scale);dummy.lookAt(0,dummy.position.y,0);dummy.updateMatrix();crowd.setMatrixAt(i,dummy.matrix);tiles[i]=p.tile;}
 crowd.instanceMatrix.setUsage(THREE.StaticDrawUsage);crowd.instanceMatrix.needsUpdate=true;geometry.attributes.crowdTile.needsUpdate=true;crowd.computeBoundingSphere();
 crowd.name='OptimizedSupporters';crowd.castShadow=false;crowd.receiveShadow=false;crowd.userData={capacity,spectators:capacity,drawCalls:1,textureSize:'1024 × 128',animated:false,instanced:true};stadium.add(crowd);setCrowdQuality(stadium,readCrowdQuality());return crowd;
}
export function readCrowdQuality(){try{const value=localStorage.getItem('touchline.crowd');if(['light','dense','off'].includes(value))return value;}catch{}return 'light';}
export function setCrowdQuality(stadium,quality){
 const crowd=stadium?.getObjectByName('OptimizedSupporters');if(!crowd)return;
 const limit=quality==='off'?0:quality==='dense'?6000:2200;
 crowd.count=Math.min(crowd.userData.capacity,limit);crowd.visible=crowd.count>0;crowd.userData.spectators=crowd.count;crowd.userData.drawCalls=crowd.count?1:0;stadium.userData.supporters=crowd.count;
}
