import * as THREE from 'three';
export function paintParisKit(canvas,number=10,name='PARIS'){
 const c=canvas.getContext('2d');c.fillStyle='#071a38';c.fillRect(0,0,1024,512);
 // Original in-game recreation: navy shirt, red central stripe with white edges.
 c.fillStyle='#f3f0e9';c.fillRect(710,0,116,512);c.fillStyle='#d8203b';c.fillRect(719,0,98,512);
 for(let y=0;y<512;y+=6){c.fillStyle='rgba(255,255,255,.025)';c.fillRect(0,y,1024,1);}
 c.fillStyle='#edf0e8';c.textAlign='center';c.font='bold '+Math.min(43,Math.floor(570/Math.max(1,name.length)))+'px Arial';c.fillText(name,256,96,440);c.font='bold 228px Arial';c.fillText(String(number),256,330);c.font='bold 26px Arial';c.fillText('PARIS SAINT-GERMAIN',256,414);
 // Stylised Paris crest rather than claiming an official licensed texture.
 c.fillStyle='#f5f2e9';c.beginPath();c.arc(887,112,44,0,Math.PI*2);c.fill();c.fillStyle='#143775';c.beginPath();c.arc(887,112,40,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='bold 13px Arial';c.fillText('PARIS',887,91);c.strokeStyle='#e12b41';c.lineWidth=7;c.beginPath();c.moveTo(876,130);c.lineTo(887,100);c.lineTo(898,130);c.moveTo(878,120);c.lineTo(896,120);c.stroke();
 c.fillStyle='#fff';c.font='bold 31px Arial';c.fillText('QATAR',768,244);c.font='19px Arial';c.fillText('AIRWAYS',768,270);
 c.strokeStyle='#faf9f1';c.lineWidth=6;c.beginPath();c.moveTo(623,110);c.quadraticCurveTo(632,127,667,103);c.stroke();
 c.fillStyle='#e52a40';c.fillRect(0,487,1024,7);
}
export function createDembeleFace(){
 const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;const c=canvas.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,256,256);
 c.strokeStyle='#382a26';c.lineWidth=7;c.lineCap='round';for(const x of [80,170]){c.beginPath();c.moveTo(x-18,95);c.quadraticCurveTo(x,87,x+17,96);c.stroke();}
 c.strokeStyle='#b4988c';c.lineWidth=3;c.beginPath();c.moveTo(123,118);c.lineTo(119,147);c.quadraticCurveTo(128,154,139,147);c.stroke();
 c.strokeStyle='#6d5148';c.lineWidth=4;c.beginPath();c.moveTo(101,173);c.quadraticCurveTo(128,182,153,172);c.stroke();
 c.strokeStyle='#bd9f92';c.lineWidth=3;c.beginPath();c.moveTo(107,185);c.quadraticCurveTo(128,191,148,184);c.stroke();
 // Subtle moustache and chin shadow on the existing rigged low-poly head.
 c.fillStyle='rgba(25,18,16,.35)';c.beginPath();c.ellipse(128,166,19,3,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(128,206,15,7,0,0,Math.PI*2);c.fill();
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;return texture;
}
