import {createMatchIntro} from './match-intro.js';
import * as THREE from 'three';
import {readCrowdQuality,setCrowdQuality} from './crowd.js?v=light2';
import {createLoadingScreen} from './loading-screen.js';
const loading=createLoadingScreen();let stadiumLoading=false;
import {createTechnicalArea} from './technical-area.js?v=fullpitch1';
import {createPlayerEditor} from './player-editor.js?v=socks1';
let playerEditor=null;
import {createProCamera} from './pro-camera.js?v=fullpitch1';
import {createDefense} from './defensive-shape.js?v=compact1';
import {chooseOutlet} from './attacking-decisions.js?v=fullpitch1';
import {createTeamMovement} from './team-movement.js?v=fullpitch1';
import {createRadar} from './radar.js?v=fullpitch1';
import {createStadium,stadiumChoices} from './stadium.js?v=crowd1';
import {separatePlayers,laneClear} from './tactics.js?v=fullpitch1';
import { createHomeKeeper } from './home-keeper.js?v=keepermotion1';
import { createShieldDuel } from './shield-duel.js?v=fullpitch1';
import { createDefender } from './defender.js?v=retreatpress1';
import { createTeammate } from './teammate.js?v=travel3';
import { createGamepadControls } from './gamepad.js?v=fullpitch1';
import { createGoalkeeper } from './goalkeeper.js?v=keepermotion1';
import { createFootballer } from './character.js?v=jockey2';
const $=id=>document.getElementById(id);
const scene=new THREE.Scene();scene.background=new THREE.Color('#c2d1bd');scene.fog=new THREE.Fog('#c2d1bd',110,280);
const renderer=new THREE.WebGLRenderer({canvas:$('pitch'),antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;
const camera=new THREE.PerspectiveCamera(48,innerWidth/innerHeight,.1,350);
scene.add(new THREE.HemisphereLight('#e9f4ec','#54703b',2.35));const sun=new THREE.DirectionalLight('#fff0c9',3);sun.position.set(-32,38,17);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-60,right:60,top:60,bottom:-60,near:1,far:180});sun.shadow.normalBias=.035;sun.shadow.bias=-.0003;scene.add(sun);
const mats=new Map();const material=color=>{if(!mats.has(color))mats.set(color,new THREE.MeshStandardMaterial({color,roughness:.82}));return mats.get(color);};
const cube=new THREE.BoxGeometry(1,1,1),staticBoxes=[];
function box(x,y,z,w,h,d,color,cast=true){const m=new THREE.Mesh(cube,material(color));m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=cast;m.receiveShadow=true;scene.add(m);staticBoxes.push(m);return m;}
function rod(a,b,r,color,parent=scene){const aa=new THREE.Vector3(...a),bb=new THREE.Vector3(...b),delta=bb.clone().sub(aa);const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,delta.length(),10),material(color));m.position.copy(aa.add(bb).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());m.castShadow=true;parent.add(m);return m;}
function lines(points,color='#e7efdf',opacity=1){const m=new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(points.map(p=>new THREE.Vector3(...p))),new THREE.LineBasicMaterial({color,transparent:opacity<1,opacity}));scene.add(m);return m;}
box(0,-.27,0,240,.5,240,'#8f9d73',false);box(0,-.08,0,84,.18,121,'#416f46',false);
for(let i=0;i<20;i++)box(0,.025,-49.875+i*5.25,68,.045,5.25,i%2?'#4d8755':'#568f58',false);
// Field markings: one goal, a penalty area, a centre circle and touchlines.
const white='#e3e9d6';function lineRect(x,z,w,d){box(x,.059,z-d/2,w,.018,.085,white,false);box(x,.059,z+d/2,w,.018,.085,white,false);box(x-w/2,.059,z,.085,.018,d,white,false);box(x+w/2,.059,z,.085,.018,d,white,false);}
lineRect(0,0,68,105);lineRect(0,-44.25,40.32,16.5);lineRect(0,-49.75,18.32,5.5);box(0,.059,0,68,.018,.085,white,false);
function groundRing(x,z,r,color,width=.038){const m=new THREE.Mesh(new THREE.RingGeometry(r-width,r,80),new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide}));m.rotation.x=-Math.PI/2;m.position.set(x,.073,z);scene.add(m);return m;}
groundRing(0,0,9.15,white);groundRing(0,-41.5, .13,white,.13);groundRing(0,0,.13,white,.13);
// Goal frame and a real three-dimensional net.
const goalObjectsStart=scene.children.length;
const goalZ=-52.5,halfGoal=3.66,goalH=2.44,netZ=-54.6;
for(const x of [-halfGoal,halfGoal]){rod([x,.09,goalZ],[x,goalH,goalZ],.065,'#f5f3df');rod([x,goalH,goalZ],[x,2.12,netZ],.043,'#d9dfca');rod([x,.06,goalZ],[x,.06,netZ],.042,'#d9dfca');rod([x,.06,netZ],[x,2.12,netZ],.039,'#d9dfca');}
rod([-halfGoal,goalH,goalZ],[halfGoal,goalH,goalZ],.065,'#f5f3df');rod([-halfGoal,.06,netZ],[halfGoal,.06,netZ],.04,'#d9dfca');
const np=[];for(let x=-halfGoal;x<=halfGoal+.001;x+=.25){np.push([x,.07,netZ],[x,2.12,netZ],[x,2.12,netZ],[x,goalH,goalZ]);}for(let y=.12;y<=2.12;y+=.25){np.push([-halfGoal,y,netZ],[halfGoal,y,netZ]);for(const x of [-halfGoal,halfGoal])np.push([x,y,netZ],[x,y+(y/2.12)*.32,goalZ]);}for(let z=netZ;z<=goalZ;z+=.25){const roofY=2.12+(z-netZ)/(goalZ-netZ)*.32;np.push([-halfGoal,roofY,z],[halfGoal,roofY,z]);for(const x of [-halfGoal,halfGoal])np.push([x,.07,z],[x,roofY,z]);}
const net=lines(np,'#e9e9d6',.54);
const homeGoal=new THREE.Group();for(const object of scene.children.slice(goalObjectsStart))homeGoal.add(object.clone());homeGoal.rotation.y=Math.PI;scene.add(homeGoal);
lineRect(0,44.25,40.32,16.5);lineRect(0,49.75,18.32,5.5);groundRing(0,41.5,.13,white,.13);

function fieldArc(x,z,r,start,end){const points=[];for(let i=0;i<64;i++){const a=start+(end-start)*i/64,b=start+(end-start)*(i+1)/64;points.push([x+Math.cos(a)*r,.077,z+Math.sin(a)*r],[x+Math.cos(b)*r,.077,z+Math.sin(b)*r]);}lines(points,white);}
const penaltyAngle=Math.asin(5.5/9.15);fieldArc(0,-41.5,9.15,penaltyAngle,Math.PI-penaltyAngle);fieldArc(0,41.5,9.15,Math.PI+penaltyAngle,2*Math.PI-penaltyAngle);
fieldArc(-34,-52.5,1,0,Math.PI/2);fieldArc(34,-52.5,1,Math.PI/2,Math.PI);fieldArc(34,52.5,1,Math.PI,Math.PI*1.5);fieldArc(-34,52.5,1,Math.PI*1.5,Math.PI*2);

const sceneryStart=scene.children.length;
// Training-ground architecture.
box(0,.15,-27.5,38,.24,3,'#b9b59b',false);box(0,.85,-29,38,1.5,.28,'#d4cdb2');box(0,1.63,-29,38,.12,.35,'#e6dfc7');
for(const x of [-17,17]){box(x,.08,0,2.3,.18,49,'#b7b39b',false);box(x,.55,0,.32,1.1,49,'#255844');box(x,1.12,0,.26,.1,49,'#e9ead9');}
for(let x=-18;x<=18;x+=3)rod([x,1.6,-29],[x,5.5,-29],.035,'#557164');
let fence=[];for(let x=-18;x<=18;x+=.5)fence.push([x,1.65,-29],[x,5.5,-29]);for(let y=1.7;y<5.6;y+=.5)fence.push([-18,y,-29],[18,y,-29]);lines(fence,'#668371',.35);
function sign(text,x,y,z,w,h){const c=document.createElement('canvas');c.width=1024;c.height=192;const ctx=c.getContext('2d');ctx.fillStyle='#174b39';ctx.fillRect(0,0,1024,192);ctx.fillStyle='#d8edbd';ctx.font='700 66px Arial';ctx.textAlign='center';ctx.fillText(text,512,120);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex}));mesh.position.set(x,y,z);scene.add(mesh);}
sign('TOUCHLINE   /   À TOI DE JOUER',0,.92,-28.82,20,1.1);
for(const side of [-1,1]){for(let row=0;row<3;row++){box(side*(21+row*.95),.3+row*.4,-9,1.0,.5,15,'#9d9f8b');for(let z=-15;z<=-3;z+=1.05){box(side*(21+row*.95),.64+row*.4,z,.7,.15,.75,(row+Math.floor(z))%3===0?'#c5d18c':'#346a59');box(side*(21.32+row*.95),.94+row*.4,z,.12,.55,.75,'#346a59');}}}
let seed=43;function rand(){seed=seed*16807%2147483647;return(seed-1)/2147483646;}
for(let i=0;i<30;i++){let x,z;if(i<14){x=-36+i*5.5;z=-35-rand()*8;}else{x=(i%2?-1:1)*(29+rand()*8);z=-25+rand()*60;}rod([x,0,z],[x,3,z],.17,'#72664d');const t=new THREE.Mesh(new THREE.IcosahedronGeometry(2.3+rand()*.7,1),material(i%2?'#6f8f5d':'#82985f'));t.position.set(x,4.3,z);t.scale.y=1.25;t.castShadow=true;scene.add(t);}
for(const x of [-20,20])for(const z of [-23,19]){rod([x,0,z],[x,10,z],.10,'#698076');box(x,10,z,2.2,.32,.55,'#d4dbbf');for(const dx of [-.65,0,.65])box(x+dx,9.86,z,.48,.06,.39,'#fff5d2',false);}
for(const x of [-11,11])for(const z of [7,11]){const cone=new THREE.Mesh(new THREE.ConeGeometry(.21,.55,12),material('#e79b4c'));cone.position.set(x,.275,z);cone.castShadow=true;scene.add(cone);}
for(const o of scene.children.slice(sceneryStart))o.userData.oldScenery=true;
// Batch static boxes to keep rendering light.
const batches=new Map();for(const m of staticBoxes){const key=m.material.uuid+(m.castShadow?'s':'n')+(m.userData.oldScenery?'env':'field');if(!batches.has(key))batches.set(key,[]);batches.get(key).push(m);scene.remove(m);}for(const batch of batches.values()){const inst=new THREE.InstancedMesh(cube,batch[0].material,batch.length);inst.userData.oldScenery=!!batch[0].userData.oldScenery;inst.castShadow=batch[0].castShadow;inst.receiveShadow=true;batch.forEach((m,i)=>{m.updateMatrix();inst.setMatrixAt(i,m.matrix);});scene.add(inst);}
// Imported scenery is independent of match physics and all six characters.
const dugouts=createTechnicalArea(scene);const stadium=createStadium(scene);const stadiumSelect=$('stadiumSelect');for(const item of stadiumChoices){const option=document.createElement('option');option.value=item.file;option.textContent=item.name;stadiumSelect.append(option);}stadiumSelect.value='FSt_Fra_003.FBX';$('crowdQuality').value=readCrowdQuality();$('crowdQuality').onchange=()=>{const quality=$('crowdQuality').value;try{localStorage.setItem('touchline.crowd',quality);}catch{}setCrowdQuality(stadium.group,quality);};
async function selectStadium(initial=false){
 stadiumSelect.disabled=true;stadiumLoading=true;$('stadiumStatus').textContent='Chargement…';
 if(!initial)loading.startStadium(stadiumSelect.selectedOptions[0].textContent);
 try{await stadium.load(stadiumSelect.value);$('stadiumStatus').textContent='16 stades · Tribunes complètes';setCrowdQuality(stadium.group,$('crowdQuality').value);if(initial)loading.done('stadium');else loading.stadiumReady();}
 catch(error){$('stadiumStatus').textContent='Chargement impossible';loading.fail(error);throw error;}
 finally{stadiumSelect.disabled=false;stadiumLoading=false;}
}
stadiumSelect.onchange=()=>{selectStadium(false).catch(()=>{});};const initialStadiumReady=selectStadium(true);initialStadiumReady.catch(()=>{});
// Animated external character, adapted as Touchline's number 10.
const player=new THREE.Group();scene.add(player);player.position.set(0,0,15);
const footballer=createFootballer(player,{dembele:true,number:10});const keeper=createGoalkeeper(scene,goalZ);const homeKeeper=createHomeKeeper(scene);
const defender=createDefender(scene,{number:4,x:0,z:-18/1.640625,simpleDuel:true});const opponent=defender;
// Compatibility placeholder, not in the scene and with no model or animation.
const emptyRoot=new THREE.Group();emptyRoot.position.set(10000,0,10000);
const noTeammate={root:emptyRoot,number:0,status:'Mode duel',velocity:new THREE.Vector3(),direction:new THREE.Vector3(0,0,-1),reset(){}};let teammate=noTeammate;
const blueAgents=[],redAgents=[defender];
player.userData.tacticalRole='striker';defender.root.userData.tacticalRole='back';
const blueMovement=createTeamMovement(-1),redMovement=createTeamMovement(1);
const blueDefense=createDefense(-1),redDefense=createDefense(1);
const blueRoots=[player,...blueAgents.map(a=>a.root)],redRoots=redAgents.map(a=>a.root),fieldRoots=[...blueRoots,...redRoots];
const closestAgent=(agents,point)=>agents.length?agents.reduce((a,b)=>a.root.position.distanceToSquared(point)<b.root.position.distanceToSquared(point)?a:b):noTeammate;
function redOutlet(actor){return chooseOutlet(actor.root,redAgents.filter(a=>a!==actor).map(a=>({root:a.root,agent:a})),blueRoots,1)?.agent||redAgents.find(a=>a!==actor);}
function blueOutlet(actor){return chooseOutlet(actor.root,[{root:player,agent:null},...blueAgents.filter(a=>a!==actor).map(a=>({root:a.root,agent:a}))],redRoots,-1);}
function chooseBluePass(){if(!blueAgents.length)return noTeammate;
 const intention=playerVelocity.length()>.25?playerVelocity.clone().normalize():null;
 return [...blueAgents].sort((a,b)=>{const score=r=>{const to=r.root.position.clone().sub(player.position);to.y=0;const distance=to.length(),angle=intention?14*(1-to.normalize().dot(intention)):0;return distance+angle+(laneClear(player.position,r.root.position,redRoots,1)?0:18)-Math.min(5,player.position.z-r.root.position.z)-(r.runTime>0?4:0);};return score(a)-score(b);})[0];
}

let avatarReady=false;
$('start').disabled=true;$('start').innerHTML='CHARGEMENT DES JOUEURS…';
const characterLoads=[footballer.promise,keeper.promise,homeKeeper.promise,...blueAgents.map(a=>a.promise),...redAgents.map(a=>a.promise)];
Promise.all([initialStadiumReady,...characterLoads.map((promise,i)=>promise.then(model=>{loading.done('player'+i);return model;}))]).then(()=>{
 avatarReady=true;$('start').disabled=false;$('start').innerHTML='ENTRER SUR LE TERRAIN <span>↗</span>';
 requestAnimationFrame(()=>requestAnimationFrame(()=>{loading.done('frame');loading.finish();}));
}).catch(error=>{loading.fail(error);$('start').disabled=true;});
const proCamera=createProCamera(camera);let cameraMode=2;let cameraFocusZ=0;
function changeCamera(){cameraMode=(cameraMode+1)%3;proCamera.reset();$('cameraBtn').innerHTML='<kbd>C</kbd> '+['Ligne de touche','Vue large','Pro · confort'][cameraMode];notify(['Vue ligne de touche : suivi stable du ballon.','Vue large : les deux buts visibles.','Caméra pro confort : orientation fixe, sans rotation automatique.'][cameraMode]);if(cameraMode!==2){camera.fov=48;camera.updateProjectionMatrix();}}

$('cameraBtn').onclick=changeCamera;
const selectRing=groundRing(0,9,.56,'#d5f990',.042);
// White ball with twelve black pentagonal panels on the sphere.
const ball=new THREE.Group();const radius=.15;scene.add(ball);const sphere=new THREE.Mesh(new THREE.SphereGeometry(radius,24,18),new THREE.MeshStandardMaterial({color:'#f5f2e2',roughness:.62}));sphere.castShadow=true;ball.add(sphere);
const phi=(1+Math.sqrt(5))/2;const vertices=[];for(const a of [-1,1])for(const b of [-1,1]){vertices.push(new THREE.Vector3(0,a,b*phi),new THREE.Vector3(a,b*phi,0),new THREE.Vector3(b*phi,0,a));}
for(const normal of vertices){normal.normalize();const u=new THREE.Vector3().crossVectors(normal,Math.abs(normal.y)>.9?new THREE.Vector3(1,0,0):new THREE.Vector3(0,1,0)).normalize(),v=new THREE.Vector3().crossVectors(normal,u);let pts=[normal.clone().multiplyScalar(radius+.002)];for(let i=0;i<5;i++){const a=i/5*Math.PI*2;pts.push(normal.clone().multiplyScalar(radius).addScaledVector(u,Math.cos(a)*.056).addScaledVector(v,Math.sin(a)*.056).normalize().multiplyScalar(radius+.002));}const positions=[];for(let i=0;i<5;i++)positions.push(...pts[0].toArray(),...pts[i+1].toArray(),...pts[(i+1)%5+1].toArray());const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.computeVertexNormals();ball.add(new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:'#25332b',roughness:.75,side:THREE.DoubleSide})));}
ball.position.set(0,radius,13.9);
const ballShadow=new THREE.Mesh(new THREE.CircleGeometry(.16,24),new THREE.MeshBasicMaterial({color:'#1e432c',transparent:true,opacity:.3,depthWrite:false}));ballShadow.rotation.x=-Math.PI/2;scene.add(ballShadow);
const target=new THREE.Group();scene.add(target);const aimRing=new THREE.Mesh(new THREE.TorusGeometry(.25,.014,6,36),new THREE.MeshBasicMaterial({color:'#e4fa87',depthTest:false,transparent:true,opacity:.9}));target.add(aimRing);for(const rot of [0,Math.PI/2]){let m=new THREE.Mesh(new THREE.BoxGeometry(.13,.018,.018),new THREE.MeshBasicMaterial({color:'#e4fa87',depthTest:false}));m.rotation.z=rot;target.add(m);}target.position.set(0,1.1,goalZ+.05);
// Gameplay.
const keys={},velocity=new THREE.Vector3();let started=false,owned=true,charge=0,charging=false,goals=0,shots=0,saves=0,time=0,runPhase=0,kickAnim=0,cooldown=0,resetTimer=0,messageTime=0,shotLive=false,shotAge=0,wasGoal=false;
let runCooldown=0;const radar=createRadar($('radarCanvas'));const radarKeeperPosition=new THREE.Vector3();
let aiChallengeActor=null;let controlGrace=0,aiChallenge=0,aiChallengeCooldown=0,redPassTarget=null,pressPlayer=null,pressTimer=0;
let distribution=null,keeperPass=null,keeperPassAge=0,throwsCompleted=0;
let slideTime=-1,slideCooldown=0,slideWon=false;const slideDirection=new THREE.Vector3(0,0,-1);
let redCarrier=defender,enemyShot=false,enemyScored=false,enemyGoals=0,homeSaves=0,challengeCooldown=0;
let defenderOwned=false,clearanceLive=false,clearanceAge=0,recoveries=0,clearances=0;
let mateOwned=false,lastActor='player',passTarget=null,completedPasses=0,playerAssists=0,mateGoals=0,assistForMate=false,assistForPlayer=false;const playerVelocity=new THREE.Vector3();player.userData.velocity=playerVelocity;
let paused=false,passLive=false,actionKind='shoot',chargeSource='keyboard',shotStyle='normal';
const shieldDuel=createShieldDuel();let shield=0,shieldSide=1;const aim={x:0,y:1.1};let direction=new THREE.Vector3(0,0,-1),shotFrom=new THREE.Vector3();let particles=[];
function notify(t){$('message').textContent=t;$('message').classList.add('visible');messageTime=3;}
function updateScore(){$('enemyGoals').textContent=String(enemyGoals).padStart(2,'0');$('saves').textContent=String(saves).padStart(2,'0');$('goals').textContent=String(goals).padStart(2,'0');$('shots').textContent=String(shots).padStart(2,'0');$('accuracy').textContent=shots?Math.round(goals/shots*100)+' % DE RÉUSSITE':'À VOUS DE JOUER';}
function resetRound(message=false){proCamera.reset();blueDefense.reset();redDefense.reset();aiChallengeActor=null;blueMovement.reset();redMovement.reset();runCooldown=0;controlGrace=0;aiChallenge=0;aiChallengeCooldown=0;redPassTarget=null;pressTimer=0;slideTime=-1;slideCooldown=0;slideWon=false;distribution=null;keeperPass=null;keeperPassAge=0;enemyScored=false;enemyShot=false;for(const a of [...blueAgents,...redAgents])a.reset();teammate=noTeammate;pressPlayer=null;homeKeeper.reset(message);redCarrier=defender;challengeCooldown=0;shieldDuel.reset();shield=0;defenderOwned=false;clearanceLive=false;clearanceAge=0;defender.reset();mateOwned=false;teammate.reset();lastActor='player';passTarget=null;assistForMate=false;assistForPlayer=false;playerVelocity.set(0,0,0);passLive=false;actionKind='shoot';shotStyle='normal';footballer.reset();keeper.reset(message);player.position.set(0,0,15);player.rotation.set(0,0,0);direction.set(0,0,-1);ball.position.set(0,radius,13.9);ball.rotation.set(0,0,0);velocity.set(0,0,0);owned=true;charge=0;charging=false;cooldown=0;resetTimer=0;shotLive=false;shotAge=0;wasGoal=false;aim.x=0;aim.y=1.1;$('celebration').classList.remove('show');if(message)notify('Ballon replacé. À toi de jouer !');}
function beginCharge(kind='shoot',source='keyboard'){
 if(kind!=='shoot'&&!(kind==='cross'&&!owned)){notify('Mode duel : aucun partenaire de champ.');return;}
 if(!started||paused||resetTimer>0||charging)return;
 if(keeper.saved||homeKeeper.saved){notify('Le gardien prépare sa relance. Démarque-toi !');return;}
 if(slideTime>=0)return;
 if(kind==='cross'&&!owned&&!mateOwned){startSlide();return;}
 if(defenderOwned){challenge();return;}
 if(mateOwned){if(kind==='shoot'){teammate.requestShot();notify('Tu demandes une frappe au partenaire.');}else{teammate.requestPass();notify('Appel de balle : ton coéquipier va te chercher.');}return;}
 if(ball.position.distanceTo(player.position)>1.8||ball.position.y>1.1){notify('Approche-toi du ballon pour jouer.');return;}
 actionKind=kind;chargeSource=source;shotStyle='normal';charging=true;charge=0;
}
function releaseAction(kind,mods={}){
 if(!charging||paused||actionKind!==kind)return;
 if(kind==='shoot')shoot(mods.chip?'chip':mods.finesse?'finesse':'normal');else playPass(kind);
}
function shoot(style='normal'){
 if(!charging||!started||paused)return;
 if(actionKind!=='shoot'){playPass(actionKind);return;}
 charging=false;const power=Math.max(.12,charge);if(ball.position.distanceTo(player.position)>2.1){charge=0;return;}
 controlGrace=0;shotStyle=style;owned=false;mateOwned=false;lastActor='player';passTarget=null;passLive=false;shots++;shotLive=true;shotAge=0;wasGoal=false;shotFrom.copy(ball.position);cooldown=.85;
 let targetX=aim.x,targetY=aim.y,speedFactor=1;
 if(style==='finesse'){targetX=THREE.MathUtils.clamp(targetX,-3.25,3.25);targetY=Math.min(1.6,targetY);speedFactor=.86;notify('Tir placé.');}
 if(style==='chip'){targetY=Math.min(2.07,Math.max(1.65,targetY+.5));speedFactor=.68;notify('Tir lobé.');}
 const dx=targetX-ball.position.x,dz=goalZ-ball.position.z,distance=Math.hypot(dx,dz),flatSpeed=(13+power*18)*speedFactor,t=Math.max(.12,distance/flatSpeed);
 velocity.set(dx/distance*flatSpeed,(targetY-ball.position.y+4.9*t*t)/t,dz/distance*flatSpeed);
 kickAnim=.20;footballer.kick(true);keeper.onShot();charge=0;pad.pulse(.18,90);updateScore();
}
function sendTeamPass(from,to,kind='pass',power=.45,recipient=null){if(!blueAgents.length)return;
 if(recipient)teammate=recipient;
 if(from==='player'&&to==='mate'&&!recipient)teammate=chooseBluePass();
 controlGrace=0;const receiver=to==='mate'?teammate.root:player;
 const point=receiver.position.clone();
 if(kind==='through'){point.add(new THREE.Vector3(0,0,-3.4));}else point.addScaledVector(to==='mate'?teammate.velocity:playerVelocity,.20);
 point.x=THREE.MathUtils.clamp(point.x,-32.4,32.4);point.z=THREE.MathUtils.clamp(point.z,-50.2,50.5);
 const dir=point.clone().sub(ball.position);dir.y=0;const dist=Math.max(1,dir.length());dir.normalize();
 if(kind==='cross'){const duration=THREE.MathUtils.clamp(.7+dist*.042,.9,1.85);velocity.copy(dir).multiplyScalar(dist/duration);velocity.y=4.9*duration;}
 else{velocity.copy(dir).multiplyScalar(Math.min(36,.6*dist+5.0+power*2+(kind==='through'?2.4:0)));velocity.y=.12;}
 owned=false;mateOwned=false;lastActor=from;passTarget=to;passLive=true;shotLive=false;shotAge=0;wasGoal=false;cooldown=.40;shotFrom.copy(ball.position);
 keeper.onShot();if(from==='player')footballer.kick(true);charge=0;pad.pulse(.1,70);
 notify(from==='mate'?(to==='mate'?'Les bleus combinent vers le n°'+teammate.number+' !':'Ton coéquipier te fait la passe !'):kind==='through'?'Passe en profondeur pour ton coéquipier.':kind==='cross'?'Ballon lobé vers ton coéquipier.':'Passe vers ton coéquipier. Fais un appel pour le une-deux !');
}
function playPass(kind){
 if(!charging||paused)return;charging=false;
 if(ball.position.distanceTo(player.position)>2.1){charge=0;return;}
 sendTeamPass('player','mate',kind,Math.max(.2,charge));
}
function receiveBall(who){if(defenderOwned)redCarrier.repel((who==='player'?player:teammate.root).position);controlGrace=1.05;redPassTarget=null;keeperPass=null;clearanceLive=false;defenderOwned=false;
 if(passLive&&passTarget===who){completedPasses++;if(who==='mate'){assistForMate=lastActor==='player';assistForPlayer=false;}else{assistForPlayer=lastActor==='mate';assistForMate=false;}}
 owned=who==='player';mateOwned=who==='mate';passLive=false;passTarget=null;shotLive=false;velocity.set(0,0,0);cooldown=.16;
 if(mateOwned){teammate.receive();notify('Ton coéquipier contrôle. E / A / ✕ pour demander le ballon.');}else{notify('À toi de jouer !');}
 $('teamPasses').textContent=String(completedPasses).padStart(2,'0');
}
function teammateShoot(){controlGrace=0;
 if(!mateOwned)return;
 const tx=teammate.shotTarget?.x??(keeper.root.position.x>=0?-1:1)*(2.35+rand()*.55),ty=.65+rand()*.65;
 const dx=tx-ball.position.x,dz=goalZ-ball.position.z,dist=Math.hypot(dx,dz),flat=23+rand()*5,t=Math.max(.12,dist/flat);
 velocity.set(dx/dist*flat,(ty-ball.position.y+4.9*t*t)/t,dz/dist*flat);
 owned=false;mateOwned=false;lastActor='mate';passTarget=null;passLive=false;shotLive=true;shotAge=0;wasGoal=false;cooldown=.8;shots++;shotFrom.copy(ball.position);keeper.onShot();updateScore();notify('Ton coéquipier tente sa chance !');
}
function defenderWins(winner=defender){
 if((owned||mateOwned)&&controlGrace>0){winner.repel((owned?player:teammate.root).position);return;}
 if(mateOwned)teammate.yield(winner.root.position);
 if(owned&&slideWon&&(slideTime>=0||slideCooldown>.65)){winner.repel();return;}
 if(owned&&shieldDuel.protected){winner.repel();pad.pulse(.08,60);notify('Tu résistes au tacle ! Passe ou pivote avant de fatiguer.');return;}
 if(defenderOwned||resetTimer>0)return;
 controlGrace=1.05;redPassTarget=null;keeperPass=null;redCarrier=winner;enemyShot=false;defenderOwned=true;owned=false;mateOwned=false;charging=false;charge=0;shotLive=false;passLive=false;clearanceLive=false;passTarget=null;lastActor='defender';assistForMate=false;assistForPlayer=false;velocity.set(0,0,0);cooldown=.65;recoveries++;redCarrier.receive();homeKeeper.onShot();pad.pulse(.32,100);notify('Les rouges récupèrent et partent à l’attaque !');
}
function prepareDistribution(home){
 owned=false;mateOwned=false;defenderOwned=false;charging=false;charge=0;shotLive=false;enemyShot=false;passLive=false;passTarget=null;keeperPass=null;velocity.set(0,0,0);resetTimer=0;
 distribution={home,keeper:home?homeKeeper:keeper,receiver:null,target:null,started:false};
 notify(home?'Ton gardien a capté ! Il cherche une relance à la main.':'Le gardien rouge a capté et prépare sa relance.');
}
function keeperDistribution(dt){
 if(distribution){
  const d=distribution;
  if(!d.started){
   const candidates=d.home?[{id:'player',root:player},...blueAgents.map((a,i)=>({id:'blue'+i,root:a.root,agent:a}))]:redAgents.map(a=>({id:'red'+a.number,root:a.root,agent:a}));
   const start=d.keeper.holdPoint();const enemies=d.home?redRoots:blueRoots;
   candidates.sort((a,b)=>{const score=r=>start.distanceTo(r.root.position)-Math.min(...enemies.map(e=>e.position.distanceTo(r.root.position)))*.35;return score(a)-score(b);});
   d.receiver=candidates[0];d.target=d.receiver.root.position.clone();
   d.started=d.keeper.startThrow(d.target);
  }
  const release=d.keeper.takeThrowRelease();
  if(release){
   const destination=d.receiver.root.position.clone();destination.y=radius;
   const dist=Math.hypot(destination.x-release.x,destination.z-release.z),flight=THREE.MathUtils.clamp(.7+dist*.04,.85,2.1);
   ball.position.copy(release);velocity.copy(destination).sub(release).divideScalar(flight);velocity.y=(radius-release.y+4.9*flight*flight)/flight;
   if(d.home&&d.receiver.agent)teammate=d.receiver.agent;keeperPass={home:d.home,receiver:d.receiver.id};keeperPassAge=0;cooldown=.3;passLive=true;passTarget=d.home?(d.receiver.id==='player'?'player':'mate'):'red';lastActor=d.home?'homeKeeper':'keeper';shotAge=0;throwsCompleted++;distribution=null;
   notify(d.home?'Relance à la main de ton gardien !':'Le gardien relance les rouges à la main.');
  }
 }
 if(keeperPass){keeperPassAge+=dt;if(keeperPassAge>7){keeperPass=null;passLive=false;passTarget=null;}}
}
function callRun(){if(!blueAgents.length){notify('Mode duel : aucun appel de partenaire.');return;}
 if(!started||paused||resetTimer>0||runCooldown>0)return;
 if(!owned){notify('Récupère le ballon pour déclencher un appel.');return;}
 const runner=chooseBluePass(),current=runner.root.position;
 const left=current.clone().add(new THREE.Vector3(-2,0,-8)),right=current.clone().add(new THREE.Vector3(2,0,-8));
 const openness=p=>Math.min(...redRoots.map(r=>r.position.distanceTo(p)))+(laneClear(current,p,redRoots,1)?3:0);
 const destination=openness(left)>openness(right)?left:right;destination.x=THREE.MathUtils.clamp(destination.x,-31.5,31.5);destination.z=THREE.MathUtils.clamp(destination.z,-48.5,47.5);
 if(!blueMovement.grid.canReserve(runner.root,destination)){let alternative=null;for(const dx of [-4,4,-8,8]){const p=destination.clone();p.x=THREE.MathUtils.clamp(p.x+dx,-31.5,31.5);if(blueMovement.grid.canReserve(runner.root,p)){alternative=p;break;}}if(alternative)destination.copy(alternative);else{notify('Cet espace est occupé : oriente-toi vers un autre partenaire.');return;}}
 blueMovement.grid.reserve(runner.root,destination);runner.requestRun(destination);runCooldown=2;pad.pulse(.08,60);notify('Le n°'+runner.number+' part en profondeur ! F / Y / △ pour le lancer.');
}
$('runBtn').onclick=$('runMobile').onclick=callRun;
function startSlide(){
 if(!started||paused||resetTimer>0||owned||mateOwned||keeper.saved||homeKeeper.saved||slideTime>=0||slideCooldown>0)return;
 slideTime=0;slideCooldown=2.1;slideWon=false;charging=false;charge=0;shield=0;footballer.reset();
 slideDirection.copy(direction);const toward=ball.position.clone().sub(player.position);toward.y=0;if(toward.length()<3.4&&toward.length()>.05&&toward.normalize().dot(direction)>.25)slideDirection.lerp(toward,.55).normalize();
 direction.copy(slideDirection);player.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);for(let i=0;i<9;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(.05,.10),new THREE.MeshBasicMaterial({color:i%2?'#a7b46c':'#537d47',side:THREE.DoubleSide}));m.position.copy(player.position);m.position.y=.10;scene.add(m);particles.push({m,v:new THREE.Vector3((rand()-.5)*1.5,1+rand(),(rand()-.5)*1.5).addScaledVector(slideDirection,-1),life:.5+rand()*.25});}notify('Tacle glissé ! Attention au temps pour te relever.');
}
function updateSlide(dt){
 if(slideTime<0)return;slideTime+=dt;
 const before=player.position.clone().addScaledVector(slideDirection,.65);
 if(slideTime<.64)player.position.addScaledVector(slideDirection,8.5*Math.exp(-slideTime*2.6)*dt);
 player.position.x=THREE.MathUtils.clamp(player.position.x,-33.2,33.2);player.position.z=THREE.MathUtils.clamp(player.position.z,-51.1,51.5);player.position.y=0;
 const after=player.position.clone().addScaledVector(slideDirection,.85),closest=new THREE.Vector3();new THREE.Line3(before,after).closestPointToPoint(ball.position,true,closest);
 if(controlGrace<=0&&!slideWon&&slideTime>.10&&slideTime<.64&&!owned&&!mateOwned&&!keeper.saved&&!homeKeeper.saved&&ball.position.y<.7&&Math.hypot(closest.x-ball.position.x,closest.z-ball.position.z)<.82){
  if(defenderOwned)redCarrier.repel();enemyShot=false;receiveBall('player');slideWon=true;pad.pulse(.25,100);notify('Tacle réussi ! Ballon récupéré.');
 }
 if(slideTime>=1.2)slideTime=-1;
}
$('slideMobile').onclick=startSlide;
function challenge(){
 if(challengeCooldown>0||!defenderOwned||slideTime>=0)return;challengeCooldown=.8;footballer.kick();
 if(controlGrace<=0&&ball.position.distanceTo(player.position)<1.65&&ball.position.y<.8){redCarrier.repel();receiveBall('player');enemyShot=false;notify('Bien joué, tu récupères !');}else notify('Tacle manqué : rapproche-toi du ballon.');
}
function enemyPass(){
 if(!defenderOwned)return;const other=redOutlet(redCarrier);if(!other)return;
 const end=other.root.position.clone().addScaledVector(other.velocity,.20);end.y=radius;const delta=end.sub(ball.position);delta.y=0;const distance=delta.length();
 velocity.copy(delta.normalize()).multiplyScalar(Math.min(36,5.8+.6*distance));velocity.y=.18;
 redPassTarget=other;defenderOwned=false;enemyShot=false;shotLive=false;passLive=true;passTarget='red';keeperPass=null;lastActor='defender';controlGrace=0;cooldown=.4;shotAge=0;notify('Les rouges combinent : coupe la ligne de passe !');
}
function enemyShoot(){controlGrace=0;
 if(!defenderOwned)return;const tx=redCarrier.shotTarget?.x??(rand()>.5?1:-1)*(1.7+rand()*1.3),ty=.65+rand()*.7;
 const dx=tx-ball.position.x,dz=52.5-ball.position.z,dist=Math.hypot(dx,dz),speed=23+rand()*8,t=dist/speed;
 velocity.set(dx/dist*speed,(ty-ball.position.y+4.9*t*t)/t,dz/dist*speed);defenderOwned=false;enemyShot=true;shotLive=true;passLive=false;passTarget=null;shotAge=0;lastActor='defender';cooldown=.7;homeKeeper.onShot();notify('Frappe adverse ! Ton gardien intervient.');
}
function enemyGoal(){
 enemyScored=true;enemyGoals++;shotLive=false;enemyShot=false;passLive=false;resetTimer=2.8;velocity.multiplyScalar(.18);updateScore();$('celebration').classList.add('show');document.querySelector('#celebration strong').innerHTML='BUT ADVERSE';$('goalDetail').textContent='Bleus '+goals+' — '+enemyGoals+' Rouges · À vous de répondre !';notify('But des rouges !');pad.pulse(.4,180);
}
function quickPass(){if(!started||paused||resetTimer>0)return;if(mateOwned){teammate.requestPass();notify('Tu demandes le ballon au partenaire.');return;}beginCharge('pass');if(charging){charge=.45;playPass('pass');}}
$('teamPassBtn').onclick=$('passMobile').onclick=quickPass;

function goal(){document.querySelector('#celebration strong').innerHTML='BUUUT<span>!</span>';if(wasGoal)return;wasGoal=true;if(passLive)shots++;passLive=false;shotLive=false;goals++;if(lastActor==='mate'){mateGoals++;if(assistForMate)playerAssists++;}pad.pulse(.65,280);updateScore();resetTimer=2.8;$('celebration').classList.add('show');$('goalDetail').textContent=(lastActor==='mate'?'But du coéquipier':'But du n°10')+' · '+Math.round(shotFrom.distanceTo(new THREE.Vector3(0,radius,goalZ)))+' m'+(lastActor==='mate'&&assistForMate?' · Sur ta passe !':lastActor==='player'&&assistForPlayer?' · Passe décisive du coéquipier !':' · Bien joué !');for(let i=0;i<44;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(.10,.20),new THREE.MeshBasicMaterial({color:i%2?'#d8fa75':'#f2f6e4',side:THREE.DoubleSide}));m.position.set((rand()-.5)*7,1+rand()*2,goalZ+1);scene.add(m);particles.push({m,v:new THREE.Vector3((rand()-.5)*5,3+rand()*5,(rand()-.5)*4),life:2.8});}}
let kickoff=null;
const kickoffPanel=document.createElement('div');kickoffPanel.className='kickoff-banner';kickoffPanel.hidden=true;document.body.append(kickoffPanel);
function prepareKickoff(team='blue'){team='blue';
 resetRound();started=false;charging=false;for(const k in keys)keys[k]=false;
 const formation=(root,side)=>{const role=root.userData.tacticalRole;let x=0,z=12;if(role==='back'){x=root.userData.tacticalLane||6;z=30;}else if(role==='fullLeft'||role==='fullRight'){x=role==='fullLeft'?-24:24;z=27;}else if(role==='midLeft'||role==='midRight'){x=role==='midLeft'?-12:12;z=18;}else if(role==='midCenter'){z=12;}else if(role==='left'||role==='right'){x=role==='left'?-23:23;z=5;}root.position.set(x,0,side*z);root.rotation.set(0,side===1?0:Math.PI,0);};
 blueRoots.forEach(r=>formation(r,1));redRoots.forEach(r=>formation(r,-1));defender.root.position.set(0,0,-18);
 const taker=team==='blue'?player:redAgents.find(a=>a.root.userData.tacticalRole==='striker').root;taker.position.set(0,0,team==='blue'?.75:-.75);
 owned=team==='blue';defenderOwned=team==='red';mateOwned=false;if(team==='red')redCarrier=redAgents.find(a=>a.root===taker);
 ball.position.set(0,radius,0);ball.rotation.set(0,0,0);velocity.set(0,0,0);playerVelocity.set(0,0,0);kickoff={team,time:3};
}
function showKickoff(){kickoffPanel.textContent='ENGAGEMENT '+(kickoff.team==='blue'?'DES BLEUS':'DES ROUGES')+' · 3';kickoffPanel.hidden=false;camera.fov=cameraMode===2?60:48;camera.updateProjectionMatrix();proCamera.reset();camera.position.set(player.position.x,4.2,player.position.z+8.2);camera.lookAt(player.position.x,1.15,player.position.z-3.5);}
function releaseKickoff(){const team=kickoff.team;kickoff=null;kickoffPanel.hidden=true;started=true;for(const k in keys)keys[k]=false;
 owned=true;defenderOwned=false;direction.set(0,0,-1);player.rotation.set(0,0,0);controlGrace=1.05;notify('À toi de jouer ! Défenseur mobile dans les quatre directions.');}
const matchIntro=createMatchIntro({blue:[{root:player,avatar:footballer},...blueAgents,{root:homeKeeper.root,avatar:homeKeeper.avatar,keeper:true}],red:[...redAgents,{root:keeper.root,avatar:keeper.avatar,keeper:true}],camera,onFinish:showKickoff});
$('start').onclick=()=>{if(!avatarReady||started)return;if(matchIntro.active){matchIntro.skip();return;}if(kickoff)return;document.body.classList.add('playing');prepareKickoff('blue');matchIntro.start();};
$('reset').onclick=()=>{if(matchIntro.active)return;prepareKickoff('blue');showKickoff();};$('help').onclick=()=>notify('Mode duel · ZQSD : déplacement · Maj : sprint · Espace : tirer · X : tacle glissé · C : caméra · R : replacer au centre. Défenseur : déplacements dans les quatre directions.');
addEventListener('keydown',e=>{if(playerEditor?.isOpen)return;if(e.target?.tagName==='SELECT')return;const k=e.key.toLowerCase();if([' ','arrowup','arrowdown','arrowleft','arrowright','z','q','s','d','r','w','a','e','f','v','x','g'].includes(k))e.preventDefault();keys[k]=true;if(e.repeat)return;if(matchIntro.active&&k==='enter'){matchIntro.skip();return;}if(k==='escape'){setPaused(!paused);return;}if(paused||matchIntro.active||kickoff)return;if(k==='g')callRun();if(k==='x')startSlide();if(k===' ')beginCharge();if(k==='e')beginCharge('pass');if(k==='f')beginCharge('through');if(k==='v')beginCharge('cross');if(k==='r')$('reset').click();if(k==='c')changeCamera();});addEventListener('keyup',e=>{if(playerEditor?.isOpen)return;keys[e.key.toLowerCase()]=false;if(e.key===' ')releaseAction('shoot');if(e.key.toLowerCase()==='e')releaseAction('pass');if(e.key.toLowerCase()==='f')releaseAction('through');if(e.key.toLowerCase()==='v')releaseAction('cross');});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;charging=false;charge=0;});
const ray=new THREE.Raycaster(),goalPlane=new THREE.Plane(new THREE.Vector3(0,0,1),-goalZ),hit=new THREE.Vector3();
function setAim(e){if(!started||paused)return;const r=renderer.domElement.getBoundingClientRect();ray.setFromCamera(new THREE.Vector2((e.clientX-r.left)/r.width*2-1,1-(e.clientY-r.top)/r.height*2),camera);if(ray.ray.intersectPlane(goalPlane,hit)){aim.x=THREE.MathUtils.clamp(hit.x,-6.5,6.5);aim.y=THREE.MathUtils.clamp(hit.y,.35,3.2);}}
renderer.domElement.addEventListener('pointermove',setAim);renderer.domElement.addEventListener('pointerdown',e=>{setAim(e);if(e.pointerType==='mouse'){renderer.domElement.setPointerCapture(e.pointerId);beginCharge();}});renderer.domElement.addEventListener('pointerup',e=>{if(e.pointerType==='mouse')releaseAction('shoot');});renderer.domElement.addEventListener('pointercancel',()=>{charging=false;charge=0;});
for(const button of document.querySelectorAll('[data-key]')){button.onpointerdown=e=>{e.preventDefault();button.setPointerCapture(e.pointerId);keys[button.dataset.key]=true;};button.onpointerup=button.onpointercancel=()=>keys[button.dataset.key]=false;}
$('shootMobile').onpointerdown=e=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);beginCharge();};$('shootMobile').onpointerup=()=>releaseAction('shoot');$('shootMobile').onpointercancel=()=>{charging=false;charge=0;};
// Gamepad support: standard-layout Xbox, DualShock, DualSense and compatible pads.
function setPaused(value){
 paused=value;charging=false;charge=0;for(const k in keys)keys[k]=false;
 $('inputMenu').hidden=!value;document.body.classList.toggle('paused',value);
 $('resumeInput').firstChild.textContent=started?'REPRENDRE LE JEU ':'RETOUR ';
}
function refreshPadUI(state){
 const connected=!!state?.connected,ps=state?.layout==='ps';
 $('padStatus').classList.toggle('connected',connected);
 $('padStatusText').textContent=connected?(ps?'MANETTE PLAYSTATION':'MANETTE CONNECTÉE'):'CONNECTER UNE MANETTE';
 $('padDevice').textContent=connected?state.id+(state.mapping==='standard'?' · Profil classique actif':' · Profil générique : les touches peuvent varier'):'Branche ta manette en USB ou Bluetooth, puis appuie sur un bouton.';
 document.querySelectorAll('.pad-shot').forEach(e=>e.textContent=ps?'○':'B');document.querySelectorAll('.pad-pass').forEach(e=>e.textContent=ps?'✕':'A');document.querySelectorAll('.pad-sprint').forEach(e=>e.textContent=ps?'R2':'RT');
 if(!connected)document.body.classList.remove('pad-active');
}
const pad=createGamepadControls({
 mode:()=>paused?'paused':started?'play':'intro',
 onStart:()=>{if(avatarReady)$('start').click();},
 onMenu:()=>{if(matchIntro.active){matchIntro.skip();return;}if(kickoff){setPaused(!paused);return;}if(!started&&!paused){if(avatarReady)$('start').click();}else setPaused(!paused);},
 onResume:()=>setPaused(false),onHelp:()=>setPaused(true),onCamera:changeCamera,
 onRun:callRun,
 onCharge:kind=>beginCharge(kind,'pad'),onRelease:releaseAction,
 onConnect:state=>{refreshPadUI(state);notify('Manette détectée. Commandes classiques FIFA / EA FC activées.');},
 onDisconnect:()=>{refreshPadUI(null);charging=false;charge=0;if(started)setPaused(true);notify('Manette déconnectée. Clavier et souris restent disponibles.');},
 onUnavailable:()=>{$('padTrouble').textContent='Le navigateur bloque l’accès aux manettes dans cet aperçu. Ouvre le jeu dans un nouvel onglet, puis appuie sur un bouton de ta manette.';},
});
$('padStatus').onclick=$('padHelp').onclick=()=>setPaused(true);
$('closeInput').onclick=$('resumeInput').onclick=()=>setPaused(false);
addEventListener('blur',()=>{pad.setEnabled(false);if(started)setPaused(true);});addEventListener('focus',()=>pad.setEnabled(true));
document.addEventListener('visibilitychange',()=>{if(document.hidden){pad.setEnabled(false);if(started)setPaused(true);}else pad.setEnabled(true);});
const clock=new THREE.Clock();camera.position.set(32,16,26);const cameraTarget=new THREE.Vector3(),lookTarget=new THREE.Vector3();
function animate(){requestAnimationFrame(animate);if(playerEditor?.isOpen){clock.getDelta();return;}if(!playerEditor?.isOpen)pad.poll(performance.now()/1000);let dt=Math.min(clock.getDelta(),.05);if(paused||playerEditor?.isOpen||stadiumLoading)dt=0;time+=dt;document.body.classList.toggle('pad-active',pad.state.connected&&pad.state.active);
if(matchIntro.active||kickoff){
 if(matchIntro.active)matchIntro.update(dt);else{kickoff.time-=dt;kickoffPanel.textContent='ENGAGEMENT '+(kickoff.team==='blue'?'DES BLEUS':'DES ROUGES')+' · '+Math.max(1,Math.ceil(kickoff.time));footballer.update(dt);for(const a of [...blueAgents,...redAgents])a.avatar.update(dt);if(kickoff.time<=0)releaseKickoff();}
 selectRing.visible=false;target.visible=false;ballShadow.position.set(ball.position.x,.082,ball.position.z);renderer.render(scene,camera);return;
}selectRing.visible=true;
if(charging&&chargeSource==='pad'){if(Math.abs(pad.state.moveX)>.04||pad.state.moveY<-.35){aim.x=THREE.MathUtils.clamp(pad.state.moveX*4.9,-3.35,3.35);aim.y=1.1;}shotStyle=pad.state.chip?'chip':pad.state.finesse?'finesse':'normal';}
cooldown-=dt;runCooldown=Math.max(0,runCooldown-dt);controlGrace=Math.max(0,controlGrace-dt);aiChallengeCooldown=Math.max(0,aiChallengeCooldown-dt);pressTimer-=dt;challengeCooldown-=dt;slideCooldown=Math.max(0,slideCooldown-dt);homeKeeper.update(dt,ball.position,velocity,enemyShot&&resetTimer<=0,redCarrier.root.position.x);if(homeKeeper.saved)ball.position.copy(homeKeeper.holdPoint());keeper.update(dt,ball.position,velocity,(shotLive||passLive)&&!enemyShot&&resetTimer<=0,(mateOwned||lastActor==='mate'?teammate.root.position.x:player.position.x),charging);if(keeper.saved)ball.position.copy(keeper.holdPoint());kickAnim=Math.max(0,kickAnim-dt);if(messageTime>0){messageTime-=dt;if(messageTime<=0)$('message').classList.remove('visible');}
if(started&&!paused&&!playerEditor?.isOpen&&!stadiumLoading){keeperDistribution(dt);if(resetTimer>0){resetTimer-=dt;if(resetTimer<=0){if(wasGoal||enemyScored){const team=wasGoal?'red':'blue';prepareKickoff(team);showKickoff();renderer.render(scene,camera);return;}else resetRound();}}else{
 if(shield>0&&closestAgent(redAgents,player.position).root.position.distanceTo(player.position)>2.3)shield=0;
 let move=new THREE.Vector3((keys.d||keys.arrowright?1:0)-(keys.q||keys.a||keys.arrowleft?1:0),0,(keys.s||keys.arrowdown?1:0)-(keys.z||keys.w||keys.arrowup?1:0));move.x+=pad.state.moveX;move.z+=pad.state.moveY;if(cameraMode===2)move.copy(proCamera.move(move));else move.set(move.z,0,-move.x);const intensity=slideTime>=0?0:Math.min(1,move.length()),moving=intensity>0;move.normalize();const speed=(keys.shift||pad.state.sprint?6.5:4.0)*(charging?.82:1)*(shield>.15?.55:pad.state.protect?.5:1)*intensity;playerVelocity.copy(move).multiplyScalar(speed);if(moving){player.position.addScaledVector(move,speed*dt);player.position.x=THREE.MathUtils.clamp(player.position.x,-33.2,33.2);player.position.z=THREE.MathUtils.clamp(player.position.z,-51.1,51.5);direction.copy(move);player.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);runPhase+=dt*speed*2.8;}player.position.y=moving?Math.abs(Math.sin(runPhase))*.027:0;updateSlide(dt);

 if(!owned&&!mateOwned&&!defenderOwned&&!keeper.saved&&!homeKeeper.saved&&cooldown<=0&&!shotLive&&ball.position.y<.85){
  if(passTarget!=='mate')teammate=closestAgent(blueAgents,ball.position);
  const dp=ball.position.distanceTo(player.position),dm=ball.position.distanceTo(teammate.root.position);
  const mateCanTake=blueAgents.length>0&&!(passLive&&passTarget==='player'&&lastActor==='mate');
  if(mateCanTake&&dm<1.35&&(passTarget==='mate'||dm<dp-.12))receiveBall('mate');else if(dp<1.40)receiveBall('player');else if(mateCanTake&&dm<1.35)receiveBall('mate');
 }
 const threat=closestAgent(redAgents,player.position);const opponentOffset=threat.root.position.clone().sub(player.position);opponentOffset.y=0;
 const opponentDistance=opponentOffset.length();
 const backPressure=opponentDistance<1.95&&opponentOffset.normalize().dot(direction)<-.25;
 const shieldAllowed=slideTime<0&&!charging&&!footballer.kicking&&!keys.shift&&!pad.state.sprint;
 shieldDuel.update(dt,{owned,enabled:shieldAllowed,contact:backPressure||!!(pad.state.protect||keys.control),distance:opponentDistance});
 const shielding=owned&&shieldAllowed&&shieldDuel.protected;
 shield=shieldDuel.near?THREE.MathUtils.lerp(shield,shielding?1:0,1-Math.exp(-dt*(shielding?9:20))):0;
 if(backPressure){const cross=direction.x*opponentOffset.z-direction.z*opponentOffset.x;if(Math.abs(cross)>.12)shieldSide=Math.sign(cross);}
 if(shielding&&opponentDistance<2.6&&(pad.state.protect||keys.control)){
  const away=player.position.clone().sub(threat.root.position);away.y=0;if(away.lengthSq()>.01){direction.lerp(away.normalize(),1-Math.exp(-dt*5*shield)).normalize();player.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);}
 }
 if(owned){const carryDirection=direction.clone();if(shield>.1&&opponentDistance<2.6){const away=player.position.clone().sub(threat.root.position);away.y=0;if(away.lengthSq()>.01)carryDirection.lerp(away.normalize(),shield*.7).normalize();}const desired=player.position.clone().addScaledVector(carryDirection,.85-shield*.12);desired.y=radius;ball.position.lerp(desired,1-Math.exp(-dt*18));if(moving){ball.rotation.x-=move.z*speed*dt/radius;ball.rotation.z+=move.x*speed*dt/radius;}}
 if(charging)charge=Math.min(1,charge+dt*.85);
 }
 const blueCarrier=homeKeeper.saved?homeKeeper.group:mateOwned?teammate.root:player;
 const blueHolder=homeKeeper.saved?homeKeeper.holdPoint():mateOwned?teammate.root.position:player.position;
 const bluePlans=blueMovement.update(dt,{agents:blueAgents,members:blueRoots,carrier:blueCarrier,holder:blueHolder,enemies:redRoots,active:resetTimer<=0&&(owned||mateOwned||homeKeeper.saved||passLive&&passTarget!=='red')});
 const redPlans=redMovement.update(dt,{agents:redAgents,members:redRoots,carrier:keeper.saved?keeper.root:redCarrier.root,holder:keeper.saved?keeper.holdPoint():redCarrier.root.position,enemies:blueRoots,active:resetTimer<=0&&(defenderOwned||keeper.saved||!!redPassTarget)});
 const blueDefPlans=blueDefense.update(dt,{agents:blueAgents,enemies:redRoots,carrier:defenderOwned?redCarrier.root:null,ball:ball.position,velocity,free:!defenderOwned,human:player,active:resetTimer<=0&&!keeper.saved&&!homeKeeper.saved&&!owned&&!mateOwned&&!(passLive&&passTarget!=='red')});
 let aiAction=null;const bluePress=blueDefense.presser||closestAgent(blueAgents,ball.position);
 if(!mateOwned&&!owned&&passTarget!=='mate'&&!defenderOwned)teammate=bluePress;
 for(const blue of blueAgents){
  const selected=blue===teammate;
  const owner=keeper.saved?'keeper':homeKeeper.saved?'homeKeeper':defenderOwned?'defender':owned?'player':mateOwned?(selected?'mate':'player'):selected?'free':'player';
  const defensiveTarget=blueMovement.positionFor(blue.root,ball.position,true);
  const action=blue.update(dt,{defensePlan:blueDefPlans.get(blue),offense:selected&&mateOwned?blueOutlet(blue):null,teamGrid:blueMovement.grid,supportPlan:bluePlans.get(blue),defensiveTarget,enemies:[...redRoots,...blueAgents.filter(a=>a!==blue).map(a=>a.root)],defendCover:!owned&&!mateOwned&&!homeKeeper.saved&&!(passLive&&passTarget==='mate')&&blue!==bluePress,active:resetTimer<=0,celebrate:wasGoal&&resetTimer>0,owner,player:mateOwned&&!selected?teammate.root.position:player.position,ball:ball.position,ballVelocity:velocity,shotLive,passTarget:selected?passTarget:'player'});
  if(selected)aiAction=action;
 }
 if(mateOwned&&resetTimer<=0){const desired=teammate.root.position.clone().addScaledVector(teammate.direction,.70);desired.y=radius;ball.position.lerp(desired,1-Math.exp(-dt*18));ball.rotation.x+=teammate.velocity.z*dt/radius;ball.rotation.z-=teammate.velocity.x*dt/radius;}
 if(aiAction&&resetTimer<=0){if(aiAction.type==='pass'&&mateOwned)sendTeamPass('mate',aiAction.recipient?'mate':'player',aiAction.kind||'pass',.45,aiAction.recipient);if(aiAction.type==='shoot'&&mateOwned)teammateShoot();}
 if(keeperPass&&!keeperPass.home&&!owned&&!mateOwned&&cooldown<=0&&ball.position.y<.85){const receiver=redAgents.find(a=>'red'+a.number===keeperPass.receiver)||defender;if(receiver.root.position.distanceTo(ball.position)<1.45){redCarrier=receiver;defenderOwned=true;passLive=false;passTarget=null;keeperPass=null;velocity.set(0,0,0);controlGrace=1.05;cooldown=.55;receiver.receive();notify('Les rouges contrôlent la relance.');}}
 if(redPassTarget&&!owned&&!mateOwned&&!defenderOwned&&cooldown<=0&&ball.position.y<.85&&redPassTarget.root.position.distanceTo(ball.position)<1.35){redCarrier=redPassTarget;redPassTarget=null;defenderOwned=true;passLive=false;passTarget=null;velocity.set(0,0,0);controlGrace=1.05;cooldown=.4;redCarrier.receive();}
 const redDefPlans=redDefense.update(dt,{agents:redAgents,enemies:blueRoots,carrier:owned?player:mateOwned?teammate.root:null,ball:ball.position,velocity,free:!owned&&!mateOwned,active:resetTimer<=0&&!keeper.saved&&!homeKeeper.saved&&!defenderOwned&&!redPassTarget&&!(keeperPass&&!keeperPass.home)});
 const nearest=redDefense.presser||closestAgent(redAgents,ball.position);pressPlayer=nearest;

 for(const red of redAgents){
  const receiving=redPassTarget===red||keeperPass&&!keeperPass.home&&keeperPass.receiver==='red'+red.number;
  const markOptions=blueRoots.filter(r=>r!==(owned?player:mateOwned?teammate.root:null));const markerIndex=redAgents.filter(a=>a!==nearest).indexOf(red);
  const cover=receiving?ball.position.clone():!defenderOwned&&red!==nearest?redMovement.positionFor(red.root,ball.position,true):null;
  const act=red.update(dt,{carrierRoot:owned?player:mateOwned?teammate.root:null,defensePlan:redDefPlans.get(red),teamGrid:redMovement.grid,supportPlan:receiving?null:redPlans.get(red),enemies:blueRoots,ally:redOutlet(red)?.root,obstacles:[...blueRoots,...redAgents.filter(a=>a!==red).map(a=>a.root)],canChallenge:redDefense.presser===red&&controlGrace<=0&&!redPassTarget&&!keeper.saved&&!homeKeeper.saved,active:resetTimer<=0,owns:defenderOwned&&redCarrier===red,allyOwns:defenderOwned&&redCarrier!==red||!!redPassTarget&&redPassTarget!==red,coverTarget:cover,ball:ball.position,ballVelocity:velocity,free:!owned&&!mateOwned,protected:owned&&shieldDuel.protected,shieldCenter:owned&&shield>.35&&red===nearest?player.position:null});
  if(act==='win'&&!defenderOwned)defenderWins(red);
  if(act==='shoot'&&redCarrier===red)enemyShoot();if(act==='pass'&&redCarrier===red)enemyPass();
 }
 separatePlayers(fieldRoots,owned?player:mateOwned?teammate.root:defenderOwned?redCarrier.root:null);
 if(defenderOwned&&resetTimer<=0){
  const at=redCarrier.root.position.clone().addScaledVector(redCarrier.direction,.73);at.y=radius;ball.position.lerp(at,1-Math.exp(-dt*20));
  // No automatic theft merely because two bodies overlap: a deliberate AI
  // challenge requires a readable wind-up and has its own recovery timer.
  const challenger=blueDefense.presser;const gap=challenger?challenger.root.position.distanceTo(ball.position):Infinity;if(aiChallengeActor!==challenger){aiChallenge=0;aiChallengeActor=challenger;}
  if(challenger&&controlGrace<=0&&gap<1.35&&ball.position.y<.7&&challenger.direction.dot(ball.position.clone().sub(challenger.root.position).normalize())>.2&&aiChallengeCooldown<=0){aiChallenge+=dt;if(aiChallenge> .30){challenger.avatar.kick();aiChallengeCooldown=1.6;aiChallenge=0;if(gap<1.15){teammate=challenger;receiveBall('mate');}}}else aiChallenge=0;
 }
 if(clearanceLive){clearanceAge+=dt;if(clearanceAge>4&&resetTimer<=0){clearanceLive=false;resetTimer=1.2;notify('Dégagement réussi. Nouvelle attaque !');}}
 if(!owned&&!mateOwned&&!defenderOwned&&!keeper.saved&&!homeKeeper.saved){const prev=ball.position.clone();velocity.y-=9.8*dt;ball.position.addScaledVector(velocity,dt);ball.rotation.x+=velocity.z*dt/radius;ball.rotation.z-=velocity.x*dt/radius;
 if(ball.position.y<radius){ball.position.y=radius;if(Math.abs(velocity.y)>1.05)velocity.y*=-.47;else velocity.y=0;const friction=Math.exp(-dt*(passLive?.45:1.25));velocity.x*=friction;velocity.z*=friction;}
 if((shotLive||passLive)&&!enemyShot&&(!keeperPass||keeperPass.home)&&!redPassTarget&&cooldown<=0&&resetTimer<=0){for(const red of redAgents){if(red.intercept(prev,ball.position)){defenderWins(red);break;}}}
 if((shotLive||passLive)&&!keeperPass&&!enemyShot&&keeper.checkSave(prev,ball.position,radius)){saves++;shotLive=false;passLive=false;pad.pulse(.32,130);velocity.set(0,0,0);ball.position.copy(keeper.holdPoint());updateScore();prepareDistribution(false);}
 if(enemyShot&&homeKeeper.checkSave(prev,ball.position,radius)){homeSaves++;enemyShot=false;shotLive=false;velocity.set(0,0,0);ball.position.copy(homeKeeper.holdPoint());prepareDistribution(true);}
 // Both ends use the same post and crossbar rebound rules.
 for(const x of [-halfGoal,halfGoal]){const dx=ball.position.x-x,dz=ball.position.z-52.5,dist=Math.hypot(dx,dz);if(dist<radius+.065&&ball.position.y<goalH+.1){const n=new THREE.Vector3(dx/(dist||1),0,dz/(dist||1));velocity.addScaledVector(n,-1.65*velocity.dot(n));ball.position.x=x+n.x*(radius+.07);ball.position.z=52.5+n.z*(radius+.07);}}
 if(Math.abs(ball.position.x)<halfGoal+.05){const dy=ball.position.y-goalH,dz=ball.position.z-52.5,dist=Math.hypot(dy,dz);if(dist<radius+.065){const n=new THREE.Vector3(0,dy/(dist||1),dz/(dist||1));velocity.addScaledVector(n,-1.65*velocity.dot(n));ball.position.y=goalH+n.y*(radius+.07);ball.position.z=52.5+n.z*(radius+.07);}}
 if(enemyShot&&prev.z<52.5&&ball.position.z>=52.5){const a=(52.5-prev.z)/(ball.position.z-prev.z),x=THREE.MathUtils.lerp(prev.x,ball.position.x,a),y=THREE.MathUtils.lerp(prev.y,ball.position.y,a);if(Math.abs(x)<halfGoal-radius&&y<goalH-radius&&y>=radius*.8)enemyGoal();else{enemyShot=false;shotLive=false;resetTimer=2;notify('Frappe adverse à côté !');}}
 // Cylindrical post and crossbar contacts before testing the goal line.
 for(const x of [-halfGoal,halfGoal]){const dx=ball.position.x-x,dz=ball.position.z-goalZ,dist=Math.hypot(dx,dz);if(dist<radius+.065&&ball.position.y<goalH+.1){const n=new THREE.Vector3(dx/(dist||1),0,dz/(dist||1));velocity.addScaledVector(n,-1.65*velocity.dot(n));ball.position.x=x+n.x*(radius+.07);ball.position.z=goalZ+n.z*(radius+.07);notify('Le poteau !');}}
 if(Math.abs(ball.position.x)<halfGoal+.05){const dy=ball.position.y-goalH,dz=ball.position.z-goalZ,dist=Math.hypot(dy,dz);if(dist<radius+.065){const n=new THREE.Vector3(0,dy/(dist||1),dz/(dist||1));velocity.addScaledVector(n,-1.65*velocity.dot(n));ball.position.y=goalH+n.y*(radius+.07);ball.position.z=goalZ+n.z*(radius+.07);notify('La barre !');}}
 if((shotLive||passLive)&&prev.z>goalZ&&ball.position.z<=goalZ){const a=(prev.z-goalZ)/(prev.z-ball.position.z),crossX=THREE.MathUtils.lerp(prev.x,ball.position.x,a),crossY=THREE.MathUtils.lerp(prev.y,ball.position.y,a);if(Math.abs(crossX)<halfGoal-radius&&crossY<goalH-radius&&crossY>=radius*.8)goal();else{shotLive=false;passLive=false;resetTimer=2;notify('À côté ! Le prochain sera le bon.');}}
 if(wasGoal){if(ball.position.z<netZ+radius){ball.position.z=netZ+radius;velocity.z=Math.abs(velocity.z)*.15;velocity.x*=.35;velocity.y*=.4;}if(Math.abs(ball.position.x)>halfGoal-radius){ball.position.x=Math.sign(ball.position.x)*(halfGoal-radius);velocity.x*=-.2;}}
 if(shotLive||passLive){shotAge+=dt;if(shotAge>7&&!keeperPass){shotLive=false;passLive=false;resetTimer=1.8;notify('Récupère le ballon pour une nouvelle frappe.');}}
 if(!wasGoal&&(Math.abs(ball.position.x)>36||ball.position.z>55.5||ball.position.z<-57.5)&&resetTimer<=0){resetTimer=1.6;shotLive=false;passLive=false;notify('Ballon sorti. On recommence !');}
 }
}
footballer.update(dt,{moving:started&&resetTimer<=0&&!!(keys.d||keys.q||keys.a||keys.s||keys.z||keys.w||keys.arrowup||keys.arrowdown||keys.arrowleft||keys.arrowright||Math.hypot(pad.state.moveX,pad.state.moveY)>.01),sprint:!!keys.shift||pad.state.sprint,goal:wasGoal&&resetTimer>0,shield:owned?shield:0,shieldSide,slide:slideTime});
for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.v.y-=5*dt;p.m.position.addScaledVector(p.v,dt);p.m.rotation.x+=dt*4;p.m.rotation.y+=dt*2;if(p.life<=0){scene.remove(p.m);p.m.geometry.dispose();p.m.material.dispose();particles.splice(i,1);}}
selectRing.position.set(player.position.x,.075,player.position.z);ballShadow.position.set(ball.position.x,.082,ball.position.z);ballShadow.scale.setScalar(1+ball.position.y*.32);ballShadow.material.opacity=.29/(1+ball.position.y*.3);target.position.set(aim.x,aim.y,goalZ+.065);target.visible=started&&resetTimer<=0&&(owned||charging);aimRing.material.color.set(Math.abs(aim.x)<3.3&&aim.y<2.1?'#e4fa87':'#ed9866');
$('powerFill').style.width=(charging?charge*100:owned&&shieldDuel.active?shieldDuel.remaining/shieldDuel.duration*100:0)+'%';$('powerText').textContent=charging?Math.round(charge*100)+' %':resetTimer>0?(homeKeeper.saved?'TON GARDIEN !':keeper.saved?'ARRÊT':enemyScored?'BUT ADVERSE':wasGoal?'BUT !':'REESSAIE'):defenderOwned?'ADVERSAIRE':mateOwned?'APPEL : E / A':owned?(shieldDuel.protected?shieldDuel.remaining.toFixed(1)+' s':shieldDuel.exhausted?'FATIGUÉ':'PRÊT'):'EN JEU';$('ballState').textContent=charging?(actionKind==='pass'?'PASSE AU SOL':actionKind==='cross'?'PASSE LOBÉE':actionKind==='through'?'PASSE EN PROFONDEUR':shotStyle==='finesse'?'TIR PLACÉ':shotStyle==='chip'?'TIR LOBÉ':'FRAPPE EN PRÉPARATION'):homeKeeper.saved?(homeKeeper.animationState==='throw'?'TON GARDIEN RELANCE À LA MAIN':'TON GARDIEN GARDE LE BALLON'):keeper.saved?(keeper.animationState==='throw'?'RELANCE ADVERSE À LA MAIN':'LE GARDIEN GARDE LE BALLON'):defenderOwned?'LES ROUGES ATTAQUENT':mateOwned?'N°'+teammate.number+' · '+teammate.status.toUpperCase():owned?(shieldDuel.exhausted?'PROTECTION ÉPUISÉE':shield>.35?'PROTECTION DE BALLE':'BALLON AU PIED'):'VA CHERCHER LE BALLON';
document.querySelector('.power-help').textContent=distribution?'DÉMARQUE-TOI · RELANCE À LA MAIN':defenderOwned?'B / ○ : TACLE · X / □ : TACLE GLISSÉ':mateOwned?'E / A / ✕ : APPEL · ESPACE / B / ○ : FRAPPE':pad.state.connected&&pad.state.active?(charging&&actionKind!=='shoot'?'MAINTENIR · RELÂCHER POUR PASSER':'MAINTENIR '+(pad.state.layout==='ps'?'ROND':'B')+' · STICK GAUCHE POUR VISER'):'MAINTENIR ESPACE · RELÂCHER POUR TIRER';
const activeRed=defenderOwned?redCarrier:closestAgent(redAgents,ball.position);document.querySelector('.defender-panel>b').textContent=String(activeRed.number);$('defenderState').textContent=activeRed.status;$('defenderStats').textContent=recoveries+' récup. · '+homeSaves+' arrêts bleus';
const hudMate=owned?chooseBluePass():teammate;document.querySelector('.mate-line>b').textContent=hudMate.number;$('mateState').textContent=hudMate.status;$('teamPasses').textContent=String(completedPasses).padStart(2,'0');$('teamPassBtn').innerHTML='<kbd>'+(pad.state.active?(pad.state.layout==='ps'?'✕':'A'):'E')+'</kbd> '+(mateOwned?'Demander le ballon':'Passe au n°'+hudMate.number);
$('runBtn').disabled=!owned||runCooldown>0;$('runBtn').innerHTML='<kbd>'+(pad.state.active?'L3':'G')+'</kbd> '+(runCooldown>0?'Appel en cours…':'Appel en profondeur');
 homeKeeper.group.children[0].getWorldPosition(radarKeeperPosition);radar.update([{position:player.position,color:'#d5fb77',human:true},...blueAgents.map(a=>({position:a.root.position,color:'#69c9f0'})),...redAgents.map(a=>({position:a.root.position,color:'#ef836c'})),{position:keeper.root.position,color:'#f4b567'},{position:radarKeeperPosition,color:'#bea5e8'}],ball.position);
// One broadcast axis for both teams, saves and throws. No possession-driven cuts.
const desiredFocus=cameraMode===1?0:THREE.MathUtils.clamp(ball.position.z*.8,-43.5,43.5);
cameraFocusZ=THREE.MathUtils.damp(cameraFocusZ,desiredFocus,2.3,dt);
const portraitScale=Math.max(1,1.35/camera.aspect),wide=cameraMode===1?1.52:1;
cameraTarget.set(34*wide*portraitScale,70*wide*portraitScale,cameraFocusZ);lookTarget.set(0,.4,cameraFocusZ);
if(!started){cameraTarget.set(34,85,0);lookTarget.set(0,0,0);}
if(started&&cameraMode===2){proCamera.update(dt,player,direction,playerVelocity.length());}else{camera.position.lerp(cameraTarget,1-Math.exp(-dt*2.3));camera.lookAt(0,.4,camera.position.z);}renderer.render(scene,camera);
}
animate();addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
window.__football={matchIntro,prepareKickoff:(team)=>{prepareKickoff(team);showKickoff();},get kickoff(){return kickoff?{...kickoff}:null},dugouts,proCamera,changeCamera,get cameraMode(){return cameraMode},blueDefense,redDefense,blueOutlet,sendTeamPass,blueMovement,redMovement,callRun,chooseBluePass,get runCooldown(){return runCooldown},blueAgents,redAgents,fieldRoots,get activeTeammate(){return teammate},stadium,camera,startSlide,get controlGrace(){return controlGrace},get redPassTarget(){return redPassTarget?.number??null},get slideWon(){return slideWon},get slideTime(){return slideTime},get slideCooldown(){return slideCooldown},get distribution(){return distribution?.home?'home':distribution?'away':null},get keeperPass(){return keeperPass},get throwsCompleted(){return throwsCompleted},get shield(){return shield},shieldDuel,scene,player,footballer,keeper,homeKeeper,teammate,defender,opponent,pad,get enemyGoals(){return enemyGoals},get homeSaves(){return homeSaves},get enemyShot(){return enemyShot},get defenderOwned(){return defenderOwned},get recoveries(){return recoveries},get clearances(){return clearances},get mateOwned(){return mateOwned},get owner(){return homeKeeper.saved?'homeKeeper':keeper.saved?'keeper':defenderOwned?'defender':owned?'player':mateOwned?'mate':'free'},get completedPasses(){return completedPasses},get mateGoals(){return mateGoals},get playerAssists(){return playerAssists},get lastActor(){return lastActor},get passTarget(){return passTarget},quickPass,get paused(){return paused},get passLive(){return passLive},get charge(){return charge},get charging(){return charging},get shotStyle(){return shotStyle},get actionKind(){return actionKind},get saves(){return saves},get avatarReady(){return avatarReady},ball,aim,beginCharge,shoot,resetRound,get goals(){return goals},get shots(){return shots},get started(){return started},get owned(){return owned}};

playerEditor=createPlayerEditor({avatar:footballer,onOpen:()=>{charging=false;charge=0;for(const k in keys)keys[k]=false;}});$('playerMenuBtn').onclick=$('customizeIntro').onclick=()=>playerEditor.open();window.__football.playerEditor=playerEditor;
