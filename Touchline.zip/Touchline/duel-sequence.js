// Small readable duel: yield 2.5 metres, plant, press, attempt one standing tackle.
export function createDuelSequence(){
 let mode='idle',age=0,startZ=0,endZ=0,contactSent=false;
 const enter=next=>{mode=next;age=0;contactSent=false;};
 return {get mode(){return mode},get retreatDistance(){return startZ-endZ},
 reset(){mode='idle';age=0;startZ=endZ=0;contactSent=false;},
 beginTackle(){if(mode==='press'||mode==='idle'){enter('tackle');return true;}return false;},
 update(dt,{position,ball,fixing,free,owns,active=true}){
  if(!active)return {mode,retreatZ:endZ,contact:false};
  age+=dt;let contact=false;
  if(owns){enter('idle');return {mode,retreatZ:endZ,contact};}
  const gap=Math.hypot(ball.x-position.x,ball.z-position.z);
  if(mode==='idle'&&fixing&&!free){startZ=position.z;endZ=Math.max(-49,startZ-2.5);enter('retreat');}
  else if(mode==='retreat'){
   if(free){enter('press');}
   else if(!fixing||gap>8){enter('recover');}
   else if(position.z<=endZ+.035||age>3){enter('plant');}
  }else if(mode==='plant'&&age>=.16){enter('press');}
  else if(mode==='press'&&age>4){enter('recover');}
  else if(mode==='tackle'){
   if(age>=.12&&!contactSent){contact=true;contactSent=true;}
   if(age>=.36)enter('recover');
  }else if(mode==='recover'&&age>=.7){enter('idle');}
  return {mode,retreatZ:endZ,contact,age};
 }
 };
}
