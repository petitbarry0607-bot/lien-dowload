import * as THREE from 'three';
// Compact, ball-relative defensive lines. Do not interpolate towards the goal:
// that made the entire team retreat unnecessarily when the ball was far away.
export function createDefense(sign){
 const plans=new Map();let presser=null,lock=0,line=9;
 const depth=p=>-sign*p.z;
 const clamp=p=>{p.x=THREE.MathUtils.clamp(p.x,-32,32);p.z=THREE.MathUtils.clamp(p.z,-49.3,49.3);p.y=0;return p;};
 const back=a=>a.root.userData.tacticalRole==='back'||a.root.userData.tacticalRole.startsWith('full');
 const laneFor=root=>(root.userData.tacticalLane??({fullLeft:-13,fullRight:13,midLeft:-5,midRight:5,left:-13,right:13}[root.userData.tacticalRole]||0))*1.7;
 return {get plans(){return plans},get presser(){return presser},get lineDepth(){return line},reset(){plans.clear();presser=null;lock=0;line=9;},
  update(dt,{agents,enemies,carrier,ball,velocity,free,active,human=null}){
   plans.clear();if(!active||!agents.length){presser=null;lock=0;return plans;}lock-=dt;
   const ballDepth=depth(ball),incoming=free?THREE.MathUtils.clamp(-sign*velocity.z*.35,0,6):0;
   line=THREE.MathUtils.clamp(ballDepth+9+incoming,-12,ballDepth>37?49:44);
   const score=a=>a.root.position.distanceTo(ball)+(back(a)&&ballDepth<28?6:0);
   const candidate=agents.reduce((a,b)=>score(a)<score(b)?a:b);
   const humanPress=human&&human.position.distanceTo(ball)<3.5&&human.position.distanceTo(ball)<candidate.root.position.distanceTo(ball)+.5;
   const beaten=presser&&(depth(presser.root.position)<ballDepth-2||presser.root.position.distanceTo(ball)>12);
   if(humanPress){presser=null;lock=0;}else if(!presser||!agents.includes(presser)||(lock<=0||beaten)&&score(candidate)+1.6<score(presser)){presser=candidate;lock=.8;}
   const coverAgent=agents.filter(a=>a!==presser&&back(a)).sort((a,b)=>Math.abs(a.root.position.x-ball.x)-Math.abs(b.root.position.x-ball.x))[0];
   const helper=agents.filter(a=>a!==presser&&!back(a)&&a.root.userData.tacticalRole.startsWith('mid')&&a.root.position.distanceTo(ball)<12).sort((a,b)=>a.root.position.distanceTo(ball)-b.root.position.distanceTo(ball))[0];
   const used=new Set();
   for(const a of agents){
    const root=a.root,r=root.userData.tacticalRole,lane=laneFor(root);let target,kind='screen',threat=null;
    if(a===presser){
     kind=free?'intercept':'press';target=ball.clone();
     if(free){target.addScaledVector(velocity,.18);for(const t of [.12,.24,.36,.5,.65]){const p=ball.clone().addScaledVector(velocity,t);p.y=0;const height=ball.y+velocity.y*t-4.9*t*t;if(height<.85&&root.position.distanceTo(p)<5*t+1.1){target=p;break;}}}
     else{target.z-=sign*.95;target.x+=Math.sign(ball.x)*.12;}
    }else{
     const halfWidth=r==='back'?7:r.startsWith('full')?8:r.startsWith('mid')?7:9;
     const lo=Math.max(-31,lane-halfWidth),hi=Math.min(31,lane+halfWidth);
     const candidates=enemies.filter(e=>e!==carrier&&!used.has(e)&&e.position.x>=lo&&e.position.x<=hi&&Math.abs(depth(e.position)-ballDepth)<22);
     candidates.sort((a,b)=>root.position.distanceTo(a.position)-root.position.distanceTo(b.position));threat=candidates[0]||null;
     let d=back(a)?line:r.startsWith('mid')?Math.min(line-5,ballDepth+2):ballDepth-3;
     let x=THREE.MathUtils.clamp(lane+ball.x*.12,lo,hi);
     if(threat){
      x=THREE.MathUtils.clamp(threat.position.x*.65+ball.x*.18+lane*.17,lo,hi);
      const runSpeed=-sign*(threat.userData?.velocity?.z||0);
      const runBehind=back(a)&&depth(threat.position)>line-1&&(ballDepth>18||free&&incoming>1||runSpeed>1.5&&threat.position.distanceTo(ball)<26);
      if(runBehind){d=Math.min(49,Math.max(line,Math.min(line+6,depth(threat.position)+1.5)));kind='cover';}
      // Mark in front of the defensive line, never follow an irrelevant runner
      // all the way back to the penalty area.
      else if(!back(a))d=THREE.MathUtils.clamp(depth(threat.position)+1.3,ballDepth-2,line-5);
      used.add(threat);
     }
     if(a===coverAgent){kind='cover';d=Math.max(d,line);}
     if(back(a)&&kind!=='cover')kind='hold';
     if(a===helper&&presser&&ballDepth<36){x=THREE.MathUtils.clamp(ball.x+(lane<=ball.x?-4.5:4.5),lo,hi);d=ballDepth+3;kind='screen';}
     target=new THREE.Vector3(x,0,-sign*THREE.MathUtils.clamp(d,-20,49));
    }
    const distance=root.position.distanceTo(target);
    plans.set(a,{target:clamp(target),kind,pressing:a===presser,threat,speed:a===presser?5:distance>7?5.2:4.6});
   }
   return plans;
  }
 };
}
