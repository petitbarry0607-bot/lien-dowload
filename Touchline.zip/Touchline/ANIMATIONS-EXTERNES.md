# Pack proposé par l’utilisateur — inspection

Catalogue : https://techlabid.github.io/techlabid/free-3d-assets/

Pack inspecté : MPlayer Run Backward Arc Right.
Téléchargement : https://github.com/TechLabID/techlabid/releases/download/V5.3-Mplayer-asset/MPlayer_RunBackwardArcRight-3D-Asset.zip

L’archive contient un FBX, un GLB animé, un OBJ, des textures, un aperçu, un README et License.txt. Le GLB contient une animation nommée MPlayer_RunBackwardArcRight et 195 canaux. Ses articulations portent des noms tels que TechLabID:Head, TechLabID:LeftForeArm et TechLabID:LeftHand. Le joueur de Touchline utilise un autre squelette : retargeting et vérification des axes et des appuis nécessaires.

La licence fournie autorise les projets personnels et commerciaux et la modification, mais interdit la redistribution des fichiers d’origine comme assets autonomes. Attribution appréciée : « 3D Asset by TechLabID ». Ces indications rapportent le texte fourni par l’éditeur, sans vérification indépendante des droits sur les composants tiers.

**Statut : inspecté, non intégré au jeu.** Aucune nouvelle animation du pack n’est revendiquée comme installée. La version actuelle conserve les animations Quaternius et les poses défensives procédurales déjà vérifiées. L’archive source n’est pas incluse dans le ZIP du jeu.

## Gardiens — intégration réalisée

Deux packs supplémentaires, GoalKeeper Breathing Idle et GoalKeeper Sidestep, sont désormais utilisés sous forme de courbes de mouvement adaptées aux cibles IK, sans importer leurs modèles. Voir assets/animations/README.md pour les liens, la méthode et la licence. Le pack Goalkeeper Catch est inspecté mais non intégré. Le statut « non intégré » ci-dessus concerne le pack de recul MPlayer, pas ces deux packs de gardien.
