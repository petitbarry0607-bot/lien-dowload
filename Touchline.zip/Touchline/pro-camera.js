import * as THREE from 'three';
// Comfort camera: fixed attacking heading and pitch. Player turns never orbit
// the camera; movement input cannot feed back into its own rotating basis.
export function createProCamera(camera){
 let ready=false;const focus=new THREE.Vector3(),desired=new THREE.Vector3();
 const clamp=THREE.MathUtils.clamp;
 return {
  reset(){ready=false;},get yaw(){return 0;},
  move(input){return new THREE.Vector3(input.x,0,input.z);},
  update(dt,player,direction,speed){
   const portrait=Math.max(1,1.05/camera.aspect),distance=8.2*portrait,height=4.2;
   // Ignore the player's running bob and all speed-dependent lens effects.
   desired.set(player.position.x,0,player.position.z);
   if(!ready){focus.copy(desired);ready=true;}
   else focus.lerp(desired,1-Math.exp(-Math.min(dt,.05)*7));
   camera.position.set(clamp(focus.x,-35,35),height,clamp(focus.z+distance,-55.5,58.5));
   // Translate eye and look point together: no lateral rocking or pitch pumping.
   camera.lookAt(camera.position.x,height-3.05,camera.position.z-distance-3.5);
   if(camera.fov!==60){camera.fov=60;camera.updateProjectionMatrix();}
  }
 };
}
