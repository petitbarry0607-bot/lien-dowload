import * as THREE from 'three';
import {addCrowd} from './crowd.js';
import {FBXLoader} from './vendor/FBXLoader.js';
export const stadiumChoices=[...Array.from({length:4},(_,i)=>({file:`Fst_Eng_00${i+1}.FBX`,name:`Angleterre ${i+1}`})),...['001','002','003','014'].map((n,i)=>({file:`FSt_Esp_${n}.FBX`,name:`Espagne ${i+1}`})),...Array.from({length:4},(_,i)=>({file:`FSt_Fra_00${i+1}.FBX`,name:`France ${i+1}`})),...Array.from({length:4},(_,i)=>({file:`FSt_Ita_00${i+1}.FBX`,name:`Italie ${i+1}`}))];
export function createStadium(scene){
 let current=null,serial=0;
 function dispose(group){group?.traverse(o=>{if(o.isMesh){if(o.isInstancedMesh)o.dispose();o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map?.dispose();m.dispose();});}});}
 async function load(file){
  const request=++serial;
  const manager=new THREE.LoadingManager();manager.setURLModifier(url=>/\.jpg|\.png/i.test(url)?'./assets/stadiums/Pitch.jpg':url);
  const source=await new FBXLoader(manager).loadAsync('./assets/stadiums/'+file);source.updateMatrixWorld(true);
  const pitch=new THREE.Box3();source.traverse(mesh=>{if(!mesh.isMesh)return;const mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];for(const g of mesh.geometry.groups){if(!/MainMaterial/i.test(mats[g.materialIndex]?.name))continue;for(let i=g.start;i<g.start+g.count;i++){const n=mesh.geometry.index?mesh.geometry.index.getX(i):i;pitch.expandByPoint(new THREE.Vector3().fromBufferAttribute(mesh.geometry.attributes.position,n).applyMatrix4(mesh.matrixWorld));}}});
  if(pitch.isEmpty()){dispose(source);throw Error('Surface du stade introuvable');}
  const center=pitch.getCenter(new THREE.Vector3()),span=pitch.getSize(new THREE.Vector3());
  const rotate=span.x>span.z,sx=72/(rotate?span.z:span.x),sz=111/(rotate?span.x:span.z),sy=Math.min(sx,sz)*.65;
  const group=new THREE.Group();group.name='ImportedStadium';group.userData.file=file;let triangles=0;
  source.traverse(mesh=>{
   if(!mesh.isMesh)return;const src=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();src.applyMatrix4(mesh.matrixWorld);const pos=src.attributes.position,normal=src.attributes.normal,mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];
   const buckets=new Map();
   for(const g of src.groups){if(/MainMaterial/i.test(mats[g.materialIndex]?.name))continue;for(let i=g.start;i<g.start+g.count;i+=3){const points=[0,1,2].map(k=>new THREE.Vector3().fromBufferAttribute(pos,i+k));const y=Math.max(...points.map(p=>p.y));if(y<center.y-12)continue;
    for(const p of points){p.sub(center);if(rotate){const x=p.x;p.x=p.z;p.z=-x;}p.set(p.x*sx,p.y*sy,p.z*sz);
     // Recess the complete bowl by six metres at the touchlines/end lines;
     // preserve the playable field, stands and roof without cutting geometry.
     p.x+=THREE.MathUtils.clamp(p.x/34,-1,1)*6;
     p.z+=THREE.MathUtils.clamp(p.z/52.5,-1,1)*6;}
    if(!buckets.has(g.materialIndex))buckets.set(g.materialIndex,{p:[],n:[]});const bucket=buckets.get(g.materialIndex);
    points.forEach((p,k)=>{bucket.p.push(...p.toArray());const n=normal?new THREE.Vector3().fromBufferAttribute(normal,i+k):new THREE.Vector3(0,1,0);if(rotate){const x=n.x;n.x=n.z;n.z=-x;}n.set(n.x/sx,n.y/sy,n.z/sz).normalize();bucket.n.push(...n.toArray());});triangles++;
   }}
   for(const [index,bucket] of buckets){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(bucket.p,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(bucket.n,3));geometry.computeVertexNormals();geometry.computeBoundingSphere();const original=mats[index];const material=new THREE.MeshStandardMaterial({color:original.color||'#b7bcba',roughness:.86,side:THREE.DoubleSide});const part=new THREE.Mesh(geometry,material);part.receiveShadow=true;part.castShadow=false;group.add(part);}
   src.dispose();
  });
  dispose(source);
  if(request!==serial){dispose(group);return null;}
  if(current){scene.remove(current);dispose(current);}current=group;scene.add(group);
  for(const o of scene.children)if(o.userData.oldScenery)o.visible=false;
  addCrowd(group);
  group.userData.triangles=triangles;
  return {file,triangles,parts:group.children.length};
 }
 return {load,get group(){return current}};
}
