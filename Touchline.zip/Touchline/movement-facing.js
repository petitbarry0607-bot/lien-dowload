// Rotate through the shortest angle, including exact 180-degree turns.
// Normalized vector lerp can remain stuck facing the opposite direction.
export function turnToward(direction,facing,dt,rate=14){
 if(facing.x*facing.x+facing.z*facing.z<.0001)return;
 const current=Math.atan2(direction.x,direction.z),wanted=Math.atan2(facing.x,facing.z);
 const delta=Math.atan2(Math.sin(wanted-current),Math.cos(wanted-current));
 const angle=current+delta*(1-Math.exp(-Math.max(0,dt)*rate));
 direction.set(Math.sin(angle),0,Math.cos(angle));
}
export function defensiveFacing(position,velocity,ball){
 // No defensive backsteps: all moving players face their travel direction.
 if(velocity.lengthSq()>.15*.15)return velocity;
 const toBall=ball.clone().sub(position);toBall.y=0;return toBall;
}
