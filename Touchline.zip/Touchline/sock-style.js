import * as THREE from 'three';
// Height is stored in the bind pose, so the cuff follows the leg when animated.
// A shader boundary avoids the colour gradients of per-vertex sock painting.
export function createSockStyle(){
 const heights={short:55,medium:91,long:155};
 const uniforms={sockTop:{value:155},sockSkin:{value:new THREE.Color('#754a36')},sockFabric:{value:new THREE.Color('#0b2042')},sockCuff:{value:new THREE.Color('#eef4dc')}};
 return {
  update(profile){uniforms.sockTop.value=heights[profile.sockLength]??heights.long;uniforms.sockSkin.value.set(profile.skinTone||'#754a36');},
  apply(material){
   material.onBeforeCompile=shader=>{
    Object.assign(shader.uniforms,uniforms);
    shader.vertexShader='attribute float sockBindHeight;\nvarying float vSockHeight;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvSockHeight = sockBindHeight;');
    shader.fragmentShader='uniform float sockTop;\nuniform vec3 sockSkin;\nuniform vec3 sockFabric;\nuniform vec3 sockCuff;\nvarying float vSockHeight;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
     if(vSockHeight > 20.0 && vSockHeight < 180.0){
      if(vSockHeight > sockTop) diffuseColor.rgb = sockSkin;
      else if(vSockHeight > sockTop - 6.0) diffuseColor.rgb = sockCuff;
      else diffuseColor.rgb = sockFabric;
     }`);
   };
   material.customProgramCacheKey=()=> 'touchline-sock-height-v1';
  }
 };
}
