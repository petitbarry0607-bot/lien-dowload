import {keeperMotion} from './assets/animations/keeper-motion.js';
// Adapted source curves drive IK, not the source skeleton or root translation.
export function sampleKeeperMotion(name,time){
 const clip=keeperMotion[name],t=((time%clip.duration)+clip.duration)%clip.duration;
 const f=t/clip.duration*(clip.frames.length-1),i=Math.floor(f),w=f-i;
 const a=clip.frames[i],b=clip.frames[Math.min(i+1,clip.frames.length-1)];
 return a.map((v,k)=>v+(b[k]-v)*w);
}
export const keeperStepDuration=keeperMotion.sidestep.duration;
