import {laneClear} from './tactics.js';
// Evaluate real receivers, not a mandatory return pass to the human.
export function chooseOutlet(actor,receivers,enemies,sign){
 const at=actor.position,pressure=Math.min(20,...enemies.map(e=>e.position.distanceTo(at)));
 let best=null;
 for(const receiver of receivers){
  const root=receiver.root,p=root.position,distance=at.distanceTo(p);
  if(root===actor||distance<3.5||distance>55)continue;
  const safe=laneClear(at,p,enemies,1.05),space=Math.min(8,...enemies.map(e=>e.position.distanceTo(p)));
  const progress=(p.z-at.z)*sign,goalDistance=52.5-p.z*sign;
  const switchPlay=at.x*p.x< -55&&Math.abs(p.x-at.x)>18&&space>3;
  const cutback=at.z*sign>36.5&&Math.abs(at.x)>8&&Math.abs(p.x)<7&&goalDistance<18&&progress> -12;
  let score=(safe?22:-35)+Math.min(space,6)*2+Math.max(-8,Math.min(10,progress))*.9-distance*.24;
  if(switchPlay)score+=pressure<4?10:3;
  if(cutback)score+=16;
  if(space<2)score-=18;
  if(pressure<3&&progress<0&&safe)score+=8;
  if(score>(best?.score??-Infinity))best={...receiver,safe,space,progress,switchPlay,cutback,score,kind:progress>5&&root.userData?.velocity?.length()>2?'through':'pass'};
 }
 return best;
}
