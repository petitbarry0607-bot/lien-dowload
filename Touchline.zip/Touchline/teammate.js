import {turnToward} from './movement-facing.js';
import * as THREE from 'three';
import {createProbeNavigator,openShotTarget} from './probe-navigation.js';
import {laneClear,steerAvoid} from './tactics.js';
import { createFootballer } from './character.js?v=duels2';

// Local football AI: support runs, interceptions, control, give-and-go decisions
// and shooting. It makes decisions from the current game state, not a fixed path.
export function createTeammate(scene,options={}){
 const root=new THREE.Group();root.name='Touchline_Teammate_7';root.position.set((options.x??4.8)*1.7,0,(options.z??3.8)*1.640625);scene.add(root);
 const avatar=createFootballer(root,{number:options.number??7,skinTone:'#a56e4d'});
 let runTime=0;const runTarget=new THREE.Vector3();
 const direction=new THREE.Vector3(0,0,-1),velocity=new THREE.Vector3(),target=new THREE.Vector3();
 const navigator=createProbeNavigator();root.userData.velocity=velocity;let shotTarget=null;let supportReview=0,recovering=0;const retreat=new THREE.Vector3();let mode='support',holdTime=0,receiveDelay=0,requestPassTime=0,requestShotTime=0,pending=null,receiveCount=0,side=1,age=0;
 const ring=new THREE.Mesh(new THREE.RingGeometry(.49,.525,48),new THREE.MeshBasicMaterial({color:'#75dced',transparent:true,opacity:.8,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.076;root.add(ring);
 const canvas=document.createElement('canvas');canvas.width=256;canvas.height=72;const ctx=canvas.getContext('2d');ctx.fillStyle='#163f4de6';ctx.beginPath();ctx.roundRect(3,3,250,66,30);ctx.fill();ctx.fillStyle='#88e1ec';ctx.font='bold 22px Arial';ctx.textAlign='center';ctx.fillText((options.number??7)+' · COÉQUIPIER IA',128,47);const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;
 const label=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false}));label.scale.set(1.7,.48,1);label.position.y=2.25;root.add(label);
 const stateNames={hold:'Tient la ligne',press:'Cadre le porteur',screen:'Coupe la ligne de passe',cover:'Protège le but',wide:'Garde son couloir',unmark:'Sort du marquage',balance:'Soutien en retrait',run:'Appel en profondeur',support:'Se démarque',intercept:'Va recevoir la passe',chase:'Récupère le ballon',control:'Contrôle le ballon',carry:'Avance vers le but',pass:'Prépare la passe',shoot:'Prépare sa frappe',watch:'Suit l’action',celebrate:'Célèbre le but',request:'Attend le ballon'};
 function reset(){runTime=0;navigator.reset();recovering=0;root.position.set((options.x??4.8)*1.7,0,(options.z??3.8)*1.640625);root.rotation.set(0,0,0);direction.set(0,0,-1);velocity.set(0,0,0);mode='support';holdTime=0;receiveDelay=0;requestPassTime=0;requestShotTime=0;pending=null;side=1;avatar.reset();}
 function receive(){runTime=0;navigator.reset();recovering=0;holdTime=0;receiveDelay=.12;pending=null;receiveCount++;mode='control';}
 function beginAction(type,option=null){if(pending)return;pending={type,time:.095,recipient:option?.agent||null,kind:option?.kind||'pass',point:option?.root.position.clone()};mode=type==='pass'?'pass':'shoot';avatar.kick();}
 function update(dt,c){
  if(!avatar.ready||dt<=0)return null;const frameStart=root.position.clone();age+=dt;supportReview-=dt;requestPassTime=Math.max(0,requestPassTime-dt);requestShotTime=Math.max(0,requestShotTime-dt);let speed=0,action=null;
  target.copy(root.position);
  if(!c.active){mode=c.celebrate?'celebrate':'watch';velocity.multiplyScalar(Math.exp(-dt*10));avatar.update(dt,{goal:c.celebrate});return null;}
  if(recovering>0){recovering-=dt;root.position.addScaledVector(retreat,dt*1.6);direction.copy(retreat);root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);avatar.update(dt,{moving:true,walk:true});return null;}
  const enemies=c.enemies||[];const pressure=Math.min(...enemies.map(o=>o.position.distanceTo(root.position)));const openPass=laneClear(root.position,c.player,enemies,1);
  const playerDistance=root.position.distanceTo(c.player);
  if(c.owner==='mate'){
   const route=navigator.update(dt,root.position,new THREE.Vector3(0,0,-52.5),enemies);
   holdTime+=dt;receiveDelay=Math.max(0,receiveDelay-dt);
   if(pending){pending.time-=dt;mode=pending.type==='pass'?'pass':'shoot';if(pending.time<=0){action={type:pending.type,recipient:pending.recipient,kind:pending.kind};if(pending.type==='pass')requestPassTime=0;else requestShotTime=0;pending=null;holdTime=0;}}
   else if(receiveDelay>0){mode='control';}
   else{
    const shootingLane=openShotTarget(root.position,-52.5,enemies);
    const toGoal=Math.hypot(root.position.x,-52.5-root.position.z);
    const option=c.offense;
    const shootNow=toGoal<17&&Math.abs(root.position.x)<7.5&&!!shootingLane;
    const passUseful=option?.safe&&option.space>1.5&&(option.cutback||route.trapped||route.blocked||pressure<3||option.progress>3&&holdTime>.65||option.switchPlay&&holdTime>1||holdTime>2.2&&option.score>25);
    if(holdTime>.22&&requestPassTime>0&&playerDistance>2&&playerDistance<55){beginAction('pass');}
    else if(holdTime>.24&&((requestShotTime>0&&toGoal<29)||shootNow&&!(option?.cutback&&option.safe&&option.space>2))){shotTarget=shootingLane;beginAction('shoot');}
    else if(holdTime>.4&&passUseful){beginAction('pass',option);}
    else{mode='carry';target.copy(root.position).addScaledVector(route.direction,3);speed=3.9*route.speed;}
   }
  }else{
   holdTime=0;receiveDelay=0;pending=null;
   const isReceiving=c.owner==='free'&&!c.shotLive&&c.passTarget!=='player';
   if(c.defendCover){mode='support';target.copy(c.defensiveTarget||new THREE.Vector3(options.lane??5,0,THREE.MathUtils.clamp(c.ball.z+5,-23,26)));speed=3.7;}else if(c.owner==='defender'){const playerPress=c.player.distanceTo(c.ball)<root.position.distanceTo(c.ball)-1;mode=playerPress?'support':'chase';target.copy(c.ball);target.y=0;if(playerPress){target.x+=(c.ball.x>0?-4:4);target.z=Math.min(18,c.ball.z+4);}else{const away=root.position.clone().sub(c.ball);away.y=0;if(away.lengthSq()>.01)target.addScaledVector(away.normalize(),1.15);}speed=4.0;}else if(isReceiving){
    mode=c.passTarget==='mate'?'intercept':'chase';let lead=.12;
    if(c.ball.y>.7){lead=THREE.MathUtils.clamp((c.ballVelocity.y+Math.sqrt(c.ballVelocity.y*c.ballVelocity.y+19.6*Math.max(0,c.ball.y-.15)))/9.8,0,1.1);}
    target.copy(c.ball).addScaledVector(c.ballVelocity,lead);target.y=0;target.x=THREE.MathUtils.clamp(target.x,-32.8,32.8);target.z=THREE.MathUtils.clamp(target.z,-50.7,50.5);speed=5.9;
   }else{
    mode=c.shotLive?'watch':'support';
    if(c.player.x>6)side=-1;else if(c.player.x< -6)side=1;
    target.set(THREE.MathUtils.clamp(c.player.x+(options.lane??side*5.1),-16.3,16.3),0,THREE.MathUtils.clamp(c.player.z-(options.depth??5.2),-26.5,15));
    if(c.player.z< -15)target.set(c.player.x>0?-3.8:3.8,0,-15.5);
    if(c.owner==='player'&&supportReview<=0&&!laneClear(c.player,target,enemies,1.1)){side*=-1;supportReview=1.3;target.x=THREE.MathUtils.clamp(c.player.x+side*5.5,-10,10);target.z=THREE.MathUtils.clamp(c.player.z-2,-17,17);}
    speed=c.shotLive?2.2:4.9;
   }
  }
  if(c.supportPlan&&c.owner!=='mate'&&c.owner!=='free'&&!c.shotLive){target.copy(c.supportPlan.target);speed=c.supportPlan.speed;mode=c.supportPlan.kind;}
  if(c.defensePlan&&c.owner!=='mate'){runTime=0;target.copy(c.defensePlan.target);mode=c.defensePlan.kind;speed=c.defensePlan.speed;}
  if(runTime>0){runTime=Math.max(0,runTime-dt);if(c.owner==='player'&&!c.shotLive){mode='run';target.copy(runTarget);speed=5.8;if(root.position.distanceTo(target)<.6)runTime=0;}else if(c.owner==='defender'||c.owner==='mate')runTime=0;}
  const flowing=pending||action||mode==='pass'||mode==='shoot';
  if(flowing){target.copy(root.position).add(velocity);speed=velocity.length();}
  const delta=target.clone().sub(root.position);delta.y=0;const distance=delta.length();
  let desired=distance>.24?delta.normalize().multiplyScalar(Math.min(speed,distance*3.1)):new THREE.Vector3();
  if(playerDistance<1.1&&playerDistance>.01){const away=root.position.clone().sub(c.player);away.y=0;desired.addScaledVector(away.normalize(),(1.1-playerDistance)*4);}
  if(c.teamGrid&&!flowing)desired=c.teamGrid.steer(root,desired);
  if(flowing)velocity.multiplyScalar(Math.exp(-dt*1.3));else velocity.lerp((mode==='carry'?desired:steerAvoid(root.position,desired,enemies,1.3)).clampLength(0,5.9),1-Math.exp(-dt*10));if(mode==='control')velocity.multiplyScalar(Math.exp(-dt*4));
  root.position.addScaledVector(velocity,dt);root.position.x=THREE.MathUtils.clamp(root.position.x,-32.8,32.8);root.position.z=THREE.MathUtils.clamp(root.position.z,-50.7,50.5);
  const moving=velocity.length()>.15;
  let facing=velocity.clone();if(mode==='pass')facing.copy(pending?.point||action?.recipient?.root.position||c.player).sub(root.position);else if(mode==='shoot')facing.set(-root.position.x,0,-52.5-root.position.z);else if(!moving&&c.owner!=='mate')facing.copy(c.ball).sub(root.position);
  facing.y=0;if(facing.lengthSq()>.001){facing.normalize();turnToward(direction,facing,dt);root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);}
  const travel=root.position.clone().sub(frameStart);travel.y=0;
  if(travel.lengthSq()>dt*dt*.01&&!avatar.kicking){direction.copy(travel).normalize();root.rotation.set(0,Math.atan2(-direction.x,-direction.z),0);}
  avatar.update(dt,{moving:travel.lengthSq()>dt*dt*.01,sprint:velocity.length()>5.2});
  ring.material.opacity=c.owner==='mate'?.95:.6;ring.material.color.set(c.owner==='mate'?'#d4f877':'#75dced');
  return action;
 }
 return {get runTime(){return runTime},get runTarget(){return runTime>0?runTarget:null},cancelRun(){runTime=0;},requestRun(destination){runTarget.copy(destination);runTime=3.5;},get shotTarget(){return shotTarget},navigator,number:options.number??7,root,avatar,promise:avatar.promise,reset,receive,update,direction,velocity,
  yield(from){recovering=1.1;pending=null;mode='watch';retreat.copy(root.position).sub(from);retreat.y=0;if(retreat.lengthSq()<.01)retreat.set(1,0,1);retreat.normalize();},get state(){return mode},get status(){return stateNames[mode]||'Disponible'},get possessionTime(){return holdTime},
  requestPass(){requestPassTime=5;requestShotTime=0;if(pending?.type==='shoot')pending=null;},
  requestShot(){requestShotTime=5;requestPassTime=0;},
 };
}
