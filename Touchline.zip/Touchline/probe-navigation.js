import * as THREE from 'three';
// Three swept ground probes, computed numerically only. No scene objects,
// debug lines or visible ray helpers are created.
export function createProbeNavigator(){
 let committed=0,hold=0,review=0,last=null;
 const probeLength=4.6,clearance=.92;
 function cast(origin,direction,obstacles){
  let distance=probeLength;
  for(const object of obstacles){const p=object.position||object,v=object.userData?.velocity;
   const dx=p.x+(v?.x||0)*.22-origin.x,dz=p.z+(v?.z||0)*.22-origin.z;
   const along=dx*direction.x+dz*direction.z,lateral=dx*dx+dz*dz-along*along;
   if(along<-.15||lateral>clearance*clearance)continue;
   distance=Math.min(distance,Math.max(0,along-Math.sqrt(Math.max(0,clearance*clearance-lateral))));
  }
  for(const [position,slope,bound] of [[origin.x,direction.x,32.9],[origin.z,direction.z,51.2]]){
   if(Math.abs(slope)>.001){const edge=((slope>0?bound:-bound)-position)/slope;if(edge>=0)distance=Math.min(distance,edge);}
  }
  return distance;
 }
 return {
  reset(){committed=0;hold=0;review=0;last=null;},
  get last(){return last},
  update(dt,position,goal,obstacles){
   hold=Math.max(0,hold-dt);review-=dt;
   if(last&&review>0)return last;
   review=.10;
   const forward=goal.clone().sub(position);forward.y=0;if(forward.lengthSq()<.001)forward.set(0,0,1);forward.normalize();
   const directions=[-.70,0,.70].map(angle=>forward.clone().applyAxisAngle(new THREE.Vector3(0,1,0),angle));
   const distances=directions.map(d=>cast(position,d,obstacles));
   const blocked=distances[1]<3.5,trapped=Math.max(...distances)<1.6;
   let chosen=1;
   if(blocked){
    const side=distances[0]>distances[2]?0:2;
    const previous=committed<0?0:2;
    chosen=committed!==0&&hold>0&&distances[previous]>1.15?previous:side;
    if(distances[1]>distances[chosen]+.7)chosen=1;
   }else if(committed!==0&&hold>0&&distances[committed<0?0:2]>2){chosen=committed<0?0:2;}
   const newSide=chosen-1;if(newSide!==committed){committed=newSide;hold=.70;}
   let direction=directions[chosen].clone(),speed=chosen===1?1:.85;
   if(trapped){
    // No free corridor: give ground, open an angle, and let the football AI
    // prefer a pass. Never keep accelerating into the blocking player's body.
    direction.copy(forward).negate().addScaledVector(new THREE.Vector3(-forward.z,0,forward.x),distances[0]>distances[2]?.7:-.7).normalize();speed=.38;
   }else speed*=THREE.MathUtils.clamp(distances[chosen]/2.1,.3,1);
   last={direction,speed,blocked,trapped,choice:trapped?'retreat':chosen===1?'forward':chosen===0?'left':'right',distances};return last;
  }
 };
}

// Test three actual goal targets before committing to a shot. This uses the
// same horizontal clearance principle, with no rendered aim helpers.
export function openShotTarget(position,goalZ,obstacles){
 const order=position.x>=0?[-2.65,2.65,0]:[2.65,-2.65,0];
 for(const x of order){const target=new THREE.Vector3(x,0,goalZ),delta=target.clone().sub(position);delta.y=0;const length=delta.length();delta.normalize();let clear=true;
  for(const o of obstacles){const p=o.position||o,dx=p.x-position.x,dz=p.z-position.z,along=dx*delta.x+dz*delta.z;if(along>.2&&along<length-.4&&dx*dx+dz*dz-along*along<.8*.8){clear=false;break;}}
  if(clear)return target;
 }
 return null;
}
