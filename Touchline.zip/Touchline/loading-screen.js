export function createLoadingScreen(){
 const overlay=document.getElementById('loadingScreen'),bar=document.getElementById('loadingBar'),number=document.getElementById('loadingPercent'),status=document.getElementById('loadingStatus'),players=document.getElementById('loadingPlayers'),stadium=document.getElementById('loadingStadium'),retry=document.getElementById('loadingRetry');
 const completed=new Set();let complete=false,secondary=false,failed=false;
 retry.onclick=()=>location.reload();
 function update(){const count=[...completed].filter(k=>k.startsWith('player')).length;const percent=Math.floor(completed.size/6*100);bar.style.width=percent+'%';number.textContent=percent+' %';overlay.querySelector('[role=progressbar]').setAttribute('aria-valuenow',percent);players.textContent=count+' / 4 joueurs prêts';stadium.textContent=completed.has('stadium')?'Stade prêt':'Préparation du stade…';status.textContent=count<4?'Préparation des personnages et des animations…':!completed.has('stadium')?'Installation du stade et des tribunes…':'Préparation de l’affichage 3D…';}
 return {
  get isComplete(){return complete;},
  done(key){if(failed||secondary)return;completed.add(key);update();},
  finish(){if(failed)return;complete=true;overlay.hidden=true;},
  startStadium(name){secondary=true;failed=false;overlay.hidden=false;bar.style.width='0%';number.textContent='0 %';overlay.querySelector('[role=progressbar]').setAttribute('aria-valuenow','0');status.textContent='Chargement du stade : '+name;players.textContent='4 joueurs prêts';stadium.textContent='Installation des tribunes et de la pelouse…';retry.hidden=true;},
  stadiumReady(){bar.style.width='100%';number.textContent='100 %';overlay.querySelector('[role=progressbar]').setAttribute('aria-valuenow','100');stadium.textContent='Stade prêt';requestAnimationFrame(()=>requestAnimationFrame(()=>{if(!failed)overlay.hidden=true;}));},
  fail(error){failed=true;overlay.hidden=false;status.textContent='Le chargement n’a pas pu se terminer.';stadium.textContent='Clique sur Réessayer pour recharger le jeu.';retry.hidden=false;console.error(error);}
 };
}
