export function createRadar(canvas){
 const ctx=canvas.getContext('2d');canvas.width=360;canvas.height=224;
 const left=14,top=12,width=332,height=200;
 const at=p=>[left+(52.5-p.z)/105*width,top+(p.x+34)/68*height];
 return {update(players,ball){
  ctx.clearRect(0,0,360,224);ctx.fillStyle='#103b30dc';ctx.fillRect(0,0,360,224);ctx.strokeStyle='#e5f1d877';ctx.lineWidth=2;ctx.strokeRect(left,top,width,height);ctx.beginPath();ctx.moveTo(180,top);ctx.lineTo(180,212);ctx.stroke();ctx.beginPath();ctx.ellipse(180,112,27,26,0,0,Math.PI*2);ctx.stroke();const boxW=16.5/105*width,boxH=40.32/68*height,boxY=top+(height-boxH)/2;ctx.strokeRect(left,boxY,boxW,boxH);ctx.strokeRect(left+width-boxW,boxY,boxW,boxH);const goalH=7.32/68*height;ctx.strokeRect(7,top+(height-goalH)/2,7,goalH);ctx.strokeRect(346,top+(height-goalH)/2,7,goalH);
  for(const p of players){const [x,y]=at(p.position);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(x,y,p.human?6.5:5.5,0,Math.PI*2);ctx.fill();if(p.human){ctx.strokeStyle='#d9ff75';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,10,0,Math.PI*2);ctx.stroke();}}
  const [x,y]=at(ball);ctx.fillStyle='#fffdf1';ctx.strokeStyle='#193c2c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,4,0,Math.PI*2);ctx.fill();ctx.stroke();
 }};
}
